//---------------------------------------------------------------------------
// IPC INTERFACE
//---------------------------------------------------------------------------
// History :
// 01 : creation
// 02 : nov 2013, Modification from API to IPC
//      As the IPC interface is fully compatible with the old API, the names are unchanged

//---------------------------------------------------------------------------
// INTERFACE DEFINITION
//---------------------------------------------------------------------------
typedef unsigned char __stdcall (*TAPI)(char *Command, void *Structure);

//---------------------------------------------------------------------------
// STRUCTURES DEFINITION
//---------------------------------------------------------------------------
// Structure for all ANUMLFRF commands
#define API_STRING_SIZE 1024
struct TAPILFRF
{
    char          StringIn1[API_STRING_SIZE];
    char          StringIn2[API_STRING_SIZE];
    char          StringIn3[API_STRING_SIZE];
    char          StringIn4[API_STRING_SIZE];
    unsigned char ByteIn1;
    unsigned char ByteIn2;
    unsigned char ByteIn3;
    unsigned char ByteIn4;

    char          StringOut1[API_STRING_SIZE];
    char          StringOut2[API_STRING_SIZE];
    char          StringOut3[API_STRING_SIZE];
    char          StringOut4[API_STRING_SIZE];
    unsigned char ByteOut1;
    unsigned char ByteOut2;
    unsigned char ByteOut3;
    unsigned char ByteOut4;
};


//---------------------------------------------------------------------------
// RETURN VALUES
//---------------------------------------------------------------------------
#define API_OK              0x00    // If no error occur
#define API_ER_COMMAND      0x02    // Command name is not recognized
#define API_ERROR           0x03    // Specific error (see for each function)


//---------------------------------------------------------------------------
// COMMANDS
//---------------------------------------------------------------------------
/*
    LOAD : Load a configuration file
    --------------------------------
        IN  : StringIn1 = path and file name
        OUT : -
        RET : ERROR if file not exists else OK

    RUN : Start run in manual mode
    ------------------------------
        IN  : -
        OUT : -
        RET : OK or ERROR (licence expired)

    RUN_MANUAL : Start run in Manual mode (same as RUN command)
    --------------------------------------
        IN  : -
        OUT : -
        RET : OK or ERROR (licence expired)

    RUN_SCRIPT : Start run in Script mode
    --------------------------------------
        IN  : -
        OUT : -
        RET : OK or ERROR (licence expired)

    RUN_BROADCAST : Start run in Broadcast mode
    --------------------------------------
        IN  : -
        OUT : -
        RET : OK or ERROR (licence expired)

    RUN_INDIVIDUAL : Start run in Individual mode
    --------------------------------------
        IN  : -
        OUT : -
        RET : OK or ERROR (licence expired)

    RUN_EMC : Start run in EMC mode
    --------------------------------------
        IN  : -
        OUT : -
        RET : OK or ERROR (licence expired)

    RUN_TSTLF : Start run in TSTLF mode
    --------------------------------------
        IN  : -
        OUT : -
        RET : OK or ERROR (licence expired)

    IDFILTER : specify the ID to be received
    ----------------------------------------------------
        IN  : List of ID, or null string for all ID
        OUT : -
        RET : OK

    READLSE : Get LSE informations
    ----------------------------------------------------
        IN  : -
        OUT : ByteOut1   = 1 or 0 according to the rotation
              ByteOut2   = Tooth number (Optical sensor only)
              StringOut1 = Angle in �
              StringOut2 = Speed of the last complete revolution
        RET : OK

    STOP : Stop the run
    -------------------
        IN  : -
        OUT : -
        RET : OK

    LFPWR : modify the LF Power
    ---------------------------
        IN  : ByteIn1 = level [0..100]%
        OUT : -
        RET : OK or ERROR

    SENDF : Send a frame (yet defined in the list)
    ----------------------------------------------
        IN  : StringIn1  = Frame name
              StringIn2  = 1st parameter (if defined)
              StringIn3  = 2nd parameter (if defined)
              StringIn4  = 3rd parameter (if defined)
              ByteIn1    = Number of frames  [1..255]
              ByteIn2    = Interframe [0..255]ms
        OUT : -
        RET : OK or ERROR if the frame is not defined

    STOPF : Stop LF emission(in case of CONT)
    ----------------------------------------------
        IN  : -
        OUT : -
        RET : OK

    SHOW : Show ANumLFRF.exe GUI
    ----------------------------------------------
        IN  : -
        OUT : -
        RET : OK

    HIDE : Hide ANumLFRF.exe GUI
    ----------------------------------------------
        IN  : -
        OUT : -
        RET : OK

    FEXISTS : Return flag if the frame name is in the list
    -----------------------------------------------------
        IN  : StringIn1  = Frame name
        OUT : ByteOut1 = 1 if Frame exists, else 0
        RET : OK

    FSENT : Return flag to indicate the frame is sent
    ----------------------------------------------
        IN  : -
        OUT : ByteOut1 = 1 if Frame sent, else 0
        RET : OK

    FREAD : Read a received frame
    -------------------------------------
        IN  : -
        OUT : ByteOut1   = Number of received frames (100 maximum)
              StringOut1 = 1st received frame (complete)
              StringOut2 = 1st received frame (Hex field only)
        RET : OK

    CLRBUF : Clear the received buffer
    ----------------------------------
        IN  : -
        OUT : -
        RET : OK

    IDREAD : Read the ID field in the 1st received frame
    ----------------------------------------------------
        IN  : -
        OUT : ByteOut1   = 1 if ID field exists, else 0
              StringOut1 = Received ID value
              StringOut2 = Received frame
        RET : OK

*/


