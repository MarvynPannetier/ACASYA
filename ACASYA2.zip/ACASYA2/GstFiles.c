// DEBUT TABLE
//******************************************************************************
// PRO: BANC DE TEST LSE
// PRG: GstFiles.c
// VER: Version I00A00A du 09/08/2010
// AUT: C. BERENGER / MICROTEC
//
// ROL: Programme de gestion des fichiers
//
// HST: Version I00A00A du 14/09/2010 / MP. LACROIX MICROTEC / Cr�ation
// HST: Version I00A00B du 15/11/2010 / C.BERENGER / 
//		- Passage de la r�solution moteur � 0.1 tours/min
//		- Modification de l'affichage du graphique en mode manuel
//		- Correction du probl�me de gestion des limites apr�s le chargement
//	      d'un cycle dans une autre unit� de vitesse ou de pression que celle 
//	      utilis�e par d�faut.
// HST: Version I00A00C du 30/11/2010 / C. BERENGER MICROTEC / 
//	    - Ajout d'une gestion par watchdog pour couper le moteur et la pression 
//	      en cas de probl�me de blocage de l'application.
// HST: Version I00A00D du 04/01/2011 / C. BERENGER MICROTEC / 
//	    - Ajout de quelques Mutex
//		- Suppresison de l'utilisation du fichier "MessageIhm.ini", et remplacement par des constantes
//		- Recompilation du programme avec la version 8.6.0f5 du DAQmx (identique � la version install�e sur le banc du client)
//		- Passage de la variable "GptstConfig" en mode prot�g� dans le fichier "Modes.c"
//******************************************************************************
//
//******************************************************************************
// FIN TABLE

//******************************************************************************
// Inclusions
//******************************************************************************

// Librairies standards 
#include "monwin.h"
#include "Gst-ini.h"

#include <utility.h>
#include <ansi_c.h>
#include <userint.h>
#include <cvirte.h>


// Librairies FOURNISSEUR

// Librairies MICROTEC
#include "ZoneMessage.h"
//#include "MessageIhm.h"
#include "ResultTextFile.h"

// Librairies sp�cifiques � l'application
#include "IhmModes.h"
#include "GstFiles.h"
#include "Modes.h"




//******************************************************************************
// D�finition de constantes
//******************************************************************************
//----- Options -------
//---------------------
#define cSEPARATOR ';'

#define sNOM_FICH_CONFIG			"Config.ini"
#define sDIR_CONFIG					"Config"

#define sSECTION_SPEED				"SPEED PARAM"
#define sSECTION_PRESSURE			"PRESSURE PARAM"
#define sSECTION_COMMON				"COMMON PARAM"

// Speed Unit=;(0=km/h, 1=g, 2=trs/min);
#define sTAG_SPEED_UNIT				"Speed Unit"
// Engine communication port number (1,2,...)
#define sTAG_ENGINE_COM_PORT		"ENGINE COM PORT"
// Engine communication baudrate (default = 19200)
#define sTAG_ENGINE_COM_SPEED		"ENGINE COM SPEED"
// Delay between two readings (in ms)
#define sTAG_READ_DELAY				"READ DELAY"
// Pressure Unit= (0=kPa, 1=bars, 2=mBars, 14=Psi);
#define sTAG_PRESSURE_UNIT			"Pressure Unit"
// Delay between two pressure commands (in ms)
#define sTAG_PRESSURE_COMMAND_DELAY	"PRESSURE COMMAND DELAY"
// Delay between two accelerations command (in ms)
#define sTAG_ACCELL_COMMAND_DELAY   "ACCEL COMMAND DELAY"

//-- Km/h * A + B => trs/min
#define sTAG_COEFF_A_KM_H			"COEFF_A_KM_H"
#define sTAG_COEFF_B_KM_H			"COEFF_B_KM_H"

//--  g * A + B => trs/min
#define sTAG_COEFF_A_G	 			"COEFF_A_G"
#define sTAG_COEFF_B_G	 			"COEFF_B_G"

//--  Kpa * A + B => bars
#define sTAG_COEFF_A_KPA	 		"COEFF_A_KPA"
#define sTAG_COEFF_B_KPA	 		"COEFF_B_KPA"

//--  Psi * A + B => bars
#define sTAG_COEFF_A_PSI	 		"COEFF_A_PSI"
#define sTAG_COEFF_B_PSI	 		"COEFF_B_PSI"

//--  Mbar * A + B => bars
#define sTAG_COEFF_A_MBAR	 		"COEFF_A_MBAR"
#define sTAG_COEFF_B_MBAR	 		"COEFF_B_MBAR"

#define sTAG_LIM_MIN_KM_H			"LIM_MIN_KM_H"
#define sTAG_LIM_MAX_KM_H			"LIM_MAX_KM_H"
#define sTAG_LIM_MIN_G				"LIM_MIN_G"
#define sTAG_LIM_MAX_G				"LIM_MAX_G"
#define sTAG_LIM_MIN_TRS_MIN		"LIM_MIN_TRS_MIN"
#define sTAG_LIM_MAX_TRS_MIN		"LIM_MAX_TRS_MIN"
#define sTAG_LIM_MIN_KPA			"LIM_MIN_KPA"
#define sTAG_LIM_MAX_KPA			"LIM_MAX_KPA"
#define sTAG_LIM_MIN_PSI			"LIM_MIN_PSI"
#define sTAG_LIM_MAX_PSI			"LIM_MAX_PSI"
#define sTAG_LIM_MIN_MBAR			"LIM_MIN_MBAR"
#define sTAG_LIM_MAX_MBAR			"LIM_MAX_MBAR"
#define sTAG_LIM_MIN_BAR			"LIM_MIN_BAR"
#define sTAG_LIM_MAX_BAR			"LIM_MAX_BAR"

#define sTAG_LIM_MIN_SPEED_DURAT	"LIM_MIN_SPEED_DURAT"
#define sTAG_LIM_MAX_SPEED_DURAT	"LIM_MAX_SPEED_DURAT"

#define sTAG_LIM_MIN_PRESS_DURAT	"LIM_MIN_PRESS_DURAT"
#define sTAG_LIM_MAX_PRESS_DURAT	"LIM_MAX_PRESS_DURAT"
#define sTAG_PLAGE_AFFICH_MANU		"DISPLAY_DURAT_MANU_MODE"
#define sTAG_WATCHDOG				"USE_WATCHDOG"
#define sTAG_SAVE_RESULTS			"SAVE_RESULTS"


#define sUNIT						"Unit=%d"
#define sNB_CYC_PRESS				"NbCycPres=%d"
#define sMSG_ERR_ADDING_LINE		"Error adding line [%s] to result file!\nTest cancelled!"
#define sMSG_ERR_COPY_FILE			"Error, can't copy file [%s] => [%s]!"
#define sMSG_ERR_CREATE_FILE		"Error, can't create file [%s.%s]!"
#define sMSG_ERR_WRIT_CYCLE			"Error writing cycles file [%s]!"
#define sMSG_ERR_CREATE_CYCLE_FILE	"Error, can't create cycles file [%s]!"
#define sMSG_OPEN_FILE				"Open file [%s]\n"
#define sMSG_TOO_MANY_ERR			"Too many errors to display..."
#define sMSG_ERR_READING_LINE		"Error reading line %d, error = %d!\n"
#define sMSG_ERR_READ_SPEED_UNIT	"Error reading Speed Unit (line N�%d) => [%s], can't convert value!\n"
#define sMSG_ERR_READ_SPEED_DATA	"Error reading Speed data N�%d (line N�%d) => [%s], can't convert values!\n"
#define sMSG_ERR_READ_SPEED_TIME	"Error, Speed time N�%d [%.0f] (line N�%d) is over limits (min=%.01f, max=%.01f)!\n"
#define sMSG_ERR_SPEED_DATA_OV_LIM	"Error, Speed Data N�%d [%.0f] (line N�%d) is over limits (min=%.01f, max=%.01f)!\n"
#define sMSG_NB_CYC_SPEED			"NbCycSpeed=%d"
#define sMSG_ERR_READ_SPPED_CYC_NB	"Error reading Speed cycles number (line N�%d) => [%s], can't convert value!\n"
#define sMSG_ERR_READ_PRESS_UNIT	"Error reading Pressure Unit  (line N�%d) => [%s], can't convert value!\n"
#define sMSG_ERR_READ_PRESS_DATA	"Error reading Pressure data (line N�%d) => [%s], can't convert values!\n"
#define sMSG_ERR_PRESS_TIME			"Error, Pressure time N�%d [%.0f] (line N�%d) is over limits (min=%.01f, max=%.01f)!\n"
#define sMSG_ERR_PRESS_DATA			"Error, Pressure Data N�%d [%.0f] (line N�%d) is over limits (min=%.01f, max=%.01f)!\n"
#define sMSG_ERR_READ_NB_PRESS_CYC	"Error reading number of pressure cycles number (line N�%d) => [%s], can't convert value!\n"
#define sERR_OPEN_FILE_INSUFF_MEM	"Error opening file [%s], error =%d, insufficient memory!\n"
#define sERR_OPEN_FILE_ALR_OPEN		"Error opening file [%s], error =%d, %d files open already!\n"
#define sERR_OPEN_FILE_NULL			"Error opening file [%s], error =%d, filename is NULL or contains only whitespace!\n"
#define sMSG_ERR_READ_CFG_FILE		"Error reading Config file: Section[%s], Tag'%s'"
#define sMSG_ERR_CLOSE_FILE			"Error closing result file!"

//******************************************************************************
// D�finition de types et structures
//******************************************************************************



//******************************************************************************
// Variables globales
//******************************************************************************
static char GsPathFichierResultats[500];
//extern char returnPathFichierResultats[500];

//******************************************************************************
// Fonctions internes au source
//******************************************************************************



//******************************************************************************
// Corps des fonctions et proc�dures internes au source
//******************************************************************************
#define CHECK_TAB_INDEX(sId, iIndex, iNdexMin, iIndexMax) 	\
{														\
	if ((iIndex < iNdexMin) || (iIndex > iIndexMax))	\
		MessagePopup(sId, "Index Error");		\
}


// DEBUT ALGO
//***************************************************************************
// void GstFilesGetStringDateHeure(char *sDateHeure)
//***************************************************************************
//  - char *sDateHeure: Chaine de caract�res contenant la date et l'heure
//
//  - Cr�ation d'une chaine de caract�res contenant la date et l'heure
//
//  - Aucun
//***************************************************************************
// FIN ALGO
void GstFilesGetStringDateHeure(char *sDateHeure)
{
int iMM, iJJ, iAAAA;//Date
int iHH, iMN, iSS;	//Heure

	strcpy(sDateHeure, "");
	GetSystemDate (&iMM, &iJJ, &iAAAA);
	GetSystemTime (&iHH, &iMN, &iSS);  
	
	sprintf(sDateHeure, "%04d-%02d-%02d %02d-%02d-%02d", iAAAA, iMM, iJJ, iHH, iMN, iSS);
}

// DEBUT ALGO
//***************************************************************************
// int GstFilesCloseResultFile(int iHandleFile, char *sErrMsg)
//***************************************************************************
//	- int iHandleFile   : Handle du fichier
//
//  - Fermeture du fichier r�sultats
//
//  - 0 si pas d'erreur, sinon code d'erreur
//***************************************************************************
// FIN ALGO
int GstFilesCloseResultFile(stTabFile *TabData, int iHandleFile, char *sErrMsg)
{
int iError;

	ResultTextFileClose(TabData, 1, iHandleFile, &iError);
	if(iError != 0){
		strcpy(sErrMsg, sMSG_ERR_CLOSE_FILE);
	}
	
	return iError;
}

// DEBUT ALGO
//***************************************************************************
// int GstFilesAddResultFiles(int iHandleFile, char *sLine, BOOL bCloseFile, char *sErrMsg)
//***************************************************************************
//	- int iHandleFile   : Handle du fichier
//    char *sLine 		: Ligne � ajouter dans le fichier r�sultats
//	  BOOL bCloseFile	: 1 = Ferme le fichier, 0= Laisse le fichier ouvert
//
//  - Ajout d'une ligne dans le fichier r�sultats
//
//  - 0 si pas d'erreur, sinon code d'erreur
//***************************************************************************
// FIN ALGO
int GstFilesAddResultFiles(stTabFile *TabData, int iHandleFile, char *sLine, BOOL bCloseFile, char *sErrMsg)
{
int iError;

	ResultTextFileAdd(TabData, 1, iHandleFile, sLine, bCloseFile, &iError);
	if(iError != 0){
		sprintf(sErrMsg, sMSG_ERR_ADDING_LINE, sLine);
	}
	
	return iError;
}

// DEBUT ALGO
//***************************************************************************
// int GstFilesResetAll(stTabFile *TabData)
//***************************************************************************
//	- 
//
//  - Reset de la librairie d'enregistrement des fichiers r�sultats
//
//  - 0 si pas d'erreur, sinon code d'erreur
//***************************************************************************
// FIN ALGO
int GstFilesResetAll(stTabFile *TabData)
{
int iError;

	ResultTextFileResetAll(TabData, 1 , 1, &iError);
	return iError;  
}

// DEBUT ALGO
//***************************************************************************
//int GstFilesCreateResultFiles(BOOL bCopyConfig, char *sPathConfigFile, 
//				char *sRepertoire, char *sFileName, char *sExtension, 
//				int *ptiHandleFile, char *sErrMsg)
//***************************************************************************
//  - BOOL bCopyConfig		:1 = Copie le fichier de configuration, sinon 0
//	  char *sPathConfigFile : Chemin complet vers le fichier de configuration
//	  char *sRepertoire	: Nom du r�pertoire
//	  char *sFileName	: Nom du fichier � cr�er
//	  char *sExtension	: Nom de l'extension du fichier (ex: "csv")
//	  int *ptiHandleFile: Pointeur vers le fichier cr��
//
//  - Cr�ation d'un fichier r�sultats, copie ddu fichier de configuration et du fichier de cyclage
//
//  - 0 si pas d'erreur, sinon code d'erreur
//***************************************************************************
// FIN ALGO
int GstFilesCreateResultFiles(BOOL bCopyConfig, char *sPathConfigFile, stTabFile *TabData, 
							char *sRepertoire, char *sFileName, char *sExtension, int *ptiHandleFile, char *sErrMsg)
{
#define iTAILLE_FICHIER_MAX		1048576 // 1Mo
#define iNB_LIGNE_FICHIER_MAX   20000
#define bDONT_PROTECT			0
int  iError=0;
char sFileNameCfg[MAX_FILENAME_LEN];
char sProjectDir[MAX_PATHNAME_LEN ];
char sPathConfig[MAX_PATHNAME_LEN ];
char sPathConfigDest[MAX_PATHNAME_LEN ];

	strcpy(sErrMsg, "");
	iError = 0;

	if(bCopyConfig){
		// Extraction du nom du fichier de configuration
		SplitPath (sPathConfigFile, NULL, NULL, sFileNameCfg);
		// Chemin complet vers le r�pertoire de copie du fichier de configuration
		sprintf(GsPathFichierResultats, "%s\\%s", sRepertoire, sFileNameCfg);
		
		// Recopie du fichier de cyclage
		iError = CopyFile (sPathConfigFile, GsPathFichierResultats);
		if(iError != 0){
			sprintf(sErrMsg, sMSG_ERR_COPY_FILE, sPathConfigFile, GsPathFichierResultats);
			return iError;
		}
	}
	
	// Copie du fichier "Config.ini"
	if(iError == 0){
		GetProjectDir(sProjectDir);
		sprintf(sPathConfig, "%s\\%s\\%s", sProjectDir, sDIR_CONFIG, sNOM_FICH_CONFIG);
		sprintf(sPathConfigDest, "%s\\%s", sRepertoire, sNOM_FICH_CONFIG);
		
		iError = CopyFile (sPathConfig, sPathConfigDest);
		if(iError != 0){
			sprintf(sErrMsg, sMSG_ERR_COPY_FILE, sPathConfig, sPathConfigDest);
			return iError;
		}
	}
	
	// Chemin complet vers le fichier r�sultats
	sprintf(GsPathFichierResultats, "%s\\%s", sRepertoire, sFileName);
	
	if(iError == 0){
		// Cr�ation du fichier r�sultats
		ResultTextFileResetAll(TabData, 1 , 1, &iError);
		ResultTextFileCreate(TabData, 1, GsPathFichierResultats, sExtension, bDONT_PROTECT, iTAILLE_FICHIER_MAX, iNB_LIGNE_FICHIER_MAX, ptiHandleFile, &iError);
		if(iError != 0){
			sprintf(sErrMsg, sMSG_ERR_CREATE_FILE, GsPathFichierResultats, sExtension);
			return iError;
		}		
	}
		
	return iError;
}

// DEBUT ALGO
//***************************************************************************
//void GstFilesGetDonneesPosition(char *sStringPosition, unsigned int uiNumIndex, 
//								char *sValeur, int iSizeMaxBuffer)
//***************************************************************************
//	- char *sStringPosition   => Cha�ne de caract�res contenant les donn�es 
//							  	 d'une position
//	  unsigned int uiNumIndex => Num�ro de l'index des donn�es � lire(0,1...)
//	  char *sValeur			  => Valeur lue dans la cha�ne de caract�res �
//								 l'index demand�
//	  int iSizeMaxBuffer	  => Taille maximale du buffer de retour
//
//  - Retourne la valeur lue dans une cha�ne de caract�res contenant le 
//		s�parateur ';'
//
//  - Aucun
//***************************************************************************
// FIN ALGO
void GstFilesGetDonneesPosition(char *sStringPosition, unsigned int uiNumIndex, 
								char *sValeur, int iSizeMaxBuffer)
{
int iIndex;
int iByte;
int iSizeToCopy;
char *ptCharToFind;
char *ptCourant; 
int iCptNull;

	// Initialisations
	sValeur[0] 	= 0x00; 
	iCptNull 	=0;
	
	// Si la cha�ne de caract�res pass�e en param�tres est vide, on sort
	if(strlen(sStringPosition)<=0)
		return;
	
	// Pointeur courant sur la cha�ne de caract�res
	ptCourant = sStringPosition;	
	
	// On parcours les donn�es s�par�es par des ';'
	for(iIndex=0; iIndex<=uiNumIndex; iIndex++){
		if(ptCourant==NULL)
			return;
		
		ptCharToFind = strchr(ptCourant, cSEPARATOR);
		if(ptCharToFind==NULL)
			iCptNull++;
		if(iCptNull>1)
			return;
			
		// On cherche la zone de donn�es qui nous int�resse
		if(iIndex==uiNumIndex){
			// Calcul de la taille de la cha�ne de caract�res � copier
			if(ptCharToFind==NULL)
				iSizeToCopy = strlen(ptCourant);
			else
				iSizeToCopy = strlen(ptCourant) - strlen(ptCharToFind);

			// Recopie de la zone de donn�es
			if(iSizeToCopy>0){
				for(iByte=0; iByte<iSizeToCopy; iByte++)
					if((ptCourant+iByte)!=NULL){
						if(iByte<iSizeMaxBuffer)
							sValeur[iByte] = *(ptCourant+iByte);
						else
							return;
					}
			
				// Copie de la valeur 0x00 pour cl�turer la cha�ne de caract�res
				sValeur[iSizeToCopy] = 0x00;
			}
		}
		
		if(ptCharToFind!=NULL)
			ptCourant = ptCharToFind + 1;
	}
}


// DEBUT ALGO
//****************************************************************************** 
//int GstFilesSaveConfig (stTabVitesse *ptstTabVitesse, stTabPression *ptstTabPression, 
//					int iNbreCyclesVit, int iNbreCyclesPress, int iUnitVitesse,
//					int iUnitPression, char *sComments, BOOL bSaveOneVit, 
//					BOOL bSaveOnePres, BOOL bSaveVit, BOOL bSavePress, char *sFileName)
//****************************************************************************** 
//	- int iPanel						: Panel de l'�cran d'essai
//	  stTabVitesse *ptstTabVitesse 		: Pointeur sur le Tableau des vitesses � sauvegarder
//	  stTabPression *ptstTabPression	: Pointeur sur le Tableau des pressions � sauvegarder
//	  int iNbreCyclesVit				: Nombre de cycles de vitesses pr�vus
//	  int iNbreCyclesPress				: Nombre de cycles de pression pr�vus
//	  int iUnitVitesse					: Unit� de vitesse choisie
//	  int iUnitPression					: Unit� de pression choisie
//	  BOOL bSaveOneVit					: 1=Sauve uniquement la vitesse dont l'unit� est s�lectionn�e, sinon 0
//	  BOOL bSaveOnePres					: 1=Sauve uniquement la pression dont l'unit� est s�lectionn�e, sinon 0
//	  BOOL bSaveVit						: 1=Sauver la configuration des pressions, sinon 0
//	  BOOL bSavePress					: 1=Sauver la configuration des vitesses, sinon 0
//	  char *sFileName					: Nom complet du fichier de sauvegarde  
//	  char *sErrorMsg					: Message d'erreur
//	  int iSizeMaxErrMsg				: Taille maximale du message d'erreur
// 
//
//  - Sauvegarde d'une configuration d'essai dans un fichier
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
// FIN ALGO
int GstFilesSaveConfig (int iPanel, stTabVitesse *ptstTabVitesse, stTabPression *ptstTabPression, 
						int iNbreCyclesVit, int iNbreCyclesPress, int iUnitVitesse,
						int iUnitPression, BOOL bSaveOneVit, 
						BOOL bSaveOnePres, BOOL bSaveVit, BOOL bSavePress, char *sFileName,
						char *sErrorMsg, int iSizeMaxErrMsg)
{
#define WRITE_BUFF_TO_FILE(sBuff)												\
{	iNbEltsWritten = fwrite (sBuff, sizeof(char), strlen(sBuff), hFile);    	\
	if (iNbEltsWritten != strlen(sBuff)){										\
		iErreur = errno;														\
		sprintf(sErrorMsg, sMSG_ERR_WRIT_CYCLE, sFileName);						\
		fclose(hFile);															\
		return -1;																\
	} 																			\
}

	
#define iPRECISION_DATA 2
double dVal;
char sLine[iMAX_CHAR_COMMENTS+2];
int iNbEltsWritten;
int iErreur;
int iMonth;
int iDay;
int iYear;
int iHour;
int iMin;
int iSec;
int i;
int iCount;
FILE *hFile;

	strcpy(sErrorMsg, "");

	// Ouverture du fichier
	hFile = fopen (sFileName, "w");

	if (hFile != NULL){
		// Ajout de la date/heure
		GetSystemDate (&iMonth, &iDay, &iYear);
		GetSystemTime (&iHour, &iMin, &iSec);
		sprintf(sLine, "Date:%02d/%02d/%04d Time:%02dh%02dmn%02ds\n\n", iDay, iMonth, iYear, iHour, iMin, iSec);      
		WRITE_BUFF_TO_FILE(sLine)

		// Ajout de l'unit� de vitesse
		sprintf(sLine,"Unit=%d;", iUnitVitesse);
		WRITE_BUFF_TO_FILE(sLine) 
		sprintf(sLine,"(%d=%s, ", 	iUNIT_KM_H, 	sUNIT_VIT_KM_H); 
		WRITE_BUFF_TO_FILE(sLine) 
		sprintf(sLine,"%d=%s, ", 	iUNIT_G, 		sUNIT_VIT_G);
		WRITE_BUFF_TO_FILE(sLine) 
		sprintf(sLine,"%d=%s);\n\n",iUNIT_TRS_MIN, 	sUNIT_VIT_TRS_MIN); 
		WRITE_BUFF_TO_FILE(sLine) 			
			

		// Ajout du titre des vitesses
		sprintf(sLine,"%s;",sAFFICH_TEMPS);
		WRITE_BUFF_TO_FILE(sLine)	  
		if (bSaveOneVit){
			switch (iUnitVitesse){
				case iUNIT_KM_H:
					sprintf(sLine,"%s;",sAFFICH_VITESSE_KM_H);
					WRITE_BUFF_TO_FILE(sLine)
				break;
				case iUNIT_G:
					sprintf(sLine,"%s;",sAFFICH_VITESSE_G);
					WRITE_BUFF_TO_FILE(sLine)	  
				break;
				case iUNIT_TRS_MIN:
					sprintf(sLine,"%s;",sAFFICH_VITESSE_TRS_MIN); 
					WRITE_BUFF_TO_FILE(sLine)
				break;
			}
			WRITE_BUFF_TO_FILE("\n") 
		}
		else{
				sprintf(sLine,"%s;",sAFFICH_VITESSE_KM_H);
				WRITE_BUFF_TO_FILE(sLine)	  
				sprintf(sLine,"%s;",sAFFICH_VITESSE_G);
				WRITE_BUFF_TO_FILE(sLine)	  
				sprintf(sLine,"%s;\n",sAFFICH_VITESSE_TRS_MIN); 
				WRITE_BUFF_TO_FILE(sLine)
			}
				  
		// Ajout des donn�es de vitesse  
		for (i=0; i<ptstTabVitesse->iNbElmts; i++){
			//CHECK_TAB_INDEX("100", i, 0, 5000)
			dVal = ptstTabVitesse->dVit[i];
			
			sprintf(sLine, "%.03f;%.03f;\n", ptstTabVitesse->dDuree[i], dVal);
			WRITE_BUFF_TO_FILE(sLine)
		}				
		
		// Ajout du nombre de cycles vitesse
		sprintf(sLine,"\nNbCycSpeed=%d;", iNbreCyclesVit);
		WRITE_BUFF_TO_FILE(sLine) 
		
		
		// Ajout de l'unit� de pression
		sprintf(sLine,"\n\nUnit=%d;", iUnitPression);
		WRITE_BUFF_TO_FILE(sLine) 
		sprintf(sLine,"(%d=%s, ", 	iUNIT_KPA, 		sUNIT_PRES_KPA); 
		WRITE_BUFF_TO_FILE(sLine) 
		sprintf(sLine,"%d=%s, ", 	iUNIT_BAR, 		sUNIT_PRES_BAR); 
		WRITE_BUFF_TO_FILE(sLine) 
		sprintf(sLine,"%d=%s, ", 	iUNIT_MBAR, 	sUNIT_PRES_MBAR); 
		WRITE_BUFF_TO_FILE(sLine) 
		sprintf(sLine,"%d=%s);\n\n",iUNIT_PRES_PSI, sUNIT_PRES_PSI); 
		WRITE_BUFF_TO_FILE(sLine) 
			
		// Ajout du titre des pression
		sprintf(sLine,"%s;",sAFFICH_TEMPS);
		WRITE_BUFF_TO_FILE(sLine)  
			
		if (bSaveOnePres){
			switch (iUnitPression){
				case iUNIT_KPA:
					sprintf(sLine,"%s;",sAFFICH_PRES_KPA);
					WRITE_BUFF_TO_FILE(sLine)	
				break;
				case iUNIT_BAR:
					sprintf(sLine,"%s;",sAFFICH_PRES_BARS);
					WRITE_BUFF_TO_FILE(sLine)					
				break;
				case iUNIT_MBAR:
					sprintf(sLine,"%s;",sAFFICH_PRES_MBAR);
					WRITE_BUFF_TO_FILE(sLine)					
				break;
				case iUNIT_PRES_PSI:
					sprintf(sLine,"%s;",sAFFICH_PRES_PSI);
					WRITE_BUFF_TO_FILE(sLine)					
				break;				
			}
			WRITE_BUFF_TO_FILE("\n")
		}else{
				sprintf(sLine,"%s;",sAFFICH_PRES_KPA);
				WRITE_BUFF_TO_FILE(sLine)	  
				sprintf(sLine,"%s;",sAFFICH_PRES_BARS);
				WRITE_BUFF_TO_FILE(sLine)	  
				sprintf(sLine,"%s;",sAFFICH_PRES_MBAR); 
				WRITE_BUFF_TO_FILE(sLine)
				sprintf(sLine,"%s;\n",sAFFICH_PRES_PSI); 
				WRITE_BUFF_TO_FILE(sLine)
			}
		
		// Ajout des donn�es de pression
		for (i=0; i<ptstTabPression->iNbElmts; i++){
			//CHECK_TAB_INDEX("101", i, 0, 5000)
			dVal = ptstTabPression->dPress[i];
		
			sprintf(sLine, "%.03f;%.03f;\n", ptstTabPression->dDuree[i], dVal);
			WRITE_BUFF_TO_FILE(sLine)
		}				

			
		// Ajout du nombre de cycles pression
		sprintf(sLine,"\nNbCycPres=%d;", iNbreCyclesPress);
		WRITE_BUFF_TO_FILE(sLine) 
			
		// Ajout du titre des commentaires
		sprintf(sLine, "\n\n%s:\n", sTITRE_COMMENTAIRES);
		WRITE_BUFF_TO_FILE(sLine)
			
		// Enregistrement des commentaires
		GetNumTextBoxLines (iPanel, PANEL_MODE_COMMENTAIRES, &iCount);
		
		if(iCount > 0){
			GetTextBoxLine (iPanel, PANEL_MODE_COMMENTAIRES, iCount-1, sLine);	
			if(strlen(sLine) == 0)
				iCount = iCount -1;

			sprintf(sLine,"NbLinesComments=%d;\n", iCount);
			WRITE_BUFF_TO_FILE(sLine)
		
			for(i = 0; i < iCount; i++){
				GetTextBoxLine (iPanel, PANEL_MODE_COMMENTAIRES, i, sLine);	
				if(i < iCount -1)
					strcat(sLine, "\n");
				
				if (i == (iCount -1)){
					if(strlen(sLine) > 0)
						WRITE_BUFF_TO_FILE(sLine)
				}
				else
					WRITE_BUFF_TO_FILE(sLine)
			}
		}
		else{
				WRITE_BUFF_TO_FILE("NbLinesComments=0;\n")
			}

		// Fermeture du fichier
		fclose(hFile);
	}
	else{
			sprintf(sErrorMsg, sMSG_ERR_CREATE_CYCLE_FILE, sFileName);
	
		    //ENOMEM - insufficient memory.
		    //EMFILE - FOPEN_MAX files open already.
		    //EINVAL - filename is NULL or contains only whitespace.
		    //EINVAL - invalid mode.
			return -1;
		}		
	
	return 0; //OK
}




// DEBUT ALGO
//****************************************************************************** 
//int GstFilesLoadConfig (int iPanel, int iSpeedCtrlId, int iPressCtrlId, int iMsgId,
//						stConfig *ptstConfig, stTabVitesse *ptstTabVitesse, stTabPression *ptstTabPression, 
//						int *ptiNbreCyclesVit, int *ptiNbreCyclesPress, int *ptiUnitVitesse,
//						int *ptiUnitPression, char *sComments, BOOL *ptbSaveOneVit, 
//						BOOL *ptbSaveOnePres, char *sFileName)
//****************************************************************************** 
//	- int iPanel						: Handle du panel
//	  int iSpeedCtrlId					: Handle du tableau des vitesses
//	  int iPressCtrlId					: Handle du tableau des pressions
//	  int iMsgId						: Handle de la zone de message de l'�cran d'essai
//	  stConfig *ptstConfig, 			: Pointeur vers les param�tres de configuration
//	  stTabVitesse *ptstTabVitesse 		: Pointeur sur le Tableau des vitesses � sauvegarder
//	  stTabPression *ptstTabPression	: Pointeur sur le Tableau des pressions � sauvegarder
//	  int *ptiNbreCyclesVit				: Nombre de cycles de vitesses pr�vus
//	  int *ptiNbreCyclesPress			: Nombre de cycles de pression pr�vus
//	  int *ptiUnitVitesse				: Unit� de vitesse choisie
//	  int *ptiUnitPression				: Unit� de pression choisie
//    char *sComments					: Commentaires assosci�s � l'essai
//	  BOOL *ptbSaveOneVit				: 1=Sauve uniquement la vitesse dont l'unit� est s�lectionn�e, sinon 0
//	  BOOL *ptbSaveOnePres				: 1=Sauve uniquement la pression dont l'unit� est s�lectionn�e, sinon 0
//	  char *sFileName					: Nom complet du fichier de sauvegarde  
//	  char *sErrorMsg					: Message d'erreur
//	  int iSizeMaxErrMsg				: Taille maximale du message d'erreur
// 
//
//  - Chargement d'une configuration d'essai � partir d'un fichier
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
// FIN ALGO
int GstFilesLoadConfig (int iPanel, int iSpeedCtrlId, int iPressCtrlId, int iMsgId,
						stConfig *ptstConfig, stTabVitesse *ptstTabVitesse, stTabPression *ptstTabPression, 
						int *ptiNbreCyclesVit, int *ptiNbreCyclesPress, int *ptiUnitVitesse,
						int *ptiUnitPression, char *sComments, BOOL *ptbSaveOneVit, 
						BOOL *ptbSaveOnePres, char *sFileName, char *sErrorMsg, int iSizeMaxErrMsg)
{
#define iNB_MAX_MSG 20
	
#define ADD_MSG(iNbMsg, sMsg, sGlobalMsg, iSizeMaxGlobalMsg)					\
{																				\
	if (strlen(sMsg) + strlen(sGlobalMsg) < iSizeMaxGlobalMsg){ 				\
		if(strlen(sGlobalMsg) == 0){											\
			sprintf(sGlobalMsg, sMSG_OPEN_FILE, sFileName);						\
			iNbMsg++;															\
		}																		\
		if(iNbMsg < iNB_MAX_MSG - 1)											\
			strcat(sGlobalMsg, sMsg); 											\
		else																	\
			if(iNbMsg < iNB_MAX_MSG)											\
			 strcat(sGlobalMsg, sMSG_TOO_MANY_ERR);								\
		iNbMsg++;																\
	}																			\
}
	
#define READ_BUFF_IN_FILE(sBuff)												\
{																				\
	strcpy(sBuff, "");															\
	ptResult = fgets (sBuff, iMAX_CHAR_COMMENTS, hFile);    					\
	if ((ptResult == NULL) && (errno != 0)){									\
		strcpy(sBuff, "");														\
		iErreur = errno;														\
		fclose(hFile);															\
		sprintf(sTemp, sMSG_ERR_READING_LINE, iLineNb, errno);					\
		if(strlen(sTemp) + strlen(sErrorMsg) < iSizeMaxErrMsg)  				\
			strcat(sErrorMsg, sTemp);											\
		return -1;																\
	} 																			\
	else{																		\
			if(strlen(sLine) > 1)												\
				sLine[strlen(sLine)-1] = 0x00;									\
			iLineNb++;															\
		}																		\
}

double dVal;
double dMinVal;
double dMaxVal;
double dMinTps;
double dMaxTps;
float fVal1;
float fVal2;
char sLine[iMAX_CHAR_COMMENTS+2];
char sTemp[iMAX_CHAR_COMMENTS+2];
char *ptResult;
int iLineNb;
int iNbMsg;
int iErreur;
int i;
int iNbLines;
FILE *hFile;



	// Initialisations
	ptstTabVitesse->iNbElmts 	= 0;
	ptstTabPression->iNbElmts 	= 0;
	*ptiNbreCyclesPress 		= 1;
	*ptiNbreCyclesVit			= 1;
	iLineNb						= 0;
	iNbMsg						= 0;
	*ptbSaveOneVit				= 1;
	*ptbSaveOnePres				= 1;
	
	strcpy(sComments, "");
	strcpy(sErrorMsg, "");
	

	// Ouverture du fichier
	hFile = fopen (sFileName, "r");

	if (hFile != NULL){
		// Lecture de la date/heure
		READ_BUFF_IN_FILE(sLine)

		// Lecture de l'unit� de vitesse
		READ_BUFF_IN_FILE(sLine)
		READ_BUFF_IN_FILE(sLine) 
		GstFilesGetDonneesPosition(sLine, 0, sTemp, iMAX_CHAR_COMMENTS+2);     
		if(sscanf(sTemp, sUNIT, ptiUnitVitesse)!=1){
			sprintf(sTemp, sMSG_ERR_READ_SPEED_UNIT, iLineNb, sLine);
			ADD_MSG(iNbMsg, sTemp, sErrorMsg, iSizeMaxErrMsg)
			return -1;
		}  		

		// Lecture du titre des vitesses
		READ_BUFF_IN_FILE(sLine)
		READ_BUFF_IN_FILE(sLine)	  

		dMinTps = ptstConfig->dLimMinTpsSpeed;
		dMaxTps = ptstConfig->dLimMaxTpsSpeed;

		switch(*ptiUnitVitesse){
			case iUNIT_KM_H:
				dMinVal = ptstConfig->dLimMinKmH;
				dMaxVal = ptstConfig->dLimMaxKmH;
			break;						
			case iUNIT_G:
				dMinVal = ptstConfig->dLimMinG;
				dMaxVal = ptstConfig->dLimMaxG;
			break;
			case iUNIT_TRS_MIN:
				dMinVal = ptstConfig->dLimMinTrsMin;
				dMaxVal = ptstConfig->dLimMaxTrsMin;
			break;
		}	
	

		// Lecture des donn�es de vitesse  
		i = 0;
		iErreur = 0;
		do{
			READ_BUFF_IN_FILE(sLine)
			
			//AJOUT MaximePAGES 11/06/2020
			
			if (strlen (sLine) > 1){
				if (sscanf (sLine, "%f;%f;", &fVal1, &fVal2) != 2){
					sprintf(sTemp, sMSG_ERR_READ_SPEED_DATA, i+1, iLineNb, sLine);
					ADD_MSG(iNbMsg, sTemp, sErrorMsg, iSizeMaxErrMsg)
					return -1;
				}   
				
	
				if (((double)fVal1 >= dMinTps) && ((double)fVal1 <= dMaxTps)){	
					//CHECK_TAB_INDEX("102", i, 0, 5000)
					ptstTabVitesse->dDuree[i] = (double)fVal1;
					ptstTabVitesse->bWarningDuree[i] = 0;
				}
				else{
						//CHECK_TAB_INDEX("103", i, 0, 5000)
						// Prise de la valeur Minimum ou maximum
						if ((double)fVal1 < dMinTps)
							ptstTabVitesse->dDuree[i] = dMinTps;
						else
							ptstTabVitesse->dDuree[i] = dMaxTps;

						sprintf(sTemp, sMSG_ERR_READ_SPEED_TIME, i+1, fVal1, iLineNb, dMinTps, dMaxTps);
						ADD_MSG(iNbMsg, sTemp, sErrorMsg, iSizeMaxErrMsg)						
						
						
						ptstTabVitesse->bWarningDuree[i] = 1;
					}
				
				
				dVal = (double)fVal2;
				if (iErreur == 0){   
					if ((dVal >= dMinVal) && (dVal <= dMaxVal)){
						//CHECK_TAB_INDEX("104", i, 0, 5000)
						ptstTabVitesse->dVit[i] = dVal;
						ptstTabVitesse->bWarningData[i] = 0; 
					}
					else{
							//CHECK_TAB_INDEX("105", i, 0, 5000)
							// Prise de la valeur Minimum ou maximum
							if (dVal < dMinVal)
								ptstTabVitesse->dVit[i] = dMinVal;
							else
								ptstTabVitesse->dVit[i] = dMaxVal;
					
							sprintf(sTemp, sMSG_ERR_SPEED_DATA_OV_LIM, i+1, dVal, iLineNb, dMinVal, dMaxVal);
							ADD_MSG(iNbMsg, sTemp, sErrorMsg, iSizeMaxErrMsg)							

							ptstTabVitesse->bWarningData[i] = 1; 
						}
				}
				
				// Incr�mentation du nombre de lignes lues
				i++; 
			}
		}while((strlen (sLine) > 1) && (iErreur == 0));
		
		//CHECK_TAB_INDEX("106", i, 0, 5000)
		// Mise � jour du nombre de vitesses lues
		ptstTabVitesse->iNbElmts = i;
		if (iErreur) return iErreur; 		
		
		
		// Lecture du nombre de cycles vitesse
		READ_BUFF_IN_FILE(sLine) 
		if(sscanf(sLine, sMSG_NB_CYC_SPEED, ptiNbreCyclesVit)!= 1){
			sprintf(sTemp, sMSG_ERR_READ_SPPED_CYC_NB, iLineNb, sLine);
			ADD_MSG(iNbMsg, sTemp, sErrorMsg, iSizeMaxErrMsg)
			return -1;
		}
		
		//-----------------------------------------------------------------------------------------
		
		// Lecture de l'unit� de pression
		READ_BUFF_IN_FILE(sLine)
		READ_BUFF_IN_FILE(sLine)
		GstFilesGetDonneesPosition(sLine, 0, sTemp, iMAX_CHAR_COMMENTS+2);     
		if(sscanf(sTemp, sUNIT, ptiUnitPression)!=1){
			sprintf(sTemp, sMSG_ERR_READ_PRESS_UNIT, iLineNb, sLine);
			ADD_MSG(iNbMsg, sTemp, sErrorMsg, iSizeMaxErrMsg)
			return -1;
		}
		
		// Lecture du titre des pression
		READ_BUFF_IN_FILE(sLine)
		READ_BUFF_IN_FILE(sLine)  
			
		dMinTps = ptstConfig->dLimMinTpsPress;
		dMaxTps = ptstConfig->dLimMaxTpsPress;
		
		// Limites de pression
		switch(*ptiUnitPression){
			case iUNIT_KPA:
				dMinVal = ptstConfig->dLimMinKpa;
				dMaxVal = ptstConfig->dLimMaxKpa;  
			break;
			case iUNIT_BAR:
				dMinVal = ptstConfig->dLimMinBar;
				dMaxVal = ptstConfig->dLimMaxBar;
			break;
			case iUNIT_MBAR:
				dMinVal = ptstConfig->dLimMinMbar;
				dMaxVal = ptstConfig->dLimMaxMbar;
			break;
			case iUNIT_PSI:
				dMinVal = ptstConfig->dLimMinPsi;
				dMaxVal = ptstConfig->dLimMaxPsi;
			break;
		}		
				
		// Effacement du tableau des pressions
		DeleteTableRows (iPanel, PANEL_MODE_TABLE_PRESSION, 1, -1);
		
		// Lecture des donn�es de pression  
		i = 0;
		iErreur = 0;
		do{
			READ_BUFF_IN_FILE(sLine)
				
			if (strlen (sLine) > 1){
				if(sscanf(sLine, "%f;%f", &fVal1, &fVal2)!=2){
					sprintf(sTemp, sMSG_ERR_READ_PRESS_DATA, iLineNb, sLine);
					ADD_MSG(iNbMsg, sTemp, sErrorMsg, iSizeMaxErrMsg)
					return -1;
				}

				if (((double)fVal1 >= dMinTps) && ((double)fVal1 <= dMaxTps)){
					//CHECK_TAB_INDEX("107", i, 0, 5000)
					ptstTabPression->dDuree[i] 	= (double)fVal1;
					ptstTabPression->bWarningDuree[i] = 0; 
				}
				else{
						//CHECK_TAB_INDEX("108", i, 0, 5000)
						// Prise de la valeur Minimum ou maximum
						if ((double)fVal1 < dMinTps)
							ptstTabPression->dDuree[i] = dMinTps;
						else
							ptstTabPression->dDuree[i] = dMaxTps;
						
						sprintf(sTemp, sMSG_ERR_PRESS_TIME, i+1, fVal1, iLineNb, dMinTps, dMaxTps);
						ADD_MSG(iNbMsg, sTemp, sErrorMsg, iSizeMaxErrMsg)
			
						ptstTabPression->bWarningDuree[i] = 1; 
					}				

				dVal = (double)fVal2;
				if (iErreur == 0){
					if ((dVal >= dMinVal) && (dVal <= dMaxVal)){ 
						//CHECK_TAB_INDEX("109", i, 0, 5000)
						ptstTabPression->dPress[i] = dVal;
						ptstTabPression->bWarningData[i] = 0;
					}
					else{
							//CHECK_TAB_INDEX("110", i, 0, 5000)							
							// Prise de la valeur Minimum ou maximum
							if (dVal < dMinVal)
								ptstTabPression->dPress[i] = dMinVal;
							else
								ptstTabPression->dPress[i] = dMaxVal;

							sprintf(sTemp, sMSG_ERR_PRESS_DATA, i+1, dVal, iLineNb, dMinVal, dMaxVal);
							ADD_MSG(iNbMsg, sTemp, sErrorMsg, iSizeMaxErrMsg)
							
							ptstTabPression->bWarningData[i] = 1; 
						}				
				}
				
				// Incr�mentation du nombre de lignes lues
				i++; 
			}
		}while((strlen (sLine) > 1) && (iErreur == 0));
		
		//CHECK_TAB_INDEX("111", i, 0, 5000)
		// Mise � jour du nombre de pressions lues
		ptstTabPression->iNbElmts = i;
		
		// Retour s'il y a une erreur
		if (iErreur) return iErreur;

		
	
		// Lecture du nombre de cycles pression
		READ_BUFF_IN_FILE(sLine) 
		if(sscanf(sLine, sNB_CYC_PRESS, ptiNbreCyclesPress)!=1){
			sprintf(sTemp, sMSG_ERR_READ_NB_PRESS_CYC, iLineNb, sLine);
			ADD_MSG(iNbMsg, sTemp, sErrorMsg, iSizeMaxErrMsg)
			return -1;
		}		
		
		// Lecture du titre des commentaires
		READ_BUFF_IN_FILE(sLine)
		READ_BUFF_IN_FILE(sLine)
			
		// Lecture des commentaires
		READ_BUFF_IN_FILE(sLine) 
		if(sscanf(sLine, "NbLinesComments=%d", &iNbLines) != 1)
			iNbLines = 0;

		if ((iNbLines > 0) && (iNbLines < 100)){
			SetCtrlAttribute (iPanel, PANEL_MODE_COMMENTAIRES, ATTR_ENTER_IS_NEWLINE, 0);
			// Lecture de la premi�re ligne
			READ_BUFF_IN_FILE(sLine) 
			// Reset de la zone de commentaires
			ResetTextBox (iPanel, PANEL_MODE_COMMENTAIRES, sLine);

			// Mise � jour de la zone de commentaires
			for(i = 1; i < iNbLines; i++){
				READ_BUFF_IN_FILE(sLine) 
				iErreur = InsertTextBoxLine (iPanel, PANEL_MODE_COMMENTAIRES, i, sLine);
			}

			DeleteTextBoxLine (iPanel, PANEL_MODE_COMMENTAIRES, iNbLines);
		}
		else
			// Reset de la zone de commentaires
			ResetTextBox (iPanel, PANEL_MODE_COMMENTAIRES, "");

		
		// Fermeture du fichier
		fclose(hFile);
	}
	else{
		    //ENOMEM - insufficient memory.
		    //EMFILE - FOPEN_MAX files open already.
		    //EINVAL - filename is NULL or contains only whitespace.
		    //EINVAL - invalid mode.
			switch(errno){
				case ENOMEM:
					sprintf(sTemp, sERR_OPEN_FILE_INSUFF_MEM, sFileName, errno);
				break;
				case EMFILE:
					sprintf(sTemp, sERR_OPEN_FILE_ALR_OPEN, sFileName, errno, FOPEN_MAX);
				break;
				case EINVAL:
					sprintf(sTemp, sERR_OPEN_FILE_NULL, sFileName, errno);
				break;
			}
			
			ADD_MSG(iNbMsg, sTemp, sErrorMsg, iSizeMaxErrMsg)
			return -1;
		}	
	
	
	if(strlen(sErrorMsg) > 0)
			return 2;
	return 0; //OK  
}
	 
// DEBUT ALGO
//****************************************************************************** 
// int GstFilesTraductIhmModes(int iPanel, int iPopupMenuHandle, int iStatusPanel, 
//								int iUnitVitesse, int iUnitPression)
//****************************************************************************** 
//	- int iPanel			: Handle du panel 
//	  int iPopupMenuHandle  : Handle du menu popup
//	  int iStatusPanel		: Handle du panel de status
//	  int iUnitVitesse		: Unit� s�lectionn�e pour la vitesse
//	  int iUnitPression		: Unit� s�lectionn�e pour la pression
//
//  - Traduction de l'IHM des modes Automatique/Manuel
//
//  - 0 si Ok
//	  -1 sinon
//****************************************************************************** 
// FIN ALGO
int GstFilesTraductIhmModes(int iPanel, int iPopupMenuHandle, int iStatusPanel, 
							int iUnitVitesse, int iUnitPression)
{
int iErr;  

	// Traduction du menu principal
	/*iErr = SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_CONFIG, 				ATTR_MENU_NAME, sCONFIG);  //Modif MaximePAGES 09/09/2020
	iErr = SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_CONFIG_CHARGER, 		ATTR_ITEM_NAME, sCONFIG_LOAD);
	iErr = SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_CONFIG_ENREGISTRER, 	ATTR_ITEM_NAME, sCONFIG_SAVE);
	iErr = SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_MODE_AUTOMATIQUE, 		ATTR_MENU_NAME, sAUTO_MODE);
	iErr = SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_MODE_MANUEL, 			ATTR_MENU_NAME, sMANU_MODE);*/
	iErr = SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_QUITTER, 				ATTR_MENU_NAME, sQUIT);
  

	// Traduction du menu Popup
	iErr = SetMenuBarAttribute (iPopupMenuHandle, GST_TAB_GST_ADD_1, 		ATTR_ITEM_NAME, sPOPUP_MENU_AJOUTER);
	iErr = SetMenuBarAttribute (iPopupMenuHandle, GST_TAB_GST_SUPPR, 		ATTR_ITEM_NAME, sPOPUP_MENU_SUPPRIMER);
	iErr = SetMenuBarAttribute (iPopupMenuHandle, GST_TAB_GST_COPIER, 		ATTR_ITEM_NAME, sPOPUP_MENU_COPIER);
	iErr = SetMenuBarAttribute (iPopupMenuHandle, GST_TAB_GST_COLLER, 		ATTR_ITEM_NAME, sPOPUP_MENU_COLLER);
	iErr = SetMenuBarAttribute (iPopupMenuHandle, GST_TAB_GST_INSERT, 		ATTR_ITEM_NAME, sPOPUP_MENU_INSERT);
	iErr = SetMenuBarAttribute (iPopupMenuHandle, GST_TAB_GST_AGRANDIR, 	ATTR_ITEM_NAME, sPOPUP_MENU_AGRANDIR);
	iErr = SetMenuBarAttribute (iPopupMenuHandle, GST_TAB_GST_RESTAURER, 	ATTR_ITEM_NAME, sPOPUP_MENU_RESTAURER);
	
	
	// Mise � jour du titre de l'�cran d'accueil
 	iErr = SetPanelAttribute (iPanel, ATTR_TITLE, sTITRE_APPLICATION);


	// Traduction du titre du tableau des vitesses
	iErr = SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_VITESSES, ATTR_LABEL_TEXT, sTITLE_TAB_VIT);
	// Traduction du titre du tableau des pressions
	iErr = SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_PRESSION, ATTR_LABEL_TEXT, sTITLE_TAB_PRES);
	
	// Traduction des libell�s de la table des vitesses
	switch(iUnitVitesse){
		case iUNIT_KM_H:
			iErr = SetTableColumnAttribute (iPanel, PANEL_MODE_TABLE_VITESSES, 1, ATTR_LABEL_TEXT, sUNIT_VIT_KM_H);
		break;
		case iUNIT_G:
			iErr = SetTableColumnAttribute (iPanel, PANEL_MODE_TABLE_VITESSES, 1, ATTR_LABEL_TEXT, sUNIT_VIT_G);		
		break;
		case iUNIT_TRS_MIN:
			iErr = SetTableColumnAttribute (iPanel, PANEL_MODE_TABLE_VITESSES, 1, ATTR_LABEL_TEXT, sUNIT_VIT_TRS_MIN);		
		break;
	}
	iErr = SetTableColumnAttribute (iPanel, PANEL_MODE_TABLE_VITESSES, 2, ATTR_LABEL_TEXT, sUNIT_DUREE);		


	// Traduction des libell�s de la table des pressions
	switch(iUnitPression){
		case iUNIT_KPA:
			iErr = SetTableColumnAttribute (iPanel, PANEL_MODE_TABLE_PRESSION, 1, ATTR_LABEL_TEXT, sUNIT_PRES_KPA);
		break;
		case iUNIT_BAR:
			iErr = SetTableColumnAttribute (iPanel, PANEL_MODE_TABLE_PRESSION, 1, ATTR_LABEL_TEXT, sUNIT_PRES_BAR);
		break;
		case iUNIT_MBAR:
			iErr = SetTableColumnAttribute (iPanel, PANEL_MODE_TABLE_PRESSION, 1, ATTR_LABEL_TEXT, sUNIT_PRES_MBAR);
		break;
		case iUNIT_PSI:
			iErr = SetTableColumnAttribute (iPanel, PANEL_MODE_TABLE_PRESSION, 1, ATTR_LABEL_TEXT, sUNIT_PRES_PSI);
		break;
	}
	iErr = SetTableColumnAttribute (iPanel, PANEL_MODE_TABLE_PRESSION, 2, ATTR_LABEL_TEXT, sUNIT_DUREE);		


	// Traduction du bouton de D�part cycle vitesses
	iErr = SetCtrlAttribute (iPanel, PANEL_MODE_BUTT_START_VITESSE, ATTR_LABEL_TEXT, sBOUTON_DEP_VIT);
	// Traduction du bouton de D�part cycle pressions
	iErr = SetCtrlAttribute (iPanel, PANEL_MODE_BUT_START_PRESSION, ATTR_LABEL_TEXT, sBOUTON_DEP_PRES);
	// Traduction du bouton de D�part cycle vitesses et pressions
	iErr = SetCtrlAttribute (iPanel, PANEL_MODE_BUTT_START_VIT_PRESS, ATTR_LABEL_TEXT, sBOUTON_DEP_VIT_PRES);


	// Libell�s choix nbre cycles
	iErr = SetCtrlAttribute (iPanel, PANEL_MODE_NBE_CYCLES_VITESSE,  ATTR_LABEL_TEXT, sNBRE_CYCLES);
	iErr = SetCtrlAttribute (iPanel, PANEL_MODE_NBE_CYCLES_PRESSION, ATTR_LABEL_TEXT, sNBRE_CYCLES);

	// Libelles Cycle N�
	iErr = SetCtrlAttribute (iPanel, PANEL_MODE_NUM_CYCLE_VITESSE,  ATTR_LABEL_TEXT, sNUM_CYCLE);
	iErr = SetCtrlAttribute (iPanel, PANEL_MODE_NUM_CYCLE_PRESSION, ATTR_LABEL_TEXT, sNUM_CYCLE);
	
	// Traduction des affichages de vitesse
	switch(iUnitVitesse){
		case iUNIT_KM_H:
			iErr = SetCtrlAttribute (iPanel, PANEL_MODE_AFFICH_VITESSE, 	ATTR_LABEL_TEXT, sAFFICH_VITESSE_KM_H);
			iErr = SetCtrlAttribute (iPanel, PANEL_MODE_SAISIE_VITESSE_MANU,ATTR_LABEL_TEXT, sAFFICH_VITESSE_KM_H);
			iErr = SetCtrlAttribute (iStatusPanel, PANEL_STAT_SPEED, 		ATTR_LABEL_TEXT, sAFFICH_VITESSE_KM_H);
		break;
		case iUNIT_G:
			iErr = SetCtrlAttribute (iPanel, PANEL_MODE_AFFICH_VITESSE, 	ATTR_LABEL_TEXT, sAFFICH_VITESSE_G);
			iErr = SetCtrlAttribute (iPanel, PANEL_MODE_SAISIE_VITESSE_MANU,ATTR_LABEL_TEXT, sAFFICH_VITESSE_G);
			iErr = SetCtrlAttribute (iStatusPanel, PANEL_STAT_SPEED, 		ATTR_LABEL_TEXT, sAFFICH_VITESSE_G);
		break;
		case iUNIT_TRS_MIN:
			iErr = SetCtrlAttribute (iPanel, PANEL_MODE_AFFICH_VITESSE, 	ATTR_LABEL_TEXT, sAFFICH_VITESSE_TRS_MIN);
			iErr = SetCtrlAttribute (iPanel, PANEL_MODE_SAISIE_VITESSE_MANU,ATTR_LABEL_TEXT, sAFFICH_VITESSE_TRS_MIN);
			iErr = SetCtrlAttribute (iStatusPanel, PANEL_STAT_SPEED, 		ATTR_LABEL_TEXT, sAFFICH_VITESSE_TRS_MIN);
		break;
	}
	iErr = SetCtrlAttribute (iPanel, PANEL_MODE_AFFICH_TPS_VIT, 		ATTR_LABEL_TEXT, sAFFICH_TEMPS);
	iErr = SetCtrlAttribute (iPanel, PANEL_MODE_SAISIE_DUREE_VIT_MANU, 	ATTR_LABEL_TEXT, sAFFICH_TEMPS);
	
	// Traduction des affichages de pression
	switch(iUnitPression){
		case iUNIT_KPA:
			iErr = SetCtrlAttribute (iPanel, PANEL_MODE_AFFICH_PRESS, 			ATTR_LABEL_TEXT, sAFFICH_PRES_KPA);
			iErr = SetCtrlAttribute (iPanel, PANEL_MODE_SAISIE_PRESSION_MANU, 	ATTR_LABEL_TEXT, sAFFICH_PRES_KPA);
			iErr = SetCtrlAttribute (iStatusPanel, PANEL_STAT_PRESSURE, 		ATTR_LABEL_TEXT, sAFFICH_PRES_KPA);
		break;
		case iUNIT_BAR:
			iErr = SetCtrlAttribute (iPanel, PANEL_MODE_AFFICH_PRESS, 			ATTR_LABEL_TEXT, sAFFICH_PRES_BARS);
			iErr = SetCtrlAttribute (iPanel, PANEL_MODE_SAISIE_PRESSION_MANU, 	ATTR_LABEL_TEXT, sAFFICH_PRES_BARS);
			iErr = SetCtrlAttribute (iStatusPanel, PANEL_STAT_PRESSURE, 		ATTR_LABEL_TEXT, sAFFICH_PRES_BARS);
		break;
		case iUNIT_MBAR:
			iErr = SetCtrlAttribute (iPanel, PANEL_MODE_AFFICH_PRESS, 			ATTR_LABEL_TEXT, sAFFICH_PRES_MBAR);
			iErr = SetCtrlAttribute (iPanel, PANEL_MODE_SAISIE_PRESSION_MANU, 	ATTR_LABEL_TEXT, sAFFICH_PRES_MBAR);
			iErr = SetCtrlAttribute (iStatusPanel, PANEL_STAT_PRESSURE, 		ATTR_LABEL_TEXT, sAFFICH_PRES_MBAR);
		break;
		case iUNIT_PSI:
			iErr = SetCtrlAttribute (iPanel, PANEL_MODE_AFFICH_PRESS, 			ATTR_LABEL_TEXT, sAFFICH_PRES_PSI);
			iErr = SetCtrlAttribute (iPanel, PANEL_MODE_SAISIE_PRESSION_MANU, 	ATTR_LABEL_TEXT, sAFFICH_PRES_PSI);
			iErr = SetCtrlAttribute (iStatusPanel, PANEL_STAT_PRESSURE, 		ATTR_LABEL_TEXT, sAFFICH_PRES_PSI);
		break;
	}
	iErr = SetCtrlAttribute (iPanel, PANEL_MODE_AFFICH_TPS_PRESS, 		ATTR_LABEL_TEXT, sAFFICH_TEMPS);
	iErr = SetCtrlAttribute (iPanel, PANEL_MODE_SAISIE_DUREE_PRES_MAN, 	ATTR_LABEL_TEXT, sAFFICH_TEMPS);
	
	// Traduction des libell�s du graphique des vitesses
	iErr = SetCtrlAttribute (iPanel, PANEL_MODE_GRAPHE_VITESSE, ATTR_XNAME, sAFFICH_TEMPS);
	switch(iUnitVitesse){
		case iUNIT_KM_H:
			iErr = SetCtrlAttribute (iPanel, PANEL_MODE_GRAPHE_VITESSE, ATTR_YNAME, sAFFICH_VITESSE_KM_H);
		break;
		case iUNIT_G:
			iErr = SetCtrlAttribute (iPanel, PANEL_MODE_GRAPHE_VITESSE, ATTR_YNAME, sAFFICH_VITESSE_G);
		break;
		case iUNIT_TRS_MIN:
			iErr = SetCtrlAttribute (iPanel, PANEL_MODE_GRAPHE_VITESSE, ATTR_YNAME, sAFFICH_VITESSE_TRS_MIN);
		break;
	}	
	
	// Traduction des libell�s des pressions
	iErr = SetCtrlAttribute (iPanel, PANEL_MODE_GRAPHE_PRESSION, ATTR_XNAME, sAFFICH_TEMPS);
	switch(iUnitPression){
		case iUNIT_KPA:
			iErr = SetCtrlAttribute (iPanel, PANEL_MODE_GRAPHE_PRESSION, ATTR_YNAME, sAFFICH_PRES_KPA);
		break;
		case iUNIT_BAR:
			iErr = SetCtrlAttribute (iPanel, PANEL_MODE_GRAPHE_PRESSION, ATTR_YNAME, sAFFICH_PRES_BARS);
		break;
		case iUNIT_MBAR:
			iErr = SetCtrlAttribute (iPanel, PANEL_MODE_GRAPHE_PRESSION, ATTR_YNAME, sAFFICH_PRES_MBAR);
		break;
		case iUNIT_PSI:
			iErr = SetCtrlAttribute (iPanel, PANEL_MODE_GRAPHE_PRESSION, ATTR_YNAME, sAFFICH_PRES_PSI);
		break;
	}
	
	
	// Traduction du titre de la zone de message
	iErr = SetCtrlAttribute (iPanel, PANEL_MODE_MESSAGES_MODE, ATTR_LABEL_TEXT, sTITRE_ZONE_MSG);

	// Traduction du titre de la zone de commentaires
	iErr = SetCtrlAttribute (iPanel, PANEL_MODE_COMMENTAIRES, ATTR_LABEL_TEXT, sTITRE_COMMENTAIRES);

	return 0;
}

// DEBUT ALGO
//****************************************************************************** 
// int GstFilesReadConfigFile(char *sPathName, stConfig *ptstConfig, char *ErrorMsg)
//****************************************************************************** 
//	- char *sPathName		: Chemin complet vers le fichier de configuration
//	  stConfig *ptstConfig	: Pointeur vers la structure des param�tres de configuration
//	  char *ErrorMsg		: Vide ou Message d'erreur
//
//  - Lecture du fichier de configuration
//
//  - 0 si Ok
//	  -1 sinon
//****************************************************************************** 
// FIN ALGO
int GstFilesReadConfigFile(char *sPathName, stConfig *ptstConfig, char *ErrorMsg)
{
#define READ_INT_INI_FILE(sSection, sTag, iDfltVal, ptiVal)				\
{																		\
	GetIntIniFile(sSection, sTag, iDfltVal, ptiVal, sPathName);			\
	if(*ptiVal == iDfltVal){											\
		sprintf(ErrorMsg, sMSG_ERR_READ_CFG_FILE, sSection, sTag);  	\
		return 1;														\
	}																	\
}

#define READ_DOUBLE_INI_FILE(sSection, sTag, dDfltVal, ptdVal)			\
{																		\
	GetDoubleIniFile(sSection, sTag, dDfltVal, ptdVal, sPathName);		\
	if(*ptdVal == dDfltVal){											\
		sprintf(ErrorMsg, sMSG_ERR_READ_CFG_FILE, sSection, sTag);  	\
		return 1;														\
	}																	\
}

int iValue;
double dValue;


	// Raz du message d'erreur
	strcpy(ErrorMsg, "");

	// Lecture de l'unit� de vitesse
	READ_INT_INI_FILE(sSECTION_SPEED, sTAG_SPEED_UNIT, -1, &iValue)
	ptstConfig->iSpeedUnit = iValue;
					   
	// Lecture du port de communication avec le variateur
	READ_INT_INI_FILE(sSECTION_SPEED, sTAG_ENGINE_COM_PORT, -1, &iValue)
	ptstConfig->iSpeedComPort = iValue;
	
	// Lecture de la vitesse de communication avec le variateur
	READ_INT_INI_FILE(sSECTION_SPEED, sTAG_ENGINE_COM_SPEED, -1, &iValue)
	ptstConfig->iSpeedComSpeed = iValue;
	
	// Lecture de l'unit� de pression
	READ_INT_INI_FILE(sSECTION_PRESSURE, sTAG_PRESSURE_UNIT, -1, &iValue)
	ptstConfig->iPressUnit = iValue;

	// Lecture du temps d'attente entre deux commandes de pression
	READ_INT_INI_FILE(sSECTION_PRESSURE, sTAG_PRESSURE_COMMAND_DELAY, -1, &iValue)
	ptstConfig->iPressCommandDelay = iValue;

	// Lecture du temps d'attente entre deux commandes de vitesse (sp�cifique � l'acc�l�ration en g)
	READ_INT_INI_FILE(sSECTION_SPEED, sTAG_ACCELL_COMMAND_DELAY, -1, &iValue)
	ptstConfig->iAccelGCmdeDelay = iValue;	
	
	// Lecture du temps d'attente entre deux lectures de pression et vitesse
	READ_INT_INI_FILE(sSECTION_COMMON, sTAG_READ_DELAY, -1, &iValue)
	ptstConfig->iReadDelay = iValue;
	

	//-- Coefficients de conversion Vitesse --
	// Lecture du coefficient A de conversion km/h * A + B => trs/min
	READ_DOUBLE_INI_FILE(sSECTION_SPEED, sTAG_COEFF_A_KM_H, 0.0, &dValue)
	ptstConfig->dCoeffAKmH = dValue;

	// Lecture du coefficient B de conversion km/h * A + B => trs/min
	READ_DOUBLE_INI_FILE(sSECTION_SPEED, sTAG_COEFF_B_KM_H, -123456789.0, &dValue)
	ptstConfig->dCoeffBKmH = dValue;
	
	// Lecture du coefficient A de conversion g * A + B => trs/min   
	READ_DOUBLE_INI_FILE(sSECTION_SPEED, sTAG_COEFF_A_G, 0.0, &dValue)
	ptstConfig->dCoeffAG = dValue;

	// Lecture du coefficient B de conversion g * A + B => trs/min   
	READ_DOUBLE_INI_FILE(sSECTION_SPEED, sTAG_COEFF_B_G, -123456789.0, &dValue)
	ptstConfig->dCoeffBG = dValue;


	//-- Coefficients de conversion Pression --  
	// Lecture du coefficient A de conversion Kpa * A + B => bars  
	READ_DOUBLE_INI_FILE(sSECTION_PRESSURE, sTAG_COEFF_A_KPA, 0.0, &dValue)
	ptstConfig->dCoeffAKpa = dValue;

	// Lecture du coefficient B de conversion Kpa * A + B => bars   
	READ_DOUBLE_INI_FILE(sSECTION_PRESSURE, sTAG_COEFF_B_KPA, -123456789.0, &dValue)
	ptstConfig->dCoeffBKpa = dValue;
	
	// Lecture du coefficient A de conversion Psi * A + B => bars 
	READ_DOUBLE_INI_FILE(sSECTION_PRESSURE, sTAG_COEFF_A_PSI, 0.0, &dValue)
	ptstConfig->dCoeffAPsi = dValue;

	// Lecture du coefficient B de conversion Psi * A + B => bars  
	READ_DOUBLE_INI_FILE(sSECTION_PRESSURE, sTAG_COEFF_B_PSI, -123456789.0, &dValue)
	ptstConfig->dCoeffBPsi = dValue;
	 
	// Lecture du coefficient A de conversion Mbar * A + B => bars
	READ_DOUBLE_INI_FILE(sSECTION_PRESSURE, sTAG_COEFF_A_MBAR, 0.0, &dValue)
	ptstConfig->dCoeffAMbar = dValue;

	// Lecture du coefficient B de conversion PMbar * A + B => bars 
	READ_DOUBLE_INI_FILE(sSECTION_PRESSURE, sTAG_COEFF_B_MBAR, -123456789.0, &dValue)
	ptstConfig->dCoeffBMbar = dValue;	

	
	//-- Limites des saisies de Vitesse --
	// Lecture du min vitesse en km/h
	READ_DOUBLE_INI_FILE(sSECTION_SPEED, sTAG_LIM_MIN_KM_H, -123456789.0, &dValue)
	ptstConfig->dLimMinKmH = dValue;

	// Lecture du max vitesse en km/h
	READ_DOUBLE_INI_FILE(sSECTION_SPEED, sTAG_LIM_MAX_KM_H, 123456789.0, &dValue)
	ptstConfig->dLimMaxKmH = dValue;
	
	// Lecture du min acc�l�ration en g  
	READ_DOUBLE_INI_FILE(sSECTION_SPEED, sTAG_LIM_MIN_G, -123456789.0, &dValue)
	ptstConfig->dLimMinG = dValue;

	// Lecture du max acc�l�ration en g 
	READ_DOUBLE_INI_FILE(sSECTION_SPEED, sTAG_LIM_MAX_G, 123456789.0, &dValue)
	ptstConfig->dLimMaxG = dValue;

	// Lecture du min acc�l�ration en trs/min  
	READ_DOUBLE_INI_FILE(sSECTION_SPEED, sTAG_LIM_MIN_TRS_MIN, -123456789.0, &dValue)
	ptstConfig->dLimMinTrsMin = dValue;

	// Lecture du max acc�l�ration en trs/min 
	READ_DOUBLE_INI_FILE(sSECTION_SPEED, sTAG_LIM_MAX_TRS_MIN, 123456789.0, &dValue)
	ptstConfig->dLimMaxTrsMin = dValue;
	
	
	
	// Lecture de la dur�e min pour un step de vitesse
	READ_DOUBLE_INI_FILE(sSECTION_SPEED, sTAG_LIM_MIN_SPEED_DURAT, -123456789.0, &dValue)
	ptstConfig->dLimMinTpsSpeed = dValue;

	// Lecture de la dur�e max pour un step de vitesse   
	READ_DOUBLE_INI_FILE(sSECTION_SPEED, sTAG_LIM_MAX_SPEED_DURAT, 123456789.0, &dValue)
	ptstConfig->dLimMaxTpsSpeed = dValue;
	

	//-- Limites des saisies de Pression --  
	// Lecture du min pression en Kpa
	READ_DOUBLE_INI_FILE(sSECTION_PRESSURE, sTAG_LIM_MIN_KPA, -123456789.0, &dValue)
	ptstConfig->dLimMinKpa = dValue;

	// Lecture du max pression en Kpa   
	READ_DOUBLE_INI_FILE(sSECTION_PRESSURE, sTAG_LIM_MAX_KPA, 123456789.0, &dValue)
	ptstConfig->dLimMaxKpa = dValue;
	
	// Lecture du min pression en Psi
	READ_DOUBLE_INI_FILE(sSECTION_PRESSURE, sTAG_LIM_MIN_PSI, -123456789.0, &dValue)
	ptstConfig->dLimMinPsi = dValue;

	// Lecture du max pression en Psi  
	READ_DOUBLE_INI_FILE(sSECTION_PRESSURE, sTAG_LIM_MAX_PSI, 123456789.0, &dValue)
	ptstConfig->dLimMaxPsi = dValue;
	 
	// Lecture du min pression en Mbar
	READ_DOUBLE_INI_FILE(sSECTION_PRESSURE, sTAG_LIM_MIN_MBAR, -123456789.0, &dValue)
	ptstConfig->dLimMinMbar = dValue;

	// Lecture du max pression en Mbar 
	READ_DOUBLE_INI_FILE(sSECTION_PRESSURE, sTAG_LIM_MAX_MBAR, 123456789.0, &dValue)
	ptstConfig->dLimMaxMbar = dValue;	
	
	// Lecture du min pression en Bar
	READ_DOUBLE_INI_FILE(sSECTION_PRESSURE, sTAG_LIM_MIN_BAR, -123456789.0, &dValue)
	ptstConfig->dLimMinBar = dValue;

	// Lecture du max pression en Bar 
	READ_DOUBLE_INI_FILE(sSECTION_PRESSURE, sTAG_LIM_MAX_BAR, 123456789.0, &dValue)
	ptstConfig->dLimMaxBar = dValue;	
		
	
	// Lecture de la dur�e min pour un step de pression
	READ_DOUBLE_INI_FILE(sSECTION_PRESSURE, sTAG_LIM_MIN_PRESS_DURAT, -123456789.0, &dValue)
	ptstConfig->dLimMinTpsPress = dValue;

	// Lecture de la dur�e max pour un step de pression   
	READ_DOUBLE_INI_FILE(sSECTION_PRESSURE, sTAG_LIM_MAX_PRESS_DURAT, 123456789.0, &dValue)
	ptstConfig->dLimMaxTpsPress = dValue;

	//------ Modification du 15/11/2010 par C.BERENGER ---- DEBUT ------------
	// Lecture de la plage maximum d'affichage en mode manuel
	READ_DOUBLE_INI_FILE(sSECTION_COMMON, sTAG_PLAGE_AFFICH_MANU, 123456789.0, &dValue)
	ptstConfig->dPlageAffichManu = dValue;

	// Lecture de l'unit� de pression
	READ_INT_INI_FILE(sSECTION_COMMON, sTAG_WATCHDOG, -1, &iValue)
	ptstConfig->iUseWatchdog = iValue;
	
	// Possibilit� de suaver ou non les r�sultats
	READ_INT_INI_FILE(sSECTION_COMMON, sTAG_SAVE_RESULTS, -1, &iValue)
	ptstConfig->iSaveResults = iValue;	
	//------ Modification du 15/11/2010 par C.BERENGER ---- FIN ------------
	
	return 0; // OK
}

