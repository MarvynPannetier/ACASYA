// CVI wrapper source file for .NET assembly: WuAutoCheck, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null

#include "DotNetDll.h"
#include <stdarg.h>

// Macros
#ifndef __errChk
#define __errChk(f) if (__error = (f), __error < 0) goto __Error; else
#endif
#ifndef __nullChk
#define __nullChk(p) if (!(p)) { __error = CDotNetOutOfMemoryError; goto __Error; } else
#endif

// Constants
static const char * __assemblyName = "WuAutoCheck, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null";

// Static Variables
static CDotNetAssemblyHandle __assemblyHandle = 0;

// Forward declarations
static void _CDotNetGenDisposeScalar(void * scalar, unsigned int typeId);
static void CVIFUNC_C _CDotNetGenDisposeArray(void * array, unsigned int typeId, size_t nDims, ...);


// Global Functions
int CVIFUNC Initialize_WuAutoCheck(void)
{
	int __error = 0;


	if (__assemblyHandle == 0)
		__errChk(CDotNetLoadAssembly(
			__assemblyName, 
			&__assemblyHandle));



__Error:
	return __error;
}

int CVIFUNC Close_WuAutoCheck(void)
{
	int __error = 0;


	if (__assemblyHandle) {
		__errChk(CDotNetDiscardAssemblyHandle(__assemblyHandle));
		__assemblyHandle = 0;
	}



__Error:
	return __error;
}


// Type: WuAutoCheck.WU_Automation_Test_and_Folder_Manager
int CVIFUNC WuAutoCheck_WU_Automation_Test_and_Folder_Manager__Create(
	WuAutoCheck_WU_Automation_Test_and_Folder_Manager * __instance,
	CDotNetHandle * __exception)
{
	int __error = 0;

	if (__exception)
		*__exception = 0;


	*__instance = 0;

	// Call constructor
	__errChk(CDotNetCreateGenericInstance(
		__assemblyHandle, 
		"WuAutoCheck.WU_Automation_Test_and_Folder_Manager", 
		0, 
		0, 
		__instance, 
		0, 
		0, 
		0, 
		0, 
		__exception));


__Error:
	return __error;
}

int CVIFUNC WuAutoCheck_WU_Automation_Test_and_Folder_Manager_InitInterface(
	WuAutoCheck_WU_Automation_Test_and_Folder_Manager __instance,
	char * LogsCheckDirPath,
	char * LogsStorageDirPath,
	char * ConfigFilePath,
	char * ANumConfigFileNamePath,
	unsigned int PressU,
	unsigned int AccU,
	double WheelDimension,
	CDotNetHandle * __exception)
{
	int __error = 0;
	char * __parameterTypeNames[7] = {0};
	unsigned int __parameterTypes[7];
	void * __parameters[7];

	if (__exception)
		*__exception = 0;


	// Pre-process parameter: LogsCheckDirPath
	__parameterTypeNames[0] = "System.String";
	__parameterTypes[0] = (CDOTNET_STRING);
	__parameters[0] = &LogsCheckDirPath;

	// Pre-process parameter: LogsStorageDirPath
	__parameterTypeNames[1] = "System.String";
	__parameterTypes[1] = (CDOTNET_STRING);
	__parameters[1] = &LogsStorageDirPath;

	// Pre-process parameter: ConfigFilePath
	__parameterTypeNames[2] = "System.String";
	__parameterTypes[2] = (CDOTNET_STRING);
	__parameters[2] = &ConfigFilePath;

	// Pre-process parameter: ANumConfigFileNamePath
	__parameterTypeNames[3] = "System.String";
	__parameterTypes[3] = (CDOTNET_STRING);
	__parameters[3] = &ANumConfigFileNamePath;

	// Pre-process parameter: PressU
	__parameterTypeNames[4] = "System.UInt32";
	__parameterTypes[4] = (CDOTNET_UINT32);
	__parameters[4] = &PressU;

	// Pre-process parameter: AccU
	__parameterTypeNames[5] = "System.UInt32";
	__parameterTypes[5] = (CDOTNET_UINT32);
	__parameters[5] = &AccU;

	// Pre-process parameter: WheelDimension
	__parameterTypeNames[6] = "System.Double";
	__parameterTypes[6] = (CDOTNET_DOUBLE);
	__parameters[6] = &WheelDimension;

	// Call instance member
	__errChk(CDotNetInvokeGenericMember(
		__assemblyHandle, 
		"WuAutoCheck.WU_Automation_Test_and_Folder_Manager", 
		__instance, 
		CDOTNET_CALL_METHOD, 
		"InitInterface", 
		0, 
		0, 
		7, 
		(const char **)__parameterTypeNames, 
		__parameterTypes, 
		__parameters, 
		0, 
		0, 
		__exception));


__Error:
	return __error;
}

int CVIFUNC WuAutoCheck_WU_Automation_Test_and_Folder_Manager_GenerateTestFile(
	WuAutoCheck_WU_Automation_Test_and_Folder_Manager __instance,
	char * TestPath,
	unsigned int testRep,
	char ** BenchTest,
	int * CheckValidity,
	WuAutoCheck_LFComand ** __returnValue,
	ssize_t * ____returnValueLength,
	CDotNetHandle * __exception)
{
	int __error = 0;
	char * __parameterTypeNames[4] = {0};
	unsigned int __parameterTypes[4];
	void * __parameters[4];
	CDotNetHandle __returnValue__ = 0;
	unsigned int __returnValueTypeId;

	if (__exception)
		*__exception = 0;
	*BenchTest = 0;
	if (__returnValue)
		*__returnValue = 0;
	if (__returnValue)
		*____returnValueLength = 0;


	// Pre-process parameter: TestPath
	__parameterTypeNames[0] = "System.String";
	__parameterTypes[0] = (CDOTNET_STRING);
	__parameters[0] = &TestPath;

	// Pre-process parameter: testRep
	__parameterTypeNames[1] = "System.UInt32";
	__parameterTypes[1] = (CDOTNET_UINT32);
	__parameters[1] = &testRep;

	// Pre-process parameter: BenchTest
	__parameterTypeNames[2] = "System.String&";
	__parameterTypes[2] = (CDOTNET_STRING | CDOTNET_OUT);
	__parameters[2] = BenchTest;

	// Pre-process parameter: CheckValidity
	__parameterTypeNames[3] = "System.Int32&";
	__parameterTypes[3] = (CDOTNET_INT32 | CDOTNET_OUT);
	__parameters[3] = CheckValidity;

	// Pre-process return value
	__returnValueTypeId = CDOTNET_STRUCT | CDOTNET_ARRAY;

	// Call instance member
	__errChk(CDotNetInvokeGenericMember(
		__assemblyHandle, 
		"WuAutoCheck.WU_Automation_Test_and_Folder_Manager", 
		__instance, 
		CDOTNET_CALL_METHOD, 
		"GenerateTestFile", 
		0, 
		0, 
		4, 
		(const char **)__parameterTypeNames, 
		__parameterTypes, 
		__parameters, 
		&__returnValueTypeId, 
		&__returnValue__, 
		__exception));

	// Post-process return value
	if (__returnValue__) {
		if (__returnValue)
			__errChk(CDotNetGetArrayElements(
				__returnValue__, 
				CDOTNET_STRUCT, 
				0, 
				__returnValue));
		if (__returnValue)
			__errChk(CDotNetGetArrayLength(
				__returnValue__, 
				0, 
				____returnValueLength));
	}


__Error:
	if (__returnValue__)
		CDotNetDiscardHandle(__returnValue__);
	if (__error < 0) {
		_CDotNetGenDisposeScalar(
			BenchTest, 
			CDOTNET_STRING);
		_CDotNetGenDisposeArray(
			__returnValue, 
			CDOTNET_STRUCT, 
			1, 
			____returnValueLength);
	}
	return __error;
}

int CVIFUNC WuAutoCheck_WU_Automation_Test_and_Folder_Manager_CheckTest(
	WuAutoCheck_WU_Automation_Test_and_Folder_Manager __instance,
	int * ret,
	CDotNetHandle * __exception)
{
	int __error = 0;
	char * __parameterTypeNames[1] = {0};
	unsigned int __parameterTypes[1];
	void * __parameters[1];

	if (__exception)
		*__exception = 0;


	// Pre-process parameter: ret
	__parameterTypeNames[0] = "System.Int32&";
	__parameterTypes[0] = (CDOTNET_INT32 | CDOTNET_OUT);
	__parameters[0] = ret;

	// Call instance member
	__errChk(CDotNetInvokeGenericMember(
		__assemblyHandle, 
		"WuAutoCheck.WU_Automation_Test_and_Folder_Manager", 
		__instance, 
		CDOTNET_CALL_METHOD, 
		"CheckTest", 	   
		0, 
		0, 
		1, 
		(const char **)__parameterTypeNames, 
		__parameterTypes, 
		__parameters, 
		0, 
		0, 
		__exception));


__Error:
	return __error;
}

int CVIFUNC WuAutoCheck_WU_Automation_Test_and_Folder_Manager_CloseInterface(
	WuAutoCheck_WU_Automation_Test_and_Folder_Manager __instance,
	CDotNetHandle * __exception)
{
	int __error = 0;

	if (__exception)
		*__exception = 0;


	// Call instance member
	__errChk(CDotNetInvokeGenericMember(
		__assemblyHandle, 
		"WuAutoCheck.WU_Automation_Test_and_Folder_Manager", 
		__instance, 
		CDOTNET_CALL_METHOD, 
		"CloseInterface", 
		0, 
		0, 
		0, 
		0, 
		0, 
		0, 
		0, 
		0, 
		__exception));


__Error:
	return __error;
}


	
int CVIFUNC WuAutoCheck_WU_Automation_Test_and_Folder_Manager_AnalyzeTest(
	WuAutoCheck_WU_Automation_Test_and_Folder_Manager __instance,
	char * TestFolder,
	int KillExcelProcesses,
	int * ret,
	CDotNetHandle * __exception)
{
	int __error = 0;
	char * __parameterTypeNames[3] = {0};
	unsigned int __parameterTypes[3];
	void * __parameters[3];

	if (__exception)
		*__exception = 0;


	// Pre-process parameter: TestFolder
	__parameterTypeNames[0] = "System.String";
	__parameterTypes[0] = (CDOTNET_STRING);
	__parameters[0] = &TestFolder;

	// Pre-process parameter: KillExcelProcesses
	__parameterTypeNames[1] = "System.Boolean";
	__parameterTypes[1] = (CDOTNET_BOOLEAN);
	__parameters[1] = &KillExcelProcesses;

	// Pre-process parameter: ret
	__parameterTypeNames[2] = "System.Int32&";
	__parameterTypes[2] = (CDOTNET_INT32 | CDOTNET_OUT);
	__parameters[2] = ret;

	// Call instance member
	__errChk(CDotNetInvokeGenericMember(
		__assemblyHandle, 
		"WuAutoCheck.WU_Automation_Test_and_Folder_Manager", 
		__instance, 
		CDOTNET_CALL_METHOD, 
		"AnalyzeTest", 
		0, 
		0, 
		3, 
		(const char **)__parameterTypeNames, 
		__parameterTypes, 
		__parameters, 
		0, 
		0, 
		__exception));


__Error:
	return __error;
}

int CVIFUNC WuAutoCheck_WU_Automation_Test_and_Folder_Manager_CloseInterface_1(
	WuAutoCheck_WU_Automation_Test_and_Folder_Manager __instance,
	int KillExcelProcesses,
	CDotNetHandle * __exception)
{
	int __error = 0;
	char * __parameterTypeNames[1] = {0};
	unsigned int __parameterTypes[1];
	void * __parameters[1];

	if (__exception)
		*__exception = 0;


	// Pre-process parameter: KillExcelProcesses
	__parameterTypeNames[0] = "System.Boolean";
	__parameterTypes[0] = (CDOTNET_BOOLEAN);
	__parameters[0] = &KillExcelProcesses;

	// Call instance member
	__errChk(CDotNetInvokeGenericMember(
		__assemblyHandle, 
		"WuAutoCheck.WU_Automation_Test_and_Folder_Manager", 
		__instance, 
		CDOTNET_CALL_METHOD, 
		"CloseInterface", 
		0, 
		0, 
		1, 
		(const char **)__parameterTypeNames, 
		__parameterTypes, 
		__parameters, 
		0, 
		0, 
		__exception));


__Error:
	return __error;
}

int CVIFUNC WuAutoCheck_WU_Automation_Test_and_Folder_Manager_ReadTest(
	WuAutoCheck_WU_Automation_Test_and_Folder_Manager __instance,
	char * ConfigFilePath,
	char * TestFilePath,
	int * __returnValue,
	CDotNetHandle * __exception)
{
	int __error = 0;
	char * __parameterTypeNames[2] = {0};
	unsigned int __parameterTypes[2];
	void * __parameters[2];
	unsigned int __returnValueTypeId;

	if (__exception)
		*__exception = 0;


	// Pre-process parameter: ConfigFilePath
	__parameterTypeNames[0] = "System.String";
	__parameterTypes[0] = (CDOTNET_STRING);
	__parameters[0] = &ConfigFilePath;

	// Pre-process parameter: TestFilePath
	__parameterTypeNames[1] = "System.String";
	__parameterTypes[1] = (CDOTNET_STRING);
	__parameters[1] = &TestFilePath;

	// Pre-process return value
	__returnValueTypeId = CDOTNET_BOOLEAN;

	// Call instance member
	__errChk(CDotNetInvokeGenericMember(
		__assemblyHandle, 
		"WuAutoCheck.WU_Automation_Test_and_Folder_Manager", 
		__instance, 
		CDOTNET_CALL_METHOD, 
		"ReadTest", 
		0, 
		0, 
		2, 
		(const char **)__parameterTypeNames, 
		__parameterTypes, 
		__parameters, 
		&__returnValueTypeId, 
		__returnValue, 
		__exception));


__Error:
	return __error;
}

int CVIFUNC WuAutoCheck_WU_Automation_Test_and_Folder_Manager_CreateErrorLog(
	char * ErrorLogPath,
	System_Collections_Generic_List_T1 WriteLines,
	int append,
	CDotNetHandle * __exception)
{
	int __error = 0;
	char * __parameterTypeNames[3] = {0};
	unsigned int __parameterTypes[3];
	void * __parameters[3];

	if (__exception)
		*__exception = 0;


	// Pre-process parameter: ErrorLogPath
	__parameterTypeNames[0] = "System.String";
	__parameterTypes[0] = (CDOTNET_STRING);
	__parameters[0] = &ErrorLogPath;

	// Pre-process parameter: WriteLines
	__parameterTypeNames[1] = "System.Collections.Generic.List`1[[System.String, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]]";
	__parameterTypes[1] = (CDOTNET_OBJECT);
	__parameters[1] = &WriteLines;

	// Pre-process parameter: append
	__parameterTypeNames[2] = "System.Boolean";
	__parameterTypes[2] = (CDOTNET_BOOLEAN);
	__parameters[2] = &append;

	// Call static member
	__errChk(CDotNetInvokeGenericStaticMember(
		__assemblyHandle, 
		"WuAutoCheck.WU_Automation_Test_and_Folder_Manager", 
		0, 
		0, 
		CDOTNET_CALL_METHOD, 
		"CreateErrorLog", 
		0, 
		0, 
		3, 
		(const char **)__parameterTypeNames, 
		__parameterTypes, 
		__parameters, 
		0, 
		0, 
		__exception));


__Error:
	return __error;
}

int CVIFUNC WuAutoCheck_WU_Automation_Test_and_Folder_Manager__Get__DeleteFolders(
	WuAutoCheck_WU_Automation_Test_and_Folder_Manager __instance,
	int * __returnValue,
	CDotNetHandle * __exception)
{
	int __error = 0;
	unsigned int __returnValueTypeId;

	if (__exception)
		*__exception = 0;


	// Pre-process return value
	__returnValueTypeId = CDOTNET_BOOLEAN;

	// Call instance member
	__errChk(CDotNetInvokeGenericMember(
		__assemblyHandle, 
		"WuAutoCheck.WU_Automation_Test_and_Folder_Manager", 
		__instance, 
		CDOTNET_GET_FIELD, 
		"DeleteFolders", 
		0, 
		0, 
		0, 
		0, 
		0, 
		0, 
		&__returnValueTypeId, 
		__returnValue, 
		__exception));


__Error:
	return __error;
}

int CVIFUNC WuAutoCheck_WU_Automation_Test_and_Folder_Manager__Set__DeleteFolders(
	WuAutoCheck_WU_Automation_Test_and_Folder_Manager __instance,
	int DeleteFolders,
	CDotNetHandle * __exception)
{
	int __error = 0;
	char * __parameterTypeNames[1] = {0};  
	unsigned int __parameterTypes[1];
	void * __parameters[1];

	if (__exception)
		*__exception = 0;


	// Pre-process parameter: DeleteFolders
	__parameterTypeNames[0] = "System.Boolean";
	__parameterTypes[0] = (CDOTNET_BOOLEAN);
	__parameters[0] = &DeleteFolders;

	// Call instance member
	__errChk(CDotNetInvokeGenericMember(
		__assemblyHandle, 
		"WuAutoCheck.WU_Automation_Test_and_Folder_Manager", 
		__instance, 
		CDOTNET_SET_FIELD, 
		"DeleteFolders", 
		0, 
		0, 
		1, 
		(const char **)__parameterTypeNames, 
		__parameterTypes, 
		__parameters, 
		0, 
		0, 
		__exception));


__Error:
	return __error;
}


//  WuAutoCheck.getPathLog - Return the path of the directory created by the dll 
int CVIFUNC WuAutoCheck_WU_Automation_Test_and_Folder_Manager__getPathLog (
	WuAutoCheck_WU_Automation_Test_and_Folder_Manager instance_Handle,
	char **pathLogXML,
	CDotNetHandle *exceptionHandle)
{
	int __error = 0;
	char * __parameterTypeNames[1] = {0};   
	unsigned int __parameterTypes[1];
	void * __parameters[1];

	if (exceptionHandle)
		*exceptionHandle = 0;


	__parameterTypeNames[0] = "System.String&";
	__parameterTypes[0] = (CDOTNET_STRING | CDOTNET_OUT);
	__parameters[0] = pathLogXML;
	
	__errChk(CDotNetInvokeGenericMember(
			__assemblyHandle, 
			"WuAutoCheck.WU_Automation_Test_and_Folder_Manager", 
			instance_Handle, 
			CDOTNET_CALL_METHOD, 
			"getPathLog", 	   
			0,
			0, 
			1, 
			(const char **)__parameterTypeNames, 
			__parameterTypes, 
			__parameters, 
			0, 
			0, 
			exceptionHandle));
		

__Error:
	return __error; 
    
}

int CVIFUNC WuAutoCheck_LFComand__Get__Time(
	WuAutoCheck_LFComand __instance,
	double * __returnValue,
	CDotNetHandle * __exception)
{
	int __error = 0;
	unsigned int __returnValueTypeId;

	if (__exception)
		*__exception = 0;


	// Pre-process return value
	__returnValueTypeId = CDOTNET_DOUBLE;

	// Call instance member
	__errChk(CDotNetInvokeGenericMember(
		__assemblyHandle, 
		"WuAutoCheck.LFComand", 
		__instance, 
		CDOTNET_GET_FIELD, 
		"Time", 
		0, 
		0, 
		0, 
		0, 
		0, 
		0, 
		&__returnValueTypeId, 
		__returnValue, 
		__exception));


__Error:
	return __error;
}

int CVIFUNC WuAutoCheck_LFComand__Set__Time(
	WuAutoCheck_LFComand __instance,
	double Time,
	CDotNetHandle * __exception)
{
	int __error = 0;
	char * __parameterTypeNames[1] = {0};
	unsigned int __parameterTypes[1];
	void * __parameters[1];

	if (__exception)
		*__exception = 0;


	// Pre-process parameter: Time
	__parameterTypeNames[0] = "System.Double";
	__parameterTypes[0] = (CDOTNET_DOUBLE);
	__parameters[0] = &Time;

	// Call instance member
	__errChk(CDotNetInvokeGenericMember(
		__assemblyHandle, 
		"WuAutoCheck.LFComand", 
		__instance, 
		CDOTNET_SET_FIELD, 
		"Time", 
		0, 
		0, 
		1, 
		(const char **)__parameterTypeNames, 
		__parameterTypes, 
		__parameters, 
		0, 
		0, 
		__exception));


__Error:
	return __error;
}

int CVIFUNC WuAutoCheck_LFComand__Get__Command(
	WuAutoCheck_LFComand __instance,
	int * __returnValue,
	CDotNetHandle * __exception)
{
	int __error = 0;
	unsigned int __returnValueTypeId;

	if (__exception)
		*__exception = 0;


	// Pre-process return value
	__returnValueTypeId = CDOTNET_INT32;

	// Call instance member
	__errChk(CDotNetInvokeGenericMember(
		__assemblyHandle, 
		"WuAutoCheck.LFComand", 
		__instance, 
		CDOTNET_GET_FIELD, 
		"Command", 
		0, 
		0, 
		0, 
		0, 
		0, 
		0, 
		&__returnValueTypeId, 
		__returnValue, 
		__exception));


__Error:
	return __error;
}

int CVIFUNC WuAutoCheck_LFComand__Set__Command(
	WuAutoCheck_LFComand __instance,
	int Command,
	CDotNetHandle * __exception)
{
	int __error = 0;
	char * __parameterTypeNames[1] = {0};
	unsigned int __parameterTypes[1];
	void * __parameters[1];

	if (__exception)
		*__exception = 0;


	// Pre-process parameter: Command
	__parameterTypeNames[0] = "System.Int32";
	__parameterTypes[0] = (CDOTNET_INT32);
	__parameters[0] = &Command;

	// Call instance member
	__errChk(CDotNetInvokeGenericMember(
		__assemblyHandle, 
		"WuAutoCheck.LFComand", 
		__instance, 
		CDOTNET_SET_FIELD, 
		"Command", 
		0, 
		0, 
		1, 
		(const char **)__parameterTypeNames, 
		__parameterTypes, 
		__parameters, 
		0, 
		0, 
		__exception));


__Error:
	return __error;
}

int CVIFUNC WuAutoCheck_LFComand__Get__StrVal(
	WuAutoCheck_LFComand __instance,
	char ** __returnValue,
	CDotNetHandle * __exception)
{
	int __error = 0;
	unsigned int __returnValueTypeId;

	if (__exception)
		*__exception = 0;
	if (__returnValue)
		*__returnValue = 0;


	// Pre-process return value
	__returnValueTypeId = CDOTNET_STRING;

	// Call instance member
	__errChk(CDotNetInvokeGenericMember(
		__assemblyHandle, 
		"WuAutoCheck.LFComand", 
		__instance, 
		CDOTNET_GET_FIELD, 
		"StrVal", 
		0, 
		0, 
		0, 
		0, 
		0, 
		0, 
		&__returnValueTypeId, 
		__returnValue, 
		__exception));


__Error:
	if (__error < 0) {
		_CDotNetGenDisposeScalar(
			__returnValue, 
			CDOTNET_STRING);
	}
	return __error;
}

int CVIFUNC WuAutoCheck_LFComand__Set__StrVal(
	WuAutoCheck_LFComand __instance,
	char * StrVal,
	CDotNetHandle * __exception)
{
	int __error = 0;
	char * __parameterTypeNames[1] = {0};
	unsigned int __parameterTypes[1];
	void * __parameters[1];

	if (__exception)
		*__exception = 0;


	// Pre-process parameter: StrVal
	__parameterTypeNames[0] = "System.String";
	__parameterTypes[0] = (CDOTNET_STRING);
	__parameters[0] = &StrVal;

	// Call instance member
	__errChk(CDotNetInvokeGenericMember(
		__assemblyHandle, 
		"WuAutoCheck.LFComand", 
		__instance, 
		CDOTNET_SET_FIELD, 
		"StrVal", 
		0, 
		0, 
		1, 
		(const char **)__parameterTypeNames, 
		__parameterTypes, 
		__parameters, 
		0, 
		0, 
		__exception));


__Error:
	return __error;
}

int CVIFUNC WuAutoCheck_LFComand__Get__NumVal(
	WuAutoCheck_LFComand __instance,
	unsigned int * __returnValue,
	CDotNetHandle * __exception)
{
	int __error = 0;
	unsigned int __returnValueTypeId;

	if (__exception)
		*__exception = 0;


	// Pre-process return value
	__returnValueTypeId = CDOTNET_UINT32;

	// Call instance member
	__errChk(CDotNetInvokeGenericMember(
		__assemblyHandle, 
		"WuAutoCheck.LFComand", 
		__instance, 
		CDOTNET_GET_FIELD, 
		"NumVal", 
		0, 
		0, 
		0, 
		0, 
		0, 
		0, 
		&__returnValueTypeId, 
		__returnValue, 
		__exception));


__Error:
	return __error;
}

int CVIFUNC WuAutoCheck_LFComand__Set__NumVal(
	WuAutoCheck_LFComand __instance,
	unsigned int NumVal,
	CDotNetHandle * __exception)
{
	int __error = 0;
	char * __parameterTypeNames[1] = {0};
	unsigned int __parameterTypes[1];
	void * __parameters[1];

	if (__exception)
		*__exception = 0;


	// Pre-process parameter: NumVal
	__parameterTypeNames[0] = "System.UInt32";
	__parameterTypes[0] = (CDOTNET_UINT32);
	__parameters[0] = &NumVal;

	// Call instance member
	__errChk(CDotNetInvokeGenericMember(
		__assemblyHandle, 
		"WuAutoCheck.LFComand", 
		__instance, 
		CDOTNET_SET_FIELD, 
		"NumVal", 
		0, 
		0, 
		1, 
		(const char **)__parameterTypeNames, 
		__parameterTypes, 
		__parameters, 
		0, 
		0, 
		__exception));


__Error:
	return __error;
}

int CVIFUNC WuAutoCheck_LFComand__Get__Param(
	WuAutoCheck_LFComand __instance,
	unsigned int * __returnValue,
	CDotNetHandle * __exception)
{
	int __error = 0;
	unsigned int __returnValueTypeId;

	if (__exception)
		*__exception = 0;


	// Pre-process return value
	__returnValueTypeId = CDOTNET_UINT32;

	// Call instance member
	__errChk(CDotNetInvokeGenericMember(
		__assemblyHandle, 
		"WuAutoCheck.LFComand", 
		__instance, 
		CDOTNET_GET_FIELD, 
		"Param", 
		0, 
		0, 
		0, 
		0, 
		0, 
		0, 
		&__returnValueTypeId, 
		__returnValue, 
		__exception));


__Error:
	return __error;
}

int CVIFUNC WuAutoCheck_LFComand__Set__Param(
	WuAutoCheck_LFComand __instance,
	unsigned int Param,
	CDotNetHandle * __exception)
{
	int __error = 0;
	char * __parameterTypeNames[1] = {0};
	unsigned int __parameterTypes[1];
	void * __parameters[1];

	if (__exception)
		*__exception = 0;


	// Pre-process parameter: Param
	__parameterTypeNames[0] = "System.UInt32";
	__parameterTypes[0] = (CDOTNET_UINT32);
	__parameters[0] = &Param;

	// Call instance member
	__errChk(CDotNetInvokeGenericMember(
		__assemblyHandle, 
		"WuAutoCheck.LFComand", 
		__instance, 
		CDOTNET_SET_FIELD, 
		"Param", 
		0, 
		0, 
		1, 
		(const char **)__parameterTypeNames, 
		__parameterTypes, 
		__parameters, 
		0, 
		0, 
		__exception));


__Error:
	return __error;
}

int CVIFUNC WuAutoCheck_LFComand__Get__ID(
	WuAutoCheck_LFComand __instance,
	char ** __returnValue,
	CDotNetHandle * __exception)
{
	int __error = 0;
	unsigned int __returnValueTypeId;

	if (__exception)
		*__exception = 0;
	if (__returnValue)
		*__returnValue = 0;


	// Pre-process return value
	__returnValueTypeId = CDOTNET_STRING;

	// Call instance member
	__errChk(CDotNetInvokeGenericMember(
		__assemblyHandle, 
		"WuAutoCheck.LFComand", 
		__instance, 
		CDOTNET_GET_FIELD, 
		"ID", 
		0, 
		0, 
		0, 
		0, 
		0, 
		0, 
		&__returnValueTypeId, 
		__returnValue, 
		__exception));


__Error:
	if (__error < 0) {
		_CDotNetGenDisposeScalar(
			__returnValue, 
			CDOTNET_STRING);
	}
	return __error;
}

int CVIFUNC WuAutoCheck_LFComand__Set__ID(
	WuAutoCheck_LFComand __instance,
	char * ID,
	CDotNetHandle * __exception)
{
	int __error = 0;
	char * __parameterTypeNames[1] = {0};
	unsigned int __parameterTypes[1];
	void * __parameters[1];

	if (__exception)
		*__exception = 0;


	// Pre-process parameter: ID
	__parameterTypeNames[0] = "System.String";
	__parameterTypes[0] = (CDOTNET_STRING);
	__parameters[0] = &ID;

	// Call instance member
	__errChk(CDotNetInvokeGenericMember(
		__assemblyHandle, 
		"WuAutoCheck.LFComand", 
		__instance, 
		CDOTNET_SET_FIELD, 
		"ID", 
		0, 
		0, 
		1, 
		(const char **)__parameterTypeNames, 
		__parameterTypes, 
		__parameters, 
		0, 
		0, 
		__exception));


__Error:
	return __error;
}


// Internal functions
static void _CDotNetGenDisposeScalar(void * scalar, unsigned int typeId)
{
	if (!*(void **)scalar)
		return;

	typeId &= CDOTNET_BASIC_TYPE_MASK;
	if (typeId == CDOTNET_STRING) {
		CDotNetFreeMemory(*(char **)scalar);
		*(char **)scalar = 0;
	}
	else if (typeId == CDOTNET_OBJECT || typeId == CDOTNET_STRUCT) {
		CDotNetDiscardHandle(*(CDotNetHandle *)scalar);
		*(CDotNetHandle *)scalar = 0;
	}
}

static void CVIFUNC_C _CDotNetGenDisposeArray(void * array, unsigned int typeId, size_t nDims, ...)
{
	size_t i;
	ssize_t totalLength = 1;
	va_list list;

	if (!*(void **)array)
		return;

	va_start(list, nDims);
	for (i = 0; i < nDims; ++i) {
		ssize_t * lenPtr = va_arg(list, ssize_t*);

		totalLength *= *lenPtr;
		*lenPtr = 0;
	}
	va_end(list);

	typeId &= CDOTNET_BASIC_TYPE_MASK;
	if (typeId == CDOTNET_STRING)
		while (--totalLength >= 0)
			CDotNetFreeMemory((*(char ***)array)[totalLength]);
	else if (typeId > CDOTNET_ENUM)
		while (--totalLength >= 0)
			CDotNetDiscardHandle((*(CDotNetHandle **)array)[totalLength]);

	CDotNetFreeMemory(*(void**)array);
	*(void**)array = 0;
}

