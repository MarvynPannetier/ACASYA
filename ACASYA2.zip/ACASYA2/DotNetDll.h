#include <cvidef.h>

// CVI wrapper header file for .NET assembly: WuAutoCheck, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
//
// This is specified by the '__assemblyName' constant in the generated source file.
// If there are multiple versions of this assembly, and you want .NET to determine 
// the appropriate one to load, then you can remove the version, culture, and public 
// key token information from the constant and just specify the name of the assembly.
//
// Other assemblies referenced by the target assembly:
// Name: mscorlib, Location: C:\Windows\Microsoft.NET\Framework\v4.0.30319\mscorlib.dll
//
// If any assembly, including the target assembly, is not installed in the
// Global Assembly Cache (GAC) or in the application directory, and the wrapper
// code needs to load the assembly to convert types like arrays and enums, then
// you must register the path of the assembly with the CVI .NET library by
// calling CDotNetRegisterAssemblyPath before calling the wrapper code.
//
// Types exposed by the target assembly but defined in other assemblies:
// CVI name: System_Collections_Generic_List_T1, .NET name: System.Collections.Generic.List`1[[System.String, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]], Assembly: mscorlib, Module: Global Assembly Cache

#include <cvidotnet.h>

#ifdef __cplusplus
extern "C" {
#endif

// Type definitions
typedef struct __WuAutoCheck_WU_Automation_Test_and_Folder_Manager * WuAutoCheck_WU_Automation_Test_and_Folder_Manager;
typedef struct __System_Collections_Generic_List_T1 * System_Collections_Generic_List_T1;
typedef struct __WuAutoCheck_TcCommand * WuAutoCheck_TcCommand;
typedef struct __WuAutoCheck_StandardFrameInterface * WuAutoCheck_StandardFrameInterface;
typedef struct __WuAutoCheck_DiagInterface * WuAutoCheck_DiagInterface;
typedef struct __WuAutoCheck_WUPInterface * WuAutoCheck_WUPInterface;
typedef struct __WuAutoCheck_SWIdentInterface * WuAutoCheck_SWIdentInterface;
typedef struct __WuAutoCheck_LSEInterface * WuAutoCheck_LSEInterface;
typedef struct __WuAutoCheck_DruckInterface * WuAutoCheck_DruckInterface;
typedef struct __WuAutoCheck_ChartLine * WuAutoCheck_ChartLine;
typedef struct __WuAutoCheck_Point * WuAutoCheck_Point;
typedef struct __WuAutoCheck_ChartPlotVal * WuAutoCheck_ChartPlotVal;
typedef struct __WuAutoCheck_ConstParam * WuAutoCheck_ConstParam;
typedef struct __WuAutoCheck_WuId * WuAutoCheck_WuId;
typedef struct __WuAutoCheck_LFFrame * WuAutoCheck_LFFrame;
typedef struct __WuAutoCheck_Filter * WuAutoCheck_Filter;
typedef struct __WuAutoCheck_AttributeLabel * WuAutoCheck_AttributeLabel;
typedef struct __WuAutoCheck_Constants * WuAutoCheck_Constants;
typedef struct __WuAutoCheck_LFComand * WuAutoCheck_LFComand;
typedef struct __Microsoft_Office_Interop_Excel_Workbook * Microsoft_Office_Interop_Excel_Workbook;
typedef struct __Microsoft_Office_Interop_Excel_Worksheet * Microsoft_Office_Interop_Excel_Worksheet;
typedef struct __Microsoft_Office_Interop_Excel_Range * Microsoft_Office_Interop_Excel_Range;
typedef struct __Microsoft_Office_Interop_Excel_Application * Microsoft_Office_Interop_Excel_Application;
typedef struct __Microsoft_Office_Interop_Excel__Application * Microsoft_Office_Interop_Excel__Application;
typedef struct __Microsoft_Office_Interop_Excel_Workbooks * Microsoft_Office_Interop_Excel_Workbooks;
typedef struct __Microsoft_Office_Interop_Excel__Workbook * Microsoft_Office_Interop_Excel__Workbook;
typedef struct __Microsoft_Office_Interop_Excel_Sheets * Microsoft_Office_Interop_Excel_Sheets;
typedef struct __Microsoft_Office_Interop_Excel__Worksheet * Microsoft_Office_Interop_Excel__Worksheet;
typedef struct __Microsoft_Office_Interop_Excel_ChartObjects * Microsoft_Office_Interop_Excel_ChartObjects;
typedef struct __Microsoft_Office_Interop_Excel_ChartObject * Microsoft_Office_Interop_Excel_ChartObject;
typedef struct __Microsoft_Office_Interop_Excel_Chart * Microsoft_Office_Interop_Excel_Chart;
typedef struct __Microsoft_Office_Interop_Excel__Chart * Microsoft_Office_Interop_Excel__Chart;
typedef struct __Microsoft_Office_Interop_Excel_WorkbookEvents_Event * Microsoft_Office_Interop_Excel_WorkbookEvents_Event;
typedef struct __Microsoft_Office_Interop_Excel_DocEvents_Event * Microsoft_Office_Interop_Excel_DocEvents_Event;
typedef struct __Microsoft_Office_Interop_Excel_AppEvents_Event * Microsoft_Office_Interop_Excel_AppEvents_Event;
typedef struct __Microsoft_Office_Interop_Excel_ChartEvents_Event * Microsoft_Office_Interop_Excel_ChartEvents_Event;
typedef struct __Microsoft_Office_Interop_Excel_AppEvents * Microsoft_Office_Interop_Excel_AppEvents;
typedef struct __Microsoft_Office_Interop_Excel_ChartEvents * Microsoft_Office_Interop_Excel_ChartEvents;
typedef struct __Microsoft_Office_Interop_Excel_DocEvents * Microsoft_Office_Interop_Excel_DocEvents;
typedef struct __Microsoft_Office_Interop_Excel_WorkbookEvents * Microsoft_Office_Interop_Excel_WorkbookEvents;

// C wrapper for enumeration type Microsoft.Office.Interop.Excel.XlPlatform
#ifndef Microsoft_Office_Interop_Excel_XlPlatform_DEFINED
#define Microsoft_Office_Interop_Excel_XlPlatform_DEFINED
typedef enum Microsoft_Office_Interop_Excel_XlPlatform
{
	Microsoft_Office_Interop_Excel_XlPlatform_xlMacintosh = 0x1,
	Microsoft_Office_Interop_Excel_XlPlatform_xlWindows = 0x2,
	Microsoft_Office_Interop_Excel_XlPlatform_xlMSDOS = 0x3,
} Microsoft_Office_Interop_Excel_XlPlatform;
#endif // Microsoft_Office_Interop_Excel_XlPlatform_DEFINED

// C wrapper for enumeration type Microsoft.Office.Interop.Excel.XlBorderWeight
#ifndef Microsoft_Office_Interop_Excel_XlBorderWeight_DEFINED
#define Microsoft_Office_Interop_Excel_XlBorderWeight_DEFINED
typedef enum Microsoft_Office_Interop_Excel_XlBorderWeight
{
	Microsoft_Office_Interop_Excel_XlBorderWeight_xlHairline = 0x1,
	Microsoft_Office_Interop_Excel_XlBorderWeight_xlThin = 0x2,
	Microsoft_Office_Interop_Excel_XlBorderWeight_xlThick = 0x4,
	Microsoft_Office_Interop_Excel_XlBorderWeight_xlMedium = 0xffffefd6,
} Microsoft_Office_Interop_Excel_XlBorderWeight;
#endif // Microsoft_Office_Interop_Excel_XlBorderWeight_DEFINED

// C wrapper for enumeration type Microsoft.Office.Interop.Excel.XlChartType
#ifndef Microsoft_Office_Interop_Excel_XlChartType_DEFINED
#define Microsoft_Office_Interop_Excel_XlChartType_DEFINED
typedef enum Microsoft_Office_Interop_Excel_XlChartType
{
	Microsoft_Office_Interop_Excel_XlChartType_xlArea = 0x1,
	Microsoft_Office_Interop_Excel_XlChartType_xlLine = 0x4,
	Microsoft_Office_Interop_Excel_XlChartType_xlPie = 0x5,
	Microsoft_Office_Interop_Excel_XlChartType_xlBubble = 0xf,
	Microsoft_Office_Interop_Excel_XlChartType_xlColumnClustered = 0x33,
	Microsoft_Office_Interop_Excel_XlChartType_xlColumnStacked = 0x34,
	Microsoft_Office_Interop_Excel_XlChartType_xlColumnStacked100 = 0x35,
	Microsoft_Office_Interop_Excel_XlChartType_xl3DColumnClustered = 0x36,
	Microsoft_Office_Interop_Excel_XlChartType_xl3DColumnStacked = 0x37,
	Microsoft_Office_Interop_Excel_XlChartType_xl3DColumnStacked100 = 0x38,
	Microsoft_Office_Interop_Excel_XlChartType_xlBarClustered = 0x39,
	Microsoft_Office_Interop_Excel_XlChartType_xlBarStacked = 0x3a,
	Microsoft_Office_Interop_Excel_XlChartType_xlBarStacked100 = 0x3b,
	Microsoft_Office_Interop_Excel_XlChartType_xl3DBarClustered = 0x3c,
	Microsoft_Office_Interop_Excel_XlChartType_xl3DBarStacked = 0x3d,
	Microsoft_Office_Interop_Excel_XlChartType_xl3DBarStacked100 = 0x3e,
	Microsoft_Office_Interop_Excel_XlChartType_xlLineStacked = 0x3f,
	Microsoft_Office_Interop_Excel_XlChartType_xlLineStacked100 = 0x40,
	Microsoft_Office_Interop_Excel_XlChartType_xlLineMarkers = 0x41,
	Microsoft_Office_Interop_Excel_XlChartType_xlLineMarkersStacked = 0x42,
	Microsoft_Office_Interop_Excel_XlChartType_xlLineMarkersStacked100 = 0x43,
	Microsoft_Office_Interop_Excel_XlChartType_xlPieOfPie = 0x44,
	Microsoft_Office_Interop_Excel_XlChartType_xlPieExploded = 0x45,
	Microsoft_Office_Interop_Excel_XlChartType_xl3DPieExploded = 0x46,
	Microsoft_Office_Interop_Excel_XlChartType_xlBarOfPie = 0x47,
	Microsoft_Office_Interop_Excel_XlChartType_xlXYScatterSmooth = 0x48,
	Microsoft_Office_Interop_Excel_XlChartType_xlXYScatterSmoothNoMarkers = 0x49,
	Microsoft_Office_Interop_Excel_XlChartType_xlXYScatterLines = 0x4a,
	Microsoft_Office_Interop_Excel_XlChartType_xlXYScatterLinesNoMarkers = 0x4b,
	Microsoft_Office_Interop_Excel_XlChartType_xlAreaStacked = 0x4c,
	Microsoft_Office_Interop_Excel_XlChartType_xlAreaStacked100 = 0x4d,
	Microsoft_Office_Interop_Excel_XlChartType_xl3DAreaStacked = 0x4e,
	Microsoft_Office_Interop_Excel_XlChartType_xl3DAreaStacked100 = 0x4f,
	Microsoft_Office_Interop_Excel_XlChartType_xlDoughnutExploded = 0x50,
	Microsoft_Office_Interop_Excel_XlChartType_xlRadarMarkers = 0x51,
	Microsoft_Office_Interop_Excel_XlChartType_xlRadarFilled = 0x52,
	Microsoft_Office_Interop_Excel_XlChartType_xlSurface = 0x53,
	Microsoft_Office_Interop_Excel_XlChartType_xlSurfaceWireframe = 0x54,
	Microsoft_Office_Interop_Excel_XlChartType_xlSurfaceTopView = 0x55,
	Microsoft_Office_Interop_Excel_XlChartType_xlSurfaceTopViewWireframe = 0x56,
	Microsoft_Office_Interop_Excel_XlChartType_xlBubble3DEffect = 0x57,
	Microsoft_Office_Interop_Excel_XlChartType_xlStockHLC = 0x58,
	Microsoft_Office_Interop_Excel_XlChartType_xlStockOHLC = 0x59,
	Microsoft_Office_Interop_Excel_XlChartType_xlStockVHLC = 0x5a,
	Microsoft_Office_Interop_Excel_XlChartType_xlStockVOHLC = 0x5b,
	Microsoft_Office_Interop_Excel_XlChartType_xlCylinderColClustered = 0x5c,
	Microsoft_Office_Interop_Excel_XlChartType_xlCylinderColStacked = 0x5d,
	Microsoft_Office_Interop_Excel_XlChartType_xlCylinderColStacked100 = 0x5e,
	Microsoft_Office_Interop_Excel_XlChartType_xlCylinderBarClustered = 0x5f,
	Microsoft_Office_Interop_Excel_XlChartType_xlCylinderBarStacked = 0x60,
	Microsoft_Office_Interop_Excel_XlChartType_xlCylinderBarStacked100 = 0x61,
	Microsoft_Office_Interop_Excel_XlChartType_xlCylinderCol = 0x62,
	Microsoft_Office_Interop_Excel_XlChartType_xlConeColClustered = 0x63,
	Microsoft_Office_Interop_Excel_XlChartType_xlConeColStacked = 0x64,
	Microsoft_Office_Interop_Excel_XlChartType_xlConeColStacked100 = 0x65,
	Microsoft_Office_Interop_Excel_XlChartType_xlConeBarClustered = 0x66,
	Microsoft_Office_Interop_Excel_XlChartType_xlConeBarStacked = 0x67,
	Microsoft_Office_Interop_Excel_XlChartType_xlConeBarStacked100 = 0x68,
	Microsoft_Office_Interop_Excel_XlChartType_xlConeCol = 0x69,
	Microsoft_Office_Interop_Excel_XlChartType_xlPyramidColClustered = 0x6a,
	Microsoft_Office_Interop_Excel_XlChartType_xlPyramidColStacked = 0x6b,
	Microsoft_Office_Interop_Excel_XlChartType_xlPyramidColStacked100 = 0x6c,
	Microsoft_Office_Interop_Excel_XlChartType_xlPyramidBarClustered = 0x6d,
	Microsoft_Office_Interop_Excel_XlChartType_xlPyramidBarStacked = 0x6e,
	Microsoft_Office_Interop_Excel_XlChartType_xlPyramidBarStacked100 = 0x6f,
	Microsoft_Office_Interop_Excel_XlChartType_xlPyramidCol = 0x70,
	Microsoft_Office_Interop_Excel_XlChartType_xlXYScatter = 0xffffefb7,
	Microsoft_Office_Interop_Excel_XlChartType_xlRadar = 0xffffefc9,
	Microsoft_Office_Interop_Excel_XlChartType_xlDoughnut = 0xffffefe8,
	Microsoft_Office_Interop_Excel_XlChartType_xl3DPie = 0xffffeffa,
	Microsoft_Office_Interop_Excel_XlChartType_xl3DLine = 0xffffeffb,
	Microsoft_Office_Interop_Excel_XlChartType_xl3DColumn = 0xffffeffc,
	Microsoft_Office_Interop_Excel_XlChartType_xl3DArea = 0xffffeffe,
} Microsoft_Office_Interop_Excel_XlChartType;
#endif // Microsoft_Office_Interop_Excel_XlChartType_DEFINED

// C wrapper for enumeration type Microsoft.Office.Interop.Excel.XlRowCol
#ifndef Microsoft_Office_Interop_Excel_XlRowCol_DEFINED
#define Microsoft_Office_Interop_Excel_XlRowCol_DEFINED
typedef enum Microsoft_Office_Interop_Excel_XlRowCol
{
	Microsoft_Office_Interop_Excel_XlRowCol_xlRows = 0x1,
	Microsoft_Office_Interop_Excel_XlRowCol_xlColumns = 0x2,
} Microsoft_Office_Interop_Excel_XlRowCol;
#endif // Microsoft_Office_Interop_Excel_XlRowCol_DEFINED




// Global Functions
int CVIFUNC Initialize_WuAutoCheck(void);
int CVIFUNC Close_WuAutoCheck(void);

// Type: WuAutoCheck.WU_Automation_Test_and_Folder_Manager
int CVIFUNC WuAutoCheck_WU_Automation_Test_and_Folder_Manager__Create(
	WuAutoCheck_WU_Automation_Test_and_Folder_Manager * __instance,
	CDotNetHandle * __exception);
int CVIFUNC WuAutoCheck_WU_Automation_Test_and_Folder_Manager_InitInterface(
	WuAutoCheck_WU_Automation_Test_and_Folder_Manager __instance,
	char * LogsCheckDirPath,
	char * LogsStorageDirPath,
	char * ConfigFilePath,
	char * ANumConfigFileNamePath,
	unsigned int PressU,
	unsigned int AccU,
	double WheelDimension,
	CDotNetHandle * __exception);
int CVIFUNC WuAutoCheck_WU_Automation_Test_and_Folder_Manager_GenerateTestFile(
	WuAutoCheck_WU_Automation_Test_and_Folder_Manager __instance,
	char * TestPath,
	unsigned int testRep,
	char ** BenchTest,
	int * CheckValidity,
	WuAutoCheck_LFComand ** __returnValue,
	ssize_t * ____returnValueLength,
	CDotNetHandle * __exception);
int CVIFUNC WuAutoCheck_WU_Automation_Test_and_Folder_Manager_CheckTest(
	WuAutoCheck_WU_Automation_Test_and_Folder_Manager __instance,
	int * ret,
	CDotNetHandle * __exception);
int CVIFUNC WuAutoCheck_WU_Automation_Test_and_Folder_Manager_CloseInterface(
	WuAutoCheck_WU_Automation_Test_and_Folder_Manager __instance,
	CDotNetHandle * __exception);
int CVIFUNC WuAutoCheck_WU_Automation_Test_and_Folder_Manager_AnalyzeTest(
	WuAutoCheck_WU_Automation_Test_and_Folder_Manager __instance,
	char * TestFolder,
	int KillExcelProcesses,
	int * ret,
	CDotNetHandle * __exception);
int CVIFUNC WuAutoCheck_WU_Automation_Test_and_Folder_Manager_CloseInterface_1(
	WuAutoCheck_WU_Automation_Test_and_Folder_Manager __instance,
	int KillExcelProcesses,
	CDotNetHandle * __exception);
int CVIFUNC WuAutoCheck_WU_Automation_Test_and_Folder_Manager_ReadTest(
	WuAutoCheck_WU_Automation_Test_and_Folder_Manager __instance,
	char * ConfigFilePath,
	char * TestFilePath,
	int * __returnValue,
	CDotNetHandle * __exception);
int CVIFUNC WuAutoCheck_WU_Automation_Test_and_Folder_Manager_CreateErrorLog(
	char * ErrorLogPath,
	System_Collections_Generic_List_T1 WriteLines,
	int append,
	CDotNetHandle * __exception);
int CVIFUNC WuAutoCheck_WU_Automation_Test_and_Folder_Manager__Get__DeleteFolders(
	WuAutoCheck_WU_Automation_Test_and_Folder_Manager __instance,
	int * __returnValue,
	CDotNetHandle * __exception);
int CVIFUNC WuAutoCheck_WU_Automation_Test_and_Folder_Manager__Set__DeleteFolders(
	WuAutoCheck_WU_Automation_Test_and_Folder_Manager __instance,
	int DeleteFolders,
	CDotNetHandle * __exception);

int CVIFUNC WuAutoCheck_WU_Automation_Test_and_Folder_Manager__getPathLog (WuAutoCheck_WU_Automation_Test_and_Folder_Manager instance_Handle,
                                                                            char **pathLogXML,
                                                                            CDotNetHandle *exceptionHandle);

// Type: WuAutoCheck.LFComand
int CVIFUNC WuAutoCheck_LFComand__Create(
	WuAutoCheck_LFComand * __instance,
	CDotNetHandle * __exception);
int CVIFUNC WuAutoCheck_LFComand__Get__Time(
	WuAutoCheck_LFComand __instance,
	double * __returnValue,
	CDotNetHandle * __exception);
int CVIFUNC WuAutoCheck_LFComand__Set__Time(
	WuAutoCheck_LFComand __instance,
	double Time,
	CDotNetHandle * __exception);
int CVIFUNC WuAutoCheck_LFComand__Get__Command(
	WuAutoCheck_LFComand __instance,
	int * __returnValue,
	CDotNetHandle * __exception);
int CVIFUNC WuAutoCheck_LFComand__Set__Command(
	WuAutoCheck_LFComand __instance,
	int Command,
	CDotNetHandle * __exception);
int CVIFUNC WuAutoCheck_LFComand__Get__StrVal(
	WuAutoCheck_LFComand __instance,
	char ** __returnValue,
	CDotNetHandle * __exception);
int CVIFUNC WuAutoCheck_LFComand__Set__StrVal(
	WuAutoCheck_LFComand __instance,
	char * StrVal,
	CDotNetHandle * __exception);
int CVIFUNC WuAutoCheck_LFComand__Get__NumVal(
	WuAutoCheck_LFComand __instance,
	unsigned int * __returnValue,
	CDotNetHandle * __exception);
int CVIFUNC WuAutoCheck_LFComand__Set__NumVal(
	WuAutoCheck_LFComand __instance,
	unsigned int NumVal,
	CDotNetHandle * __exception);
int CVIFUNC WuAutoCheck_LFComand__Get__Param(
	WuAutoCheck_LFComand __instance,
	unsigned int * __returnValue,
	CDotNetHandle * __exception);
int CVIFUNC WuAutoCheck_LFComand__Set__Param(
	WuAutoCheck_LFComand __instance,
	unsigned int Param,
	CDotNetHandle * __exception);
int CVIFUNC WuAutoCheck_LFComand__Get__ID(
	WuAutoCheck_LFComand __instance,
	char ** __returnValue,
	CDotNetHandle * __exception);
int CVIFUNC WuAutoCheck_LFComand__Set__ID(
	WuAutoCheck_LFComand __instance,
	char * ID,
	CDotNetHandle * __exception);


#ifdef __cplusplus
}
#endif
