// DEBUT TABLE
//******************************************************************************
// PRO: BANC DE TEST LSE
// PRG: GstTables.c
// VER: Version I00A00A du 09/08/2010
// AUT: C. BERENGER / MICROTEC
//
// ROL: Programme de gestion des tables de vitesse et pression
//
// HST: Version I00A00A du 14/09/2010 / MP. LACROIX MICROTEC / Cr�ation
// HST: Version I00A00B du 15/11/2010 / C.BERENGER / 
//		- Passage de la r�solution moteur � 0.1 tours/min
//		- Modification de l'affichage du graphique en mode manuel
//		- Correction du probl�me de gestion des limites apr�s le chargement
//	      d'un cycle dans une autre unit� de vitesse ou de pression que celle 
//	      utilis�e par d�faut.
// HST: Version I00A00C du 30/11/2010 / C. BERENGER MICROTEC / 
//	    - Ajout d'une gestion par watchdog pour couper le moteur et la pression 
//	      en cas de probl�me de blocage de l'application.
// HST: Version I00A00D du 04/01/2011 / C. BERENGER MICROTEC / 
//	    - Ajout de quelques Mutex
//		- Suppresison de l'utilisation du fichier "MessageIhm.ini", et remplacement par des constantes
//		- Recompilation du programme avec la version 8.6.0f5 du DAQmx (identique � la version install�e sur le banc du client)
//		- Passage de la variable "GptstConfig" en mode prot�g� dans le fichier "Modes.c"
//******************************************************************************
//
//******************************************************************************
// FIN TABLE

//******************************************************************************
// Inclusions
//******************************************************************************

// Librairies standards 
#include <utility.h>
#include <ansi_c.h>
#include <userint.h>
#include <cvirte.h>

// Librairies FOURNISSEUR

// Librairies MICROTEC
#include "ZoneMessage.h"
#include "MessageIhm.h"

// Librairies sp�cifiques � l'application
#include "IhmModes.h"
#include "GstFiles.h" 
#include "Modes.h"
#include "GstTables.h"
#include "GstGraphe.h"


//******************************************************************************
// D�finition de constantes
//******************************************************************************
//----- Options -------
//---------------------


//******************************************************************************
// D�finition de types et structures
//******************************************************************************




//******************************************************************************
// Variables globales
//******************************************************************************
static int GiValidOk=0;
static int GiValidCancel=0;
static int GiDisableMajGrapheVitesse 	= 1;
static int GiDisableMajGraphePression 	= 1;
static BOOL GbValidCopySpeed			= 0;
static BOOL GbValidCopyPress			= 0;
Rect GrCopieSelectVit;
Rect GrCopieSelectPres;


//******************************************************************************
// Fonctions internes au source
//******************************************************************************



//******************************************************************************
// Corps des fonctions et proc�dures internes au source
//******************************************************************************



// DEBUT ALGO
//****************************************************************************** 
//int GstTablesGetRowColFromMouse(int iPanel, int iControl, int *ptiNumRow, int *ptiNumCol, 
//								int *ptiPosMouseX, int *ptiPosMouseY, BOOL *ptbCoordValid)
//****************************************************************************** 
//	- int iPanel			: Handle du panel
//	  int iControl			: Num�ro de contr�le de la table
//	  int *ptiNumRow		: Num�ro de ligne dans la table
//	  int *ptiNumCol		: Num�ro de colonne dans la table
//	  int *ptiPosMouseX		: Coordonn�es du pointeur de la souris en X
//	  int *ptiPosMouseY		: Coordonn�es du pointeur de la souris en Y
//	  BOOL *ptbCoordValid	: 1=Coordonn�es valides, sinon 0
//
//  - Retourne les coordonn�es (ligne/colonne de la table) par rapport au curseur de la souris
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
// FIN ALGO
int GstTablesGetRowColFromMouse(int iPanel, int iControl, int *ptiNumRow, int *ptiNumCol, 
								int *ptiPosMouseX, int *ptiPosMouseY, BOOL *ptbCoordValid)
{
int iLeftButt;
int iRightButt;
int iPosPanelLeft;
int iPosPanelTop;
int iNumberOfRows;
int iError;
Point cell;


	// Init
	iError 			= 0;
	*ptiNumRow		= 0;
	*ptiNumCol		= 0;
	*ptbCoordValid	= 0;

	// Lecture de la position (en pixels) du curseur de la souris sur le graphique
	iError = GetGlobalMouseState (NULL, ptiPosMouseX, ptiPosMouseY, &iLeftButt, &iRightButt, NULL);

	// Lecture de la position du panel (coordonn�es en haut � gauche)
	GetPanelAttribute (iPanel, ATTR_LEFT, &iPosPanelLeft);
	GetPanelAttribute (iPanel, ATTR_TOP, &iPosPanelTop);
	
	// Lecture de la valeur de la cellule par rapport � la position de la souris
	iError = GetTableCellFromPoint (iPanel, iControl, MakePoint (*ptiPosMouseX-iPosPanelLeft, *ptiPosMouseY-iPosPanelTop), &cell);
	
	// D�termination du nombre de lignes du contr�le (data grid)
	iError = GetNumTableRows (iPanel, iControl, &iNumberOfRows);

	// V�rification de la validit� des valeurs renvoy�es (num�ro de la cellule au dessus de laquelle se trouve la souris)
	if (((cell.x < 1) || (cell.x > 10)) || ((cell.y < 1) || (cell.y > iNumberOfRows))){
	}else{
			*ptiNumCol = cell.x;
			*ptiNumRow = cell.y;
			*ptbCoordValid	= 1;
		}

	return iError; // 0 si OK
}

// DEBUT ALGO
//****************************************************************************** 
//int GstTablesGstZoneSelect(int iPanel, int iControl, int iNumRowMouse, int iNumColMouse
//							int *ptiHeightSelect, int *ptiWidthSelect, int *ptiLeftSelect,
//							int *ptiTopSelect, BOOL *ptbValid)
//****************************************************************************** 
//	- int iPanel			: Handle du panel
//	  int iControl			: Num�ro de contr�le de la table
//	  int iNumRowMouse		: Num�ro de ligne dans la table ou se trouve le pointeur de la souris
//	  int iNumColMouse		: Num�ro de colonne dans la table ou se trouve le pointeur de la souris
//	  int *ptiHeightSelect  : Hauteur de la s�lection (en lignes)
//	  int *ptiWidthSelect   : Largeur de la s�lection (en colonnes)
//	  int *ptiLeftSelect	: Position gauche de la s�lection (1,...)
//	  int *ptiTopSelect		: Position haute de la s�lection (1,...)
//	  BOOL *ptbValid		: 1: S�lection valide, sinon invalide
//
//  - Retourne la taille de la zone de s�lection
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
// FIN ALGO
int GstTablesGstZoneSelect(int iPanel, int iControl, int iNumRowMouse, int iNumColMouse,
							int *ptiHeightSelect, int *ptiWidthSelect, int *ptiLeftSelect,
							int *ptiTopSelect, BOOL *ptbValid)
{
int iError;
Rect rect;

	// Init
	iError 			= 0;
	*ptiHeightSelect= 0;
	*ptiWidthSelect = 0;
	*ptiLeftSelect	= 0;
	*ptiTopSelect	= 0;
	*ptbValid		= 0;

	// Lecture de la taille de la zone de s�lection
	iError = GetTableSelection (iPanel, iControl, &rect); 
	
	if (!iError){
		if (rect.height <= 1){
			rect.height = 1;
			rect.width 	= 8;
			rect.left 	= 1;
			rect.top 	= iNumRowMouse;

			// Rend le contr�le actif
			SetActiveCtrl (iPanel, iControl);
			
			// S�lectionne la ligne point�e par la souris
			//SetTableSelection (iPanel, iControl, rect);	//cete fonction cause de problemes 
		}

		*ptiHeightSelect= rect.height;
		*ptiWidthSelect = rect.width;
		*ptiLeftSelect	= rect.left;
		*ptiTopSelect	= rect.top;	
		
		*ptbValid = 1;
	}
	

	return iError;
}

// DEBUT ALGO
//****************************************************************************** 
//int GstTablesMajTableau(int iPanel, int iControl, int iTypeTable, 
//						stTabVitesse *ptstTabVitesse, stTabPression *ptstTabPression,
//						char *sMsgErr)
//****************************************************************************** 
//	- int iPanel			: Handle du panel
//	  int iControl			: Num�ro de contr�le de la table
//	  int iTypeTable		: Type de table s�lectionn�e (vitesse ou pression)
//	  stTabVitesse *ptstTabVitesse	: Pointeur vers le tableau des vitesses
//	  stTabPression *ptstTabPression: POinteur vers le tableau des pressions 
//	  char *sMsgErr			: Message d'erreur
//
//  - Mise � jour des donn�es (vitesse ou pression) � partir de la table affich�e � l'�cran
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
// FIN ALGO
int GstTablesMajTableau(int iPanel, int iControl, int iTypeTable, 
						stTabVitesse *ptstTabVitesse, stTabPression *ptstTabPression,
						char *sMsgErr)
{
Rect Cell_Range; 
double *dPtTabVal;
double *dPtTabTps;
int *iPtInbElts;
int iError;
int iNbRows;

	// Initialisation
	strcpy(sMsgErr, "");

	// Lecture du nombre de lignes de la table
	iError = GetNumTableRows (iPanel, iControl, &iNbRows);
	if (iError != 0){
		sprintf(sMsgErr, "Error reading rows number\n%s", GetUILErrorString(iError)); 
		return iError;
		
	}


	// Affectation des pointeurs
	switch(iTypeTable){	   
		case iTYPE_VITESSE:
			dPtTabVal 	= &ptstTabVitesse->dVit[0];
			dPtTabTps 	= &ptstTabVitesse->dDuree[0];
			iPtInbElts 	= &ptstTabVitesse->iNbElmts;
			break;
		case iTYPE_PRESSION:
			dPtTabVal 	= &ptstTabPression->dPress[0];
			dPtTabTps 	= &ptstTabPression->dDuree[0];
			iPtInbElts	= &ptstTabPression->iNbElmts;
			break;
	}
	
	// Initialisation
	*iPtInbElts = 0;
	
	// Lecture de la colonne des valeurs
	Cell_Range.top 		= 1;
	Cell_Range.left 	= 1;
	Cell_Range.height 	= iNbRows;
	Cell_Range.width 	= 1; 
	GetTableCellRangeVals (iPanel, iControl, Cell_Range, dPtTabVal, VAL_COLUMN_MAJOR);

	// Lecture de la colonne du temps
	Cell_Range.left 	= 2;
	GetTableCellRangeVals (iPanel, iControl, Cell_Range, dPtTabTps, VAL_COLUMN_MAJOR);

	// Mise � jour du nombre de valeurs dans le tableau
	*iPtInbElts = iNbRows; 
	
	return iError;
}

// DEBUT ALGO
//****************************************************************************** 
//int GstTablesAddRows(	int iPanel, int iControl, int iOneBaseRowIndex, 
//						int iNbMaxRows, int iNbRowsToAdd, int iOptionbInsert,
//						int iTypeTable, stTabVitesse *ptstTabVitesse, 
//						stTabPression *ptstTabPression, int *ptiNbRowsAdded)
//****************************************************************************** 
//	- int iPanel			: Handle du panel
//	  int iControl			: Num�ro de contr�le de la table
//	  int iOneBaseRowIndex	: Num�ro de la ligne � partir de laquelle il faut rajouter des lignes 
//	  double dLimMinTpsSpeed: Dur�e par d�faut des vitesses
//	  double dLimMinTpsPress: Temps par d�faut des pressions
// 	  int iNbMaxRows		: Nombre maximal de lignes de la table
//	  int iNbRowsToAdd		: Nombre de lignes � rajouter
//	  int iOptionbInsert	: Option d'insertion des lignes:
//								- A partir de la ligne s�lectionn�e
//								- Avant la ligne s�lectionn�e
//								- Apr�s la ligne ss�lectionn�e
//								- A la fin de la table,
//	  int iTypeTable		: Type de table s�lectionn�e (vitesse ou pression)
//	  stTabVitesse *ptstTabVitesse	: Pointeur vers le tableau des vitesses
//	  stTabPression *ptstTabPression: POinteur vers le tableau des pressions 
//	  int *ptiNbRowsAdded	: Nombre de lignes ajout�es
//	  char *sMsgErr			: Message d'erreur
//
//  - Ajout d'une ou plusieurs lignes dans une table
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
// FIN ALGO
int GstTablesAddRows(	int iPanel, int iControl, int iOneBaseRowIndex, 
						double dLimMinTpsSpeed, double dLimMinTpsPress,
						int iNbMaxRows, int iNbRowsToAdd, int iOptionbInsert,
						int iTypeTable, stTabVitesse *ptstTabVitesse, 
						stTabPression *ptstTabPression, int *ptiNbRowsAdded,
						char *sMsgErr)
{
Rect Cell_Range;
double dLimMinTps;
double *dPtTabVal;
double *dPtTabTps;
int *iPtInbElts;
int iInsertIndex;
int iError;
int iNbRowsAfterAdd;
int iNbRows;

	// Init
	*ptiNbRowsAdded = 0;
	iError			= 0;
	strcpy(sMsgErr, "");
	
	// Affectation des pointeurs
	switch(iTypeTable){	   
		case iTYPE_VITESSE:
			dLimMinTps 	= dLimMinTpsSpeed;
			dPtTabVal 	= &ptstTabVitesse->dVit[0];
			dPtTabTps 	= &ptstTabVitesse->dDuree[0];
			iPtInbElts 	= &ptstTabVitesse->iNbElmts;
		break;
		case iTYPE_PRESSION:
			dLimMinTps 	= dLimMinTpsPress;
			dPtTabVal 	= &ptstTabPression->dPress[0];
			dPtTabTps 	= &ptstTabPression->dDuree[0];
			iPtInbElts	= &ptstTabPression->iNbElmts;
		break;
	}
	
	// Options d'ajout des lignes
	switch (iOptionbInsert){
		case bINSERT_HERE:
			iInsertIndex = iOneBaseRowIndex;
		break;
		case bINSERT_BEFORE:
			iInsertIndex = iOneBaseRowIndex;
		break;
		case bINSERT_AFTER:
			iInsertIndex = iOneBaseRowIndex + 1;
		break;
		case bINSERT_END:
			iInsertIndex = -1;
		break;
	}

	// Lecture du nombre de lignes de la table
	iError = GetNumTableRows (iPanel, iControl, &iNbRows);
	if (iError != 0){	
		strcpy(sMsgErr, GetUILErrorString(iError));
		return iError;
	}
	
	// V�rification du nombre max de lignes
	if ((iNbRows + iNbRowsToAdd) <= iNbMaxRows){
		// Ajout des lignes dans la table
		iError = InsertTableRows (iPanel, iControl, iInsertIndex, iNbRowsToAdd, VAL_USE_MASTER_CELL_TYPE);
		
		// Lecture du nombre de lignes de la table
		GetNumTableRows (iPanel, iControl, &iNbRowsAfterAdd);
		
		// Mise � jour du nombre de lignes ajout�es
		if (iError == 0){
			*ptiNbRowsAdded	= iNbRowsToAdd;
			
			// Mise � jour des valeurs par d�faut dans la colonne des dur�es
			Cell_Range.top 		= iInsertIndex;
			Cell_Range.left 	= 2;
			Cell_Range.height 	= iNbRowsToAdd;
			Cell_Range.width 	= 1; 
			SetTableCellRangeAttribute (iPanel, iControl, Cell_Range, ATTR_CTRL_VAL, dLimMinTps);
			
			// Mise � jour des donn�es (vitesse ou pression) � partir de la table affich�e � l'�cran
			iError = GstTablesMajTableau(iPanel, iControl, iTypeTable, ptstTabVitesse, ptstTabPression, sMsgErr);
		}
		else	
			strcpy(sMsgErr, GetUILErrorString(iError));
	}
	else{
			if ((iNbMaxRows - iNbRows) >= 1)
				sprintf(sMsgErr, "Number of rows must be between [1] and [%d]!", iNbMaxRows - iNbRows);
			else
				sprintf(sMsgErr, "Can't add any row (max rows = %d)!", iNbMaxRows);

		 	return -1;
		 }

	return iError; // 0 si OK
}

// DEBUT ALGO
//****************************************************************************** 
//int GstTablesSupprSelect(int iPanel, int iControl, int iHeightSelect, int iWidthSelect,
//						int iLeftSelect, int iTopSelect,int iTypeTable, 
//						stTabVitesse *ptstTabVitesse, stTabPression *ptstTabPression,
//						char *sMsgErr)
//****************************************************************************** 
//	- int iPanel			: Handle du panel
//	  int iControl			: Num�ro de contr�le de la table
//	  int iHeightSelect  	: Hauteur de la s�lection (en lignes)
//	  int iWidthSelect  	: Largeur de la s�lection (en colonnes)
//	  int iLeftSelect		: Position gauche de la s�lection (1,...)
//	  int iTopSelect		: Position haute de la s�lection (1,...)
//	  int iTypeTable		: Type de table s�lectionn�e (vitesse ou pression)
//	  stTabVitesse *ptstTabVitesse	: Pointeur vers le tableau des vitesses
//	  stTabPression *ptstTabPression: POinteur vers le tableau des pressions 
//	  char *sMsgErr			:Message d'erreur
//
//  - Suppression d'une s�lection
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
// FIN ALGO
int GstTablesSupprSelect(int iPanel, int iControl, int iHeightSelect, int iWidthSelect,
						int iLeftSelect, int iTopSelect,int iTypeTable, 
						stTabVitesse *ptstTabVitesse, stTabPression *ptstTabPression,
						char *sMsgErr)
{		   
double *dPtTabVal;
double *dPtTabTps;
int *iPtInbElts;  
int iNbRows;
int iError;


	// Init
	iError = 0;
	strcpy(sMsgErr, "");

	// Suppression des lignes
	iError = DeleteTableRows (iPanel, iControl, iTopSelect, iHeightSelect);		
	if (iError != 0){	
		strcpy(sMsgErr, GetUILErrorString(iError)); 
		return iError;
	}   
	
	// Affectation des pointeurs
	switch(iTypeTable){	   
		case iTYPE_VITESSE:
			dPtTabVal 	= &ptstTabVitesse->dVit[0];
			dPtTabTps 	= &ptstTabVitesse->dDuree[0];
			iPtInbElts 	= &ptstTabVitesse->iNbElmts;
		break;
		case iTYPE_PRESSION:
			dPtTabVal 	= &ptstTabPression->dPress[0];
			dPtTabTps 	= &ptstTabPression->dDuree[0];
			iPtInbElts	= &ptstTabPression->iNbElmts;
		break;
	}
	
	// Lecture du nombre de lignes de la table
	iError = GetNumTableRows (iPanel, iControl, &iNbRows);
	if (iError != 0){
		sprintf(sMsgErr, "Error reading rows number\n%s", GetUILErrorString(iError)); 
		return iError;
	}
	

	// Mise � jour des donn�es (vitesse ou pression) � partir de la table affich�e � l'�cran
	iError = GstTablesMajTableau(iPanel, iControl, iTypeTable, ptstTabVitesse, ptstTabPression, sMsgErr);

	return iError;// 0 si OK
}

// DEBUT ALGO
//****************************************************************************** 
//int GstTablesSetLim(int iPanel, int iIdTabVitesse, int iIdTabPress, 
//						int iUnitVitesse, int iUnitPress, stConfig *ptStConfig)
//****************************************************************************** 
//	- int iPanel			: Handle du panel
//	  int iIdTabVitesse		: Num�ro de contr�le de la table de vitesse
//	  int iIdTabPress		: Num�ro de contr�le de la table de pression
//	  int iUnitVitesse		: Unit� de vitesse
//	  int iUnitPress		: Unit� de pression
//	  stConfig *ptStConfig	: Pointeur sur la structure des param�tres
//
//  - Fixe les limites des tableaux de pression et de vitesse 
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
// FIN ALGO
int GstTablesSetLim(int iPanel, int iIdTabVitesse, int iIdTabPress, int iUnitVitesse,
					int iUnitPress, stConfig *ptStConfig)
{ 
	// Fixe les min/max du tableau des vitesses
	switch(iUnitVitesse){
		case iUNIT_KM_H:
			SetTableColumnAttribute (iPanel, iIdTabVitesse, 1, ATTR_MIN_VALUE, ptStConfig->dLimMinKmH);
			SetTableColumnAttribute (iPanel, iIdTabVitesse, 1, ATTR_MAX_VALUE, ptStConfig->dLimMaxKmH);
		break;
		case iUNIT_G:
			SetTableColumnAttribute (iPanel, iIdTabVitesse, 1, ATTR_MIN_VALUE, ptStConfig->dLimMinG);
			SetTableColumnAttribute (iPanel, iIdTabVitesse, 1, ATTR_MAX_VALUE, ptStConfig->dLimMaxG);
		break;
		case iUNIT_TRS_MIN:
			SetTableColumnAttribute (iPanel, iIdTabVitesse, 1, ATTR_MIN_VALUE, ptStConfig->dLimMinTrsMin);
			SetTableColumnAttribute (iPanel, iIdTabVitesse, 1, ATTR_MAX_VALUE, ptStConfig->dLimMaxTrsMin);
		break;
	}
	// Limites de la dur�e de chaque step
	SetTableColumnAttribute (iPanel, iIdTabVitesse, 2, ATTR_MIN_VALUE, ptStConfig->dLimMinTpsSpeed);
	SetTableColumnAttribute (iPanel, iIdTabVitesse, 2, ATTR_MAX_VALUE, ptStConfig->dLimMaxTpsSpeed);
	SetTableColumnAttribute (iPanel, iIdTabVitesse, 2, ATTR_NUM_CELL_DFLT_VALUE, ptStConfig->dLimMinTpsSpeed);	  
	
	
	// Fixe les min/max du tableau des pressions
	switch(iUnitPress){
		case iUNIT_KPA:
			SetTableColumnAttribute (iPanel, iIdTabPress, 1, ATTR_MIN_VALUE, ptStConfig->dLimMinKpa);
			SetTableColumnAttribute (iPanel, iIdTabPress, 1, ATTR_MAX_VALUE, ptStConfig->dLimMaxKpa);
		break;
		case iUNIT_BAR:
			SetTableColumnAttribute (iPanel, iIdTabPress, 1, ATTR_MIN_VALUE, ptStConfig->dLimMinBar);
			SetTableColumnAttribute (iPanel, iIdTabPress, 1, ATTR_MAX_VALUE, ptStConfig->dLimMaxBar);
		break;
		case iUNIT_MBAR:
			SetTableColumnAttribute (iPanel, iIdTabPress, 1, ATTR_MIN_VALUE, ptStConfig->dLimMinMbar);
			SetTableColumnAttribute (iPanel, iIdTabPress, 1, ATTR_MAX_VALUE, ptStConfig->dLimMaxMbar);
		break;
		case iUNIT_PSI:
			SetTableColumnAttribute (iPanel, iIdTabPress, 1, ATTR_MIN_VALUE, ptStConfig->dLimMinPsi);
			SetTableColumnAttribute (iPanel, iIdTabPress, 1, ATTR_MAX_VALUE, ptStConfig->dLimMaxPsi);
		break;
	}
	// Limites de la dur�e de chaque step
	SetTableColumnAttribute (iPanel, iIdTabPress, 2, ATTR_MIN_VALUE, ptStConfig->dLimMinTpsPress);
	SetTableColumnAttribute (iPanel, iIdTabPress, 2, ATTR_MAX_VALUE, ptStConfig->dLimMaxTpsPress);
	SetTableColumnAttribute (iPanel, iIdTabPress, 2, ATTR_NUM_CELL_DFLT_VALUE, ptStConfig->dLimMinTpsPress);	  
	
	
	return 0; // OK
}

// DEBUT ALGO
//****************************************************************************** 
// int GstDataGrid(int iPanel, int iControl, int iTypeGrid, int iColor, char *sPathConfigFile)
//****************************************************************************** 
//	- int iPanel	: Handle du panel
//	  int iControl	: Num�ro de contr�le de la grille de donn�es
//    int iTypeGrid	: Type de grille de donn�es (Vitesse ou pression)
//	  int iColor	: Couleur de la courbe de consigne
//
//  - Gestion des �v�nements sur les tables de donn�es
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
// FIN ALGO
int GstDataGrid(int iPanel, int iPopupMenuHandle, int iStatusPanel, int iPopupAdd, 
				int iControl, int iTypeGrid, int iColorSpeed, int iColorPress, stConfig *ptstConfig, 
				stTabVitesse *ptstTabVitesse, stTabPression *ptstTabPression, 
				int *ptiPanelStatusDisplayed, int *ptiAffMsg, char *sPathConfigFile)
{
char sMsgErr[1000];
int iError;
int iX;
int iY;
int iNumberOfRows;
int iInsertAfter;
int iTop;
int iLeft;
int iIdSelected;
int iGridHandle;
int iGrapheHandle;
int iOneBaseRowIndex;
int iNbRowsToAdd;
int iNbMaxRows;
int iNbRowsAdded;
int iAvailable;
int iValidOk;
int iValidCancel;
Point cell;
Rect  rect;
Rect rCopie;
BOOL bValid;

	// Initialisation
	iError = 0;

	switch (iTypeGrid){
		case iTYPE_VITESSE:
			iGridHandle 	= PANEL_MODE_TABLE_VITESSES;
			iGrapheHandle 	= PANEL_MODE_GRAPHE_VITESSE;
			break;
		case iTYPE_PRESSION:
			iGridHandle 	= PANEL_MODE_TABLE_PRESSION;		
			iGrapheHandle 	= PANEL_MODE_GRAPHE_PRESSION;
			break;
	}

	// Suppression du popup menu (clic droit de la souris)
	SetCtrlAttribute (iPanel, iGridHandle, ATTR_ENABLE_POPUP_MENU, 0);
	
	// Lecture de la position du panel (coordonn�es en haut � gauche)
	GetPanelAttribute (iPanel, ATTR_LEFT, &iLeft);
	GetPanelAttribute (iPanel, ATTR_TOP, &iTop);

	iError = GstTablesGetRowColFromMouse(iPanel, iControl, &cell.y, &cell.x, &iX, &iY, &bValid);
	
	// D�termination du nombre de lignes du contr�le (data grid)
	iError = GetNumTableRows (iPanel, iControl, &iNumberOfRows);

	// Si le nombre de lignes est sup�rieur � z�ro
	if(iNumberOfRows > 0)
		// Emp�che l'affichage du popup de choix en dehors des cellules de la table
		if( (cell.y < 1) || (cell.y > iNumberOfRows) || (cell.x < 1) || (cell.x > 2))
			return 0;

	iError = GstTablesGstZoneSelect(iPanel, iControl, cell.y, cell.x,
									&rect.height, &rect.width, &rect.left,
									&rect.top, &bValid);
							
	//------------ Affichage du menu popup -------------------
	// S�lection des �l�ments du menu � inhiber
	switch (iTypeGrid){
		case iTYPE_VITESSE:
			if (GbValidCopySpeed){
				SetMenuBarAttribute (iPopupMenuHandle, GST_TAB_GST_COLLER, ATTR_DIMMED, 		0);
				SetMenuBarAttribute (iPopupMenuHandle, GST_TAB_GST_INSERT, ATTR_DIMMED, 		0);
				SetMenuBarAttribute (iPopupMenuHandle, GST_TAB_GST_INSERT_AFTER, ATTR_DIMMED, 	0);
			}else{
					SetMenuBarAttribute (iPopupMenuHandle, GST_TAB_GST_COLLER, ATTR_DIMMED, 		1);
					SetMenuBarAttribute (iPopupMenuHandle, GST_TAB_GST_INSERT, ATTR_DIMMED, 		1);
					SetMenuBarAttribute (iPopupMenuHandle, GST_TAB_GST_INSERT_AFTER, ATTR_DIMMED, 	1);
				 }
		break;
		case iTYPE_PRESSION:
			if(GbValidCopyPress){
				SetMenuBarAttribute (iPopupMenuHandle, GST_TAB_GST_COLLER, ATTR_DIMMED, 		0);
				SetMenuBarAttribute (iPopupMenuHandle, GST_TAB_GST_INSERT, ATTR_DIMMED, 		0);
				SetMenuBarAttribute (iPopupMenuHandle, GST_TAB_GST_INSERT_AFTER, ATTR_DIMMED, 	0);
			}else{
					SetMenuBarAttribute (iPopupMenuHandle, GST_TAB_GST_COLLER, ATTR_DIMMED, 		1);
					SetMenuBarAttribute (iPopupMenuHandle, GST_TAB_GST_INSERT, ATTR_DIMMED, 		1);
					SetMenuBarAttribute (iPopupMenuHandle, GST_TAB_GST_INSERT_AFTER, ATTR_DIMMED, 	1);
				 }
		break;
	}
	// Affichage du menu popup
	iIdSelected = RunPopupMenu (iPopupMenuHandle, GST_TAB_GST, iPanel, iY-iTop, iX-iLeft, 0, 0, 20, 20);			


	switch(iIdSelected){
		//---------- Ajout de lignes dans la liste ------------
		case GST_TAB_GST_ADD_1:
			// Valeurs par d�faut
			SetCtrlVal(iPopupAdd, POPUP_ADD_CHECK_BEFORE, 	0);  
			SetCtrlVal(iPopupAdd, POPUP_ADD_CHECK_AFTER, 	1); 
			SetCtrlVal(iPopupAdd, POPUP_ADD_NB_ROWS, 		1);

			// Affichage du popup de choix
			InstallPopup (iPopupAdd);
			// Attente de la r�ponse
			do{
				  ProcessSystemEvents();
			}while((!GiValidOk) && (!GiValidCancel));
			
			// Si appui sur OK
			if (GiValidOk){
				GetCtrlVal (iPopupAdd, POPUP_ADD_NB_ROWS, 		&iNbRowsToAdd);
				GetCtrlVal (iPopupAdd, POPUP_ADD_CHECK_AFTER, 	&iInsertAfter);
				
				// Supprime le popup de choix
				RemovePopup(0);

				iOneBaseRowIndex = cell.y;
				switch (iTypeGrid){
					case iTYPE_VITESSE:
						iNbMaxRows = iTAILLE_MAX_TAB;
					break;
					case iTYPE_PRESSION:  
						iNbMaxRows = iTAILLE_MAX_TAB;
					break;
				}
			
				if (iInsertAfter){
					iError = GstTablesAddRows(	iPanel, iControl, iOneBaseRowIndex,
												ptstConfig->dLimMinTpsSpeed, ptstConfig->dLimMinTpsPress,
												iNbMaxRows, iNbRowsToAdd, bINSERT_AFTER,
												iTypeGrid, ptstTabVitesse, ptstTabPression,
												&iNbRowsAdded, sMsgErr);
					if (iError < 0)
						AffStatusPanel(iPanel, iStatusPanel, iLEVEL_MSG,MessageIhmGet(sSECTION, iMSG_ERR_ADD_ROWS), 
										sMsgErr, ptiPanelStatusDisplayed, ptiAffMsg);
				}	
				else{
						iError = GstTablesAddRows(	iPanel, iControl, iOneBaseRowIndex,
												ptstConfig->dLimMinTpsSpeed, ptstConfig->dLimMinTpsPress,
												iNbMaxRows, iNbRowsToAdd, bINSERT_BEFORE,
												iTypeGrid, ptstTabVitesse, ptstTabPression,
												&iNbRowsAdded, sMsgErr);
						if (iError < 0)
							AffStatusPanel(iPanel, iStatusPanel, iLEVEL_MSG, MessageIhmGet(sSECTION, iMSG_ERR_ADD_ROWS), 
											sMsgErr, ptiPanelStatusDisplayed, ptiAffMsg);
					}
						
				// Mise � jour du graphique
				switch (iTypeGrid){
					case iTYPE_VITESSE:
						//GstGrapheMajGrapheVit(iPanel, iGridHandle, iGrapheHandle, 1, ptstTabVitesse->dDuree, ptstTabVitesse->dVit, ptstTabVitesse->iNbElmts, 1, iColorSpeed, 1);	
					break;
					case iTYPE_PRESSION:  
						//GstGrapheMajGraphePres(iPanel, iGridHandle, iGrapheHandle, 1, ptstTabPression->dDuree, ptstTabPression->dPress, ptstTabPression->iNbElmts, 1, iColorPress, 1);	
					break;
				}
			}
			else
				// Supprime le popup de choix
				RemovePopup(0);
				
			GiValidOk 		= 0;
			GiValidCancel	= 0;
			
			if(iError == 0)
				strcpy(sPathConfigFile, "");
		break; 
		
		//------------ Suppression d'une ou plusieurs lignes de la liste ------------
		case GST_TAB_GST_SUPPR:
			GiDisableMajGrapheVitesse 	= 1;
			GiDisableMajGraphePression 	= 1;
			
			GetTableSelection (iPanel, iControl, &rect);
			
			iError = GstTablesSupprSelect(	iPanel, iControl, rect.height, rect.width,
											rect.left, rect.top,iTypeGrid, 
											ptstTabVitesse, ptstTabPression, sMsgErr);
			if (iError < 0)
				AffStatusPanel(iPanel, iStatusPanel, iLEVEL_MSG, MessageIhmGet(sSECTION, iMSG_ERR_DEL_ROWS), 
								sMsgErr, ptiPanelStatusDisplayed, ptiAffMsg);											
		
			GiDisableMajGrapheVitesse 	= 0;
			GiDisableMajGraphePression 	= 0;
			
			switch (iTypeGrid){
				case iTYPE_VITESSE:
					// Mise � jour du graphique
					//GstGrapheMajGrapheVit(iPanel, iGridHandle, iGrapheHandle, 1, ptstTabVitesse->dDuree, ptstTabVitesse->dVit, ptstTabVitesse->iNbElmts, 1, iColorSpeed, 1);
				break;
				case iTYPE_PRESSION:				
					// Mise � jour du graphique
					//GstGrapheMajGraphePres(iPanel, iGridHandle, iGrapheHandle, 1, ptstTabPression->dDuree, ptstTabPression->dPress, ptstTabPression->iNbElmts, 1, iColorPress, 1);
				break;
			}
			
			if(iError == 0)
				strcpy(sPathConfigFile, "");
		break;
		
		//------------ Copier une s�lection de donn�es ------------
		case GST_TAB_GST_COPIER:
			iError = GetTableSelection (iPanel, iControl, &rect);
			if ((!iError) && (rect.top >= 1) && (rect.top <= iNumberOfRows)){
				// Enregistrement de la liste des donn�es � copier
				switch (iTypeGrid){
					case iTYPE_VITESSE:
						// Copie des donn�es en m�moire tampon
						iError = ClipboardPutTableVals (iPanel, iControl, rect);
						if (iError != 0){
							GbValidCopySpeed = 0;
							AffStatusPanel(iPanel, iStatusPanel, iLEVEL_MSG, MessageIhmGet(sSECTION, iMSG_ERR_COPY_DATA), 
											GetUILErrorString(iError), ptiPanelStatusDisplayed, ptiAffMsg);
						}
						else{
								GrCopieSelectVit = rect;
								GbValidCopySpeed = 1;
								GbValidCopyPress = 0;
							}
					break;
					case iTYPE_PRESSION:  
						// Copie des donn�es en m�moire tampon
						iError = ClipboardPutTableVals (iPanel, iControl, rect);
						if (iError != 0){
							GbValidCopyPress = 0;
							AffStatusPanel(iPanel, iStatusPanel, iLEVEL_MSG, MessageIhmGet(sSECTION, iMSG_ERR_COPY_DATA), 
											GetUILErrorString(iError), ptiPanelStatusDisplayed, ptiAffMsg);							
						}
						else{
								GrCopieSelectPres = rect;
								GbValidCopySpeed = 0;
								GbValidCopyPress = 1;
							}   
					break;
				}
			}
		break; 
		
		//------------ Coller une s�lection de donn�es ------------
		case GST_TAB_GST_COLLER:
			GiDisableMajGrapheVitesse 	= 1;
			GiDisableMajGraphePression 	= 1;
			
			iError = GetTableSelection (iPanel, iControl, &rect);
			
			switch (iTypeGrid){
				case iTYPE_VITESSE:
					rCopie = GrCopieSelectVit;
				break;
				case iTYPE_PRESSION:  
					rCopie = GrCopieSelectPres;
				break;
			}
			
			// Coller les donn�es
			rect.height = rCopie.height;
			rect.width  = rCopie.width;
			iError = ClipboardGetTableVals (iPanel, iControl, rect, &iAvailable);
			if (iError != 0){
				AffStatusPanel(iPanel, iStatusPanel, iLEVEL_MSG, MessageIhmGet(sSECTION, iMSG_ERR_PASTE_DATA), 
								GetUILErrorString(iError), ptiPanelStatusDisplayed, ptiAffMsg);			
			}
			else
				if(iAvailable != 1){
					AffStatusPanel(iPanel, iStatusPanel, iLEVEL_MSG, MessageIhmGet(sSECTION, iMSG_ERR_PASTE_DATA), 
									MessageIhmGet(sSECTION, iMSG_ERR_NO_DATA_AVAIL), ptiPanelStatusDisplayed, ptiAffMsg);				
				}

			// Recopie des donn�es dans le tableau de donn�es
			iError = GstTablesMajTableau(iPanel, iControl, iTypeGrid, 
										ptstTabVitesse, ptstTabPression, sMsgErr);
			if(iError < 0)							
				AffStatusPanel(iPanel, iStatusPanel, iLEVEL_MSG, MessageIhmGet(sSECTION, iMSG_ERR_MAJ_DATA), 
								sMsgErr, ptiPanelStatusDisplayed, ptiAffMsg);										


			GiDisableMajGrapheVitesse 	= 0;
			GiDisableMajGraphePression 	= 0;
		
			switch (iTypeGrid){
				case iTYPE_VITESSE:
					// Mise � jour du graphique
					//GstGrapheMajGrapheVit(iPanel, iGridHandle, iGrapheHandle, 1, ptstTabVitesse->dDuree, ptstTabVitesse->dVit, ptstTabVitesse->iNbElmts, 1, iColorSpeed, 1);
				break;
				case iTYPE_PRESSION:				
					// Mise � jour du graphique
					//GstGrapheMajGraphePres(iPanel, iGridHandle, iGrapheHandle, 1, ptstTabPression->dDuree, ptstTabPression->dPress, ptstTabPression->iNbElmts, 1, iColorPress, 1);
				break;
			}		

			if(iError == 0)
				strcpy(sPathConfigFile, "");
		break;
		
		//------------ Insertion des valeurs pr�c�demment copi�es avant la ligne s�lectionn�e ------------
		case GST_TAB_GST_INSERT:
			GiDisableMajGrapheVitesse 	= 1;
			GiDisableMajGraphePression 	= 1;
			
			// Ajout du nombre de lignes n�cessaire
			iError = GetTableSelection (iPanel, iControl, &rect);
			
			switch (iTypeGrid){
				case iTYPE_VITESSE:
					rCopie = GrCopieSelectVit;
				break;
				case iTYPE_PRESSION:  
					rCopie = GrCopieSelectPres;
				break;
			}
			
			iOneBaseRowIndex = rect.top;
			iNbRowsToAdd = rCopie.height;
			switch (iTypeGrid){
				case iTYPE_VITESSE:
					iNbMaxRows = iTAILLE_MAX_TAB;
				break;
				case iTYPE_PRESSION:  
					iNbMaxRows = iTAILLE_MAX_TAB;
				break;
			}   

			// Insertion de lignes avant de coller les donn�es
			iError = GstTablesAddRows(	iPanel, iControl, iOneBaseRowIndex, 
										ptstConfig->dLimMinTpsSpeed, ptstConfig->dLimMinTpsPress,
										iNbMaxRows, iNbRowsToAdd, bINSERT_BEFORE,
										iTypeGrid, ptstTabVitesse, ptstTabPression,
										&iNbRowsAdded, sMsgErr);				
			if(iError < 0)
				AffStatusPanel(iPanel, iStatusPanel, iLEVEL_MSG, MessageIhmGet(sSECTION, iMSG_ERR_MAJ_DATA), 
								sMsgErr, ptiPanelStatusDisplayed, ptiAffMsg);										

			
			// Coller les donn�es
			rect.height = rCopie.height;
			rect.width  = rCopie.width;
			iError = ClipboardGetTableVals (iPanel, iControl, rect, &iAvailable);
			if (iError != 0){
				AffStatusPanel(iPanel, iStatusPanel, iLEVEL_MSG, MessageIhmGet(sSECTION, iMSG_ERR_INSERT), 
								GetUILErrorString(iError), ptiPanelStatusDisplayed, ptiAffMsg);			
			}
			else
				if(iAvailable != 1){
					AffStatusPanel(iPanel, iStatusPanel,iLEVEL_MSG,  MessageIhmGet(sSECTION, iMSG_ERR_INSERT), 
									MessageIhmGet(sSECTION, iMSG_ERR_NO_DATA_AVAIL), ptiPanelStatusDisplayed, ptiAffMsg);				
				}


			// Recopie des donn�es dans le tableau de donn�es
			iError = GstTablesMajTableau(iPanel, iControl, iTypeGrid, 
										ptstTabVitesse, ptstTabPression, sMsgErr);			
			if(iError < 0)
				AffStatusPanel(iPanel, iStatusPanel, iLEVEL_MSG, MessageIhmGet(sSECTION, iMSG_ERR_MAJ_DATA), 
								sMsgErr, ptiPanelStatusDisplayed, ptiAffMsg);										


			GiDisableMajGrapheVitesse 	= 0;
			GiDisableMajGraphePression 	= 0;
		
			switch (iTypeGrid){
				case iTYPE_VITESSE:
					// Mise � jour du graphique
					//GstGrapheMajGrapheVit(iPanel, iGridHandle, iGrapheHandle, 1, ptstTabVitesse->dDuree, ptstTabVitesse->dVit, ptstTabVitesse->iNbElmts, 1, iColorSpeed, 1);
				break;
				case iTYPE_PRESSION:				
					// Mise � jour du graphique
					//GstGrapheMajGraphePres(iPanel, iGridHandle, iGrapheHandle, 1, ptstTabPression->dDuree, ptstTabPression->dPress, ptstTabPression->iNbElmts, 1, iColorPress, 1);
				break;
			}	
			
			if(iError == 0)
				strcpy(sPathConfigFile, "");
		break;
		
		//------------ Insertion des valeurs pr�c�demment copi�es apr�s la ligne s�lectionn�e ------------
		case GST_TAB_GST_INSERT_AFTER:
			GiDisableMajGrapheVitesse 	= 1;
			GiDisableMajGraphePression 	= 1;
			
			// Ajout du nombre de lignes n�cessaire
			iError = GetTableSelection (iPanel, iControl, &rect);
			
			switch (iTypeGrid){
				case iTYPE_VITESSE:
					rCopie = GrCopieSelectVit;
				break;
				case iTYPE_PRESSION:  
					rCopie = GrCopieSelectPres;
				break;
			}
			
			iOneBaseRowIndex = rect.top;
			iNbRowsToAdd = rCopie.height;
			switch (iTypeGrid){
				case iTYPE_VITESSE:
					iNbMaxRows = iTAILLE_MAX_TAB;
				break;
				case iTYPE_PRESSION:  				
					iNbMaxRows = iTAILLE_MAX_TAB;
				break;
			}   

			// Insertion de lignes avant de coller les donn�es
			iError = GstTablesAddRows(	iPanel, iControl, iOneBaseRowIndex, 
										ptstConfig->dLimMinTpsSpeed, ptstConfig->dLimMinTpsPress,
										iNbMaxRows, iNbRowsToAdd, bINSERT_AFTER,
										iTypeGrid, ptstTabVitesse, ptstTabPression,
										&iNbRowsAdded, sMsgErr);				
			if(iError < 0)
				AffStatusPanel(iPanel, iStatusPanel, iLEVEL_MSG, MessageIhmGet(sSECTION, iMSG_ERR_MAJ_DATA), 
								sMsgErr, ptiPanelStatusDisplayed, ptiAffMsg);									

			
			// Coller les donn�es
			rect.top = rect.top + 1;
			rect.height = rCopie.height;
			rect.width  = rCopie.width;
			iError = ClipboardGetTableVals (iPanel, iControl, rect, &iAvailable);
			if (iError != 0){
				AffStatusPanel(iPanel, iStatusPanel, iLEVEL_MSG, MessageIhmGet(sSECTION, iMSG_ERR_INSERT), 
								GetUILErrorString(iError), ptiPanelStatusDisplayed, ptiAffMsg);							
			}

			// Recopie des donn�es dans le tableau de donn�es
			iError = GstTablesMajTableau(iPanel, iControl, iTypeGrid, 
										ptstTabVitesse, ptstTabPression, sMsgErr);			
			if(iError < 0)
				AffStatusPanel(iPanel, iStatusPanel, iLEVEL_MSG, MessageIhmGet(sSECTION, iMSG_ERR_MAJ_DATA), 
								sMsgErr, ptiPanelStatusDisplayed, ptiAffMsg);										


			GiDisableMajGrapheVitesse 	= 0;
			GiDisableMajGraphePression 	= 0;
		
			switch (iTypeGrid){
				case iTYPE_VITESSE:
					// Mise � jour du graphique
					//GstGrapheMajGrapheVit(iPanel, iGridHandle, iGrapheHandle, 1, ptstTabVitesse->dDuree, ptstTabVitesse->dVit, ptstTabVitesse->iNbElmts, 1, iColorSpeed, 1);
				break;
				case iTYPE_PRESSION:				
					// Mise � jour du graphique
					//GstGrapheMajGraphePres(iPanel, iGridHandle, iGrapheHandle, 1, ptstTabPression->dDuree, ptstTabPression->dPress, ptstTabPression->iNbElmts, 1, iColorPress, 1);
				break;
			}
			
			if(iError == 0)
				strcpy(sPathConfigFile, "");
		break;		
		
		//------------ Agrandissement de la taille de la liste ------------
		case GST_TAB_GST_AGRANDIR:
			switch (iTypeGrid){
				case iTYPE_VITESSE:
					SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_PRESSION, ATTR_VISIBLE, 	0);
					SetCtrlAttribute (iPanel, PANEL_MODE_UNIT_PRESSION,  ATTR_VISIBLE,  0);
					SetCtrlAttribute (iPanel, PANEL_MODE_UNIT_VITESSE, 	ATTR_VISIBLE, 	0);
					
					SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_VITESSES, ATTR_TOP, 		47);
					SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_VITESSES, ATTR_LEFT, 	11);
					SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_VITESSES, ATTR_HEIGHT, 	488);
					SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_VITESSES, ATTR_WIDTH, 	220);
				break;
				case iTYPE_PRESSION:
					SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_VITESSES, ATTR_VISIBLE, 	0);
					SetCtrlAttribute (iPanel, PANEL_MODE_UNIT_PRESSION,  ATTR_VISIBLE,  0);
					SetCtrlAttribute (iPanel, PANEL_MODE_UNIT_VITESSE, 	ATTR_VISIBLE, 	0);

					SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_PRESSION, ATTR_TOP, 		47);
					SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_PRESSION, ATTR_LEFT, 	11);
					SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_PRESSION, ATTR_HEIGHT, 	488);
					SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_PRESSION, ATTR_WIDTH, 	220);
				break;
			}		
		break;
		//------------ Restauration de la taille de la liste ------------
		case GST_TAB_GST_RESTAURER:
			switch (iTypeGrid){
				case iTYPE_VITESSE:
					SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_PRESSION, ATTR_VISIBLE, 	1);
					SetCtrlAttribute (iPanel, PANEL_MODE_UNIT_PRESSION,  ATTR_VISIBLE,  1);
					SetCtrlAttribute (iPanel, PANEL_MODE_UNIT_VITESSE, 	ATTR_VISIBLE, 	1);
					
					SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_VITESSES, ATTR_TOP, 		47);
					SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_VITESSES, ATTR_LEFT, 	11);
					SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_VITESSES, ATTR_HEIGHT, 	202);
					SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_VITESSES, ATTR_WIDTH, 	220);
				break;
				case iTYPE_PRESSION:
					SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_VITESSES, ATTR_VISIBLE, 	1);
					SetCtrlAttribute (iPanel, PANEL_MODE_UNIT_PRESSION,  ATTR_VISIBLE,  1);
					SetCtrlAttribute (iPanel, PANEL_MODE_UNIT_VITESSE, 	ATTR_VISIBLE, 	1);
					
					SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_PRESSION, ATTR_TOP, 		313);
					SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_PRESSION, ATTR_LEFT, 	11);
					SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_PRESSION, ATTR_HEIGHT, 	202);
					SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_PRESSION, ATTR_WIDTH, 	220);
				break;
			}		
		break;
	}
	
	return 0;
}

// DEBUT ALGO
//****************************************************************************** 
//int CVICALLBACK GstOptAddOk (int panel, int control, int event,
//		void *callbackData, int eventData1, int eventData2)
//****************************************************************************** 
//	-  Param�tres CVI
//
//  - Appui sur le bouton OK de la boite de dialogue pour l'ajout de lignes
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
// FIN ALGO
int CVICALLBACK GstOptAddOk (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event){
		case EVENT_COMMIT:
			GiValidOk 		= 1;	
			GiValidCancel 	= 0;
		break;
	}
	return 0;
}

// DEBUT ALGO
//****************************************************************************** 
//int CVICALLBACK GstOptAddCancel (int panel, int control, int event,
//		void *callbackData, int eventData1, int eventData2)
//****************************************************************************** 
//	- Param�tres CVI
//
//  - Appui sur le bouton Cancel de la boite de dialogue pour l'ajout de lignes
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
// FIN ALGO
int CVICALLBACK GstOptAddCancel (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event){
		case EVENT_COMMIT:
			GiValidCancel 	= 1;
			GiValidOk 		= 0;	
		break;
	}
	return 0;
}

// DEBUT ALGO
//****************************************************************************** 
//int CVICALLBACK GstCheck (int panel, int control, int event,
//		void *callbackData, int eventData1, int eventData2)
//****************************************************************************** 
//	- Param�tres CVI
//
//  - Gestion du choix de l'ajout de lignes avant ou apres la ligne courante
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
// FIN ALGO
int CVICALLBACK GstCheck (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event){
		case EVENT_COMMIT:
		if (control == POPUP_ADD_CHECK_BEFORE){
			SetCtrlVal(panel, POPUP_ADD_CHECK_BEFORE, 1);  
			SetCtrlVal(panel, POPUP_ADD_CHECK_AFTER,  0);  
		}
		else{
				SetCtrlVal(panel, POPUP_ADD_CHECK_BEFORE, 0);  
				SetCtrlVal(panel, POPUP_ADD_CHECK_AFTER,  1);  				
			}
		break;
	}
	return 0;
}
