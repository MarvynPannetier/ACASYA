// DEBUT TABLE
//******************************************************************************
// PRO: BANC DE TEST LSE
// PRG: GstFiles.h
// VER: Version I00A00A du 09/08/2010
// AUT: C. BERENGER / MICROTEC
//
// ROL: Gestion des fichiers
//
// HST: Version I00A00A du 09/08/2010 / C. BERENGER MICROTEC / Cr�ation
//******************************************************************************
//
//*************************************************************************** 
// FIN TABLE
#ifndef LIB_GST_FILES
 #define LIB_GST_FILES

//***************************************************************************
// inclusions
//***************************************************************************

// Librairies standards

// Librairie FOURNISSEUR

// Librairie MICROTEC
#include "ResultTextFile.h"

// Librairie sp�cifiques � l'application

//***************************************************************************
// D�finition de constantes
//***************************************************************************
#define sSECTION					"IhmModes"

#define sCONFIG		 			"Cycles"
#define sCONFIG_LOAD 			"Load"
#define sCONFIG_SAVE 			"Save"
#define sAUTO_MODE	 			"Automatic Mode"
#define sMANU_MODE	 			"Manual Mode"
#define sQUIT		 			"Back"  //Modif MaximePAGES 09/09/2020
//--------- Speed and Pressure arrays ------------
#define sTITLE_TAB_VIT	 		"SPEED/ACCEL"
#define sTITLE_TAB_PRES	 		"PRESSURE"
#define sUNIT_VIT_KM_H			"km/h"
#define sUNIT_VIT_G				"g"
#define sUNIT_VIT_TRS_MIN 		"trs/min"
#define sUNIT_PRES_KPA	 		"kPa"
#define sUNIT_PRES_BAR	 		"bars"
#define sUNIT_PRES_MBAR	 		"mBars"
#define sUNIT_PRES_PSI	 		"Psi"
#define sUNIT_DUREE		 		"Duration (s)"
//--------- Buttons ------------------------------
#define sBOUTON_DEP_VIT		 	"Start Speed cycle"
#define sBOUTON_DEP_PRES	 	"Start Pressure cycle"
#define sBOUTON_DEP_VIT_PRES 	"Start Speed and Pressure Cycles"
#define sBOUTON_STOP_VIT	 	"Stop Speed cycle"
#define sBOUTON_STOP_PRES	 	"Stop Pressure cycle"
#define sBOUTON_STOP_VIT_PRES 	"Stop Speed and Pressure Cycles"

//;--- Button Nbr Cycles -------------------------
#define sNBRE_CYCLES			"NBR Cycles"
#define sNUM_CYCLE			 	"Cycle N�"
#define sAFFICH_VITESSE_KM_H 	"Speed (km/h)"
#define sAFFICH_VITESSE_G	 	"Accel (g) and Pressure (kPa)"
#define sAFFICH_VITESSE_TRS_MIN "Speed (trs/min)"
#define sAFFICH_PRES_KPA	 	"Pressure (kPa)"
#define sAFFICH_PRES_BARS	 	"Pressure (bars)"
#define sAFFICH_PRES_MBAR	 	"Pressure (mBars)"
#define sAFFICH_PRES_PSI	 	"Pressure (Psi)"
#define sAFFICH_TEMPS		 	"Time (s)"

#define sTITRE_ZONE_MSG		 	"Messages"
#define sBOUTON_VALID_VIT	 	"Valid Speed/Accel"
#define sBOUTON_VALID_PRES	 	"Valid Pressure"
#define sBOUTON_VALID_VIT_PRES 	"Valid Speed and Pressure"
								
//;--- Popup menu ---------------------------------
#define sPOPUP_MENU_AJOUTER	 	"Add..."
#define sPOPUP_MENU_SUPPRIMER 	"Suppress"
#define sPOPUP_MENU_COPIER	 	"Copy"
#define sPOPUP_MENU_COLLER	 	"Paste"
#define sPOPUP_MENU_AGRANDIR 	"Enlarge"
#define sPOPUP_MENU_RESTAURER 	"Restore"
#define sPOPUP_MENU_INSERT	 	"Insert before"

//--- Comments -----------------------------------
#define sTITRE_COMMENTAIRES		"Comments"

	
//--------- Menu principal ----------
#define iCONFIG						0
#define iCONFIG_LOAD				1
#define iCONFIG_SAVE				2
#define iAUTO_MODE					3
#define iMANU_MODE					4
#define iQUIT						5

//--------- Tables Vitesse et pression ----------
#define iTITLE_TAB_VIT				6
#define iTITLE_TAB_PRES				7

#define iUNIT_VIT_KM_H				8
#define iUNIT_VIT_G					9
#define iUNIT_VIT_TRS_MIN			10
#define iUNIT_PRES_KPA				11
#define iUNIT_PRES_BAR				12
#define iUNIT_PRES_MBAR				13
#define iUNIT_PRES_PSI				14
#define iUNIT_DUREE					15

//--------- Boutons ----------
#define iBOUTON_DEP_VIT				16
#define iBOUTON_DEP_PRES			17
#define iBOUTON_DEP_VIT_PRES		18
#define iBOUTON_STOP_VIT			19
#define iBOUTON_STOP_PRES			20
#define iBOUTON_STOP_VIT_PRES		21

//--------- Affichages ----------
#define iNBRE_CYCLES				22
#define iNUM_CYCLE					23
#define iAFFICH_VITESSE_KM_H		24
#define iAFFICH_VITESSE_G			25
#define iAFFICH_VITESSE_TRS_MIN		26
#define iAFFICH_PRES_KPA			27
#define iAFFICH_PRES_BARS			28
#define iAFFICH_PRES_MBAR			29
#define iAFFICH_PRES_PSI			30
#define iAFFICH_TEMPS				31

#define iTITRE_ZONE_MSG				32

#define iBOUTON_VALID_VIT			33
#define iBOUTON_VALID_PRES			34
#define iBOUTON_VALID_VIT_PRES		35

#define iPOPUP_MENU_AJOUTER			36
#define iPOPUP_MENU_SUPPRIMER		37
#define iPOPUP_MENU_COPIER			38
#define iPOPUP_MENU_COLLER			39
#define iPOPUP_MENU_AGRANDIR		40
#define iPOPUP_MENU_RESTAURER		41
#define iPOPUP_MENU_INSERT			42

#define iTITRE_COMMENTAIRES			43

 
//------------------------------------
#define bSAVE_ONE_VIT				1
#define bSAVE_ALL_VIT				0
#define bSAVE_ONE_PRES				1
#define bSAVE_ALL_PRES				0
#define bSAVE_VIT					1
#define bDONT_SAVE_VIT				0
#define bSAVE_PRES					1
#define bDONT_SAVE_PRES				0

// Taille maximale d'un tableau de donn�es
#define iTAILLE_MAX_TAB				16000

//***************************************************************************
// D�finition de types et structures
//***************************************************************************
// Configuration
typedef struct{
	int iSpeedUnit;
	int iSpeedComPort;
	int iSpeedComSpeed;
	int iPressUnit;
	int iReadDelay;
	int iPressCommandDelay;
	int iAccelGCmdeDelay;
	//-- Coefficients de conversion Vitesse --
	double dCoeffAKmH;
	double dCoeffBKmH;
	double dCoeffAG;
	double dCoeffBG;
	//-- Coefficients de conversion Pression --
	double dCoeffAKpa;
	double dCoeffBKpa;
	double dCoeffAPsi;
	double dCoeffBPsi;
	double dCoeffAMbar;
	double dCoeffBMbar;
	
	double dLimMinKmH;
	double dLimMaxKmH; 
	double dLimMinG; 
	double dLimMaxG; 
	double dLimMinTrsMin;
	double dLimMaxTrsMin;
	
	double dLimMinTpsSpeed;
	double dLimMaxTpsSpeed;
	
	double dLimMinKpa; 
	double dLimMaxKpa; 
	double dLimMinPsi; 
	double dLimMaxPsi; 
	double dLimMinMbar;
	double dLimMaxMbar;		
	double dLimMinBar;
	double dLimMaxBar;
	
	double dLimMinTpsPress;
	double dLimMaxTpsPress;	
	
	double dPlageAffichManu;
	
	int iUseWatchdog;
	int iSaveResults;
}stConfig;

//--- Vitesse ---------
typedef struct{
	int iNbElmts;
	double dVit[iTAILLE_MAX_TAB];
	double dDuree[iTAILLE_MAX_TAB];
	BOOL bWarningData[iTAILLE_MAX_TAB];
	BOOL bWarningDuree[iTAILLE_MAX_TAB];
}stTabVitesse;

//--- Pression --------
typedef struct{
	int iNbElmts;
	double dPress[iTAILLE_MAX_TAB];
	double dDuree[iTAILLE_MAX_TAB];
	BOOL bWarningData[iTAILLE_MAX_TAB];
	BOOL bWarningDuree[iTAILLE_MAX_TAB];
}stTabPression;

//******************************************************************************
// Fonctions externes au source
//******************************************************************************

//  - Reset de la librairie d'enregistrement des fichiers r�sultats
int GstFilesResetAll(stTabFile *TabData);

void GstFilesGetDonneesPosition(char *sStringPosition, unsigned int uiNumIndex, 
								char *sValeur, int iSizeMaxBuffer);

//***************************************************************************
//  - char *sDateHeure: Chaine de caract�res contenant la date et l'heure
//
//  - Cr�ation d'une chaine de caract�res contenant la date et l'heure
//
//  - Aucun
//***************************************************************************
void GstFilesGetStringDateHeure(char *sDateHeure);

//***************************************************************************
//	- int iHandleFile   : Handle du fichier
//
//  - Fermeture du fichier r�sultats
//
//  - 0 si pas d'erreur, sinon code d'erreur
//***************************************************************************
int GstFilesCloseResultFile(stTabFile *TabData, int iHandleFile, char *sErrMsg);

//***************************************************************************
//	- int iHandleFile   : Handle du fichier
//    char *sLine 		: Ligne � ajouter dans le fichier r�sultats
//	  BOOL bCloseFile	: 1 = Ferme le fichier, 0= Laisse le fichier ouvert
//
//  - Ajout d'une ligne dans le fichier r�sultats
//
//  - 0 si pas d'erreur, sinon code d'erreur
//***************************************************************************
int GstFilesAddResultFiles(stTabFile *TabData, int iHandleFile, char *sLine, BOOL bCloseFile, char *sErrMsg);


//***************************************************************************
//  - BOOL bCopyConfig		:1 = Copie le fichier de configuration, sinon 0
//	  char *sPathConfigFile : Chemin complet vers le fichier de configuration
//	  char *sRepertoire	: Nom du r�pertoire
//	  char *sFileName	: Nom du fichier � cr�er
//	  char *sExtension	: Nom de l'extension du fichier (ex: "csv")
//	  int *ptiHandleFile: Pointeur vers le fichier cr��
//
//  - Cr�ation d'un fichier r�sultats
//
//  - 0 si pas d'erreur, sinon code d'erreur
//***************************************************************************
int GstFilesCreateResultFiles(BOOL bCopyConfig, char *sPathConfigFile, stTabFile *TabData, 
							char *sRepertoire, char *sFileName, char *sExtension, int *ptiHandleFile, char *sErrMsg);

//****************************************************************************** 
//	- int iPanel						: Panel de l'�cran d'essai
//	  stTabVitesse *ptstTabVitesse 		: Pointeur sur le Tableau des vitesses � sauvegarder
//	  stTabPression *ptstTabPression	: Pointeur sur le Tableau des pressions � sauvegarder
//	  int iNbreCyclesVit				: Nombre de cycles de vitesses pr�vus
//	  int iNbreCyclesPress				: Nombre de cycles de pression pr�vus
//	  int iUnitVitesse					: Unit� de vitesse choisie
//	  int iUnitPression					: Unit� de pression choisie
//	  BOOL bSaveOneVit					: 1=Sauve uniquement la vitesse dont l'unit� est s�lectionn�e, sinon 0
//	  BOOL bSaveOnePres					: 1=Sauve uniquement la pression dont l'unit� est s�lectionn�e, sinon 0
//	  BOOL bSaveVit						: 1=Sauver la configuration des pressions, sinon 0
//	  BOOL bSavePress					: 1=Sauver la configuration des vitesses, sinon 0
//	  char *sFileName					: Nom complet du fichier de sauvegarde  
//	  char *sErrorMsg					: Message d'erreur
//	  int iSizeMaxErrMsg				: Taille maximale du message d'erreur
// 
//
//  - Sauvegarde d'une configuration d'essai dans un fichier
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
int GstFilesSaveConfig (int iPanel, stTabVitesse *ptstTabVitesse, stTabPression *ptstTabPression, 
						int iNbreCyclesVit, int iNbreCyclesPress, int iUnitVitesse,
						int iUnitPression, BOOL bSaveOneVit, 
						BOOL bSaveOnePres, BOOL bSaveVit, BOOL bSavePress, char *sFileName,
						char *sErrorMsg, int iSizeMaxErrMsg);

//****************************************************************************** 
//	- int iPanel						: Handle du panel
//	  int iSpeedCtrlId					: Handle du tableau des vitesses
//	  int iPressCtrlId					: Handle du tableau des pressions
//	  int iMsgId						: Handle de la zone de message de l'�cran d'essai
//	  stConfig *ptstConfig, 			: Pointeur vers les param�tres de configuration
//	  stTabVitesse *ptstTabVitesse 		: Pointeur sur le Tableau des vitesses � sauvegarder
//	  stTabPression *ptstTabPression	: Pointeur sur le Tableau des pressions � sauvegarder
//	  int *ptiNbreCyclesVit				: Nombre de cycles de vitesses pr�vus
//	  int *ptiNbreCyclesPress			: Nombre de cycles de pression pr�vus
//	  int *ptiUnitVitesse				: Unit� de vitesse choisie
//	  int *ptiUnitPression				: Unit� de pression choisie
//    char *sComments					: Commentaires assosci�s � l'essai
//	  BOOL *ptbSaveOneVit				: 1=Sauve uniquement la vitesse dont l'unit� est s�lectionn�e, sinon 0
//	  BOOL *ptbSaveOnePres				: 1=Sauve uniquement la pression dont l'unit� est s�lectionn�e, sinon 0
//	  char *sFileName					: Nom complet du fichier de sauvegarde  
// 
//
//  - Chargement d'une configuration d'essai � partir d'un fichier
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
int GstFilesLoadConfig (int iPanel, int iSpeedCtrlId, int iPressCtrlId, int iMsgId,
						stConfig *ptstConfig, stTabVitesse *ptstTabVitesse, stTabPression *ptstTabPression, 
						int *ptiNbreCyclesVit, int *ptiNbreCyclesPress, int *ptiUnitVitesse,
						int *ptiUnitPression, char *sComments, BOOL *ptbSaveOneVit, 
						BOOL *ptbSaveOnePres, char *sFileName, char *sErrorMsg, int iSizeMaxErrMsg);

//****************************************************************************** 
//	- int iPanel			: Handle du panel 
//	  int iPopupMenuHandle  : Handle du menu popup
//	  int iStatusPanel		: Handle du panel de status
//	  int iUnitVitesse		: Unit� s�lectionn�e pour la vitesse
//	  int iUnitPression		: Unit� s�lectionn�e pour la pression
//
//  - Traduction de l'IHM des modes Automatique/Manuel
//
//  - 0 si Ok
//	  -1 sinon
//****************************************************************************** 
int GstFilesTraductIhmModes(int iPanel, int iPopupMenuHandle, int iStatusPanel, int iUnitVitesse, int iUnitPression);

//****************************************************************************** 
//	- char *sPathName		: Chemin complet vers le fichier de configuration
//	  stConfig *ptstConfig	: Pointeur vers la structure des param�tres de configuration
//	  char *ErrorMsg		: Vide ou Message d'erreur
//
//  - Lecture du fichier de configuration
//
//  - 0 si Ok
//	  -1 sinon
//****************************************************************************** 
int GstFilesReadConfigFile(char *sPathName, stConfig *ptstConfig, char *ErrorMsg);

#endif
