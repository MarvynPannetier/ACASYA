//---------------------------------------------------------------------------
// API INTERFACE
//---------------------------------------------------------------------------
// History :
// 01 : creation

//---------------------------------------------------------------------------
// INTERFACE DEFINITION
//---------------------------------------------------------------------------
//typedef unsigned char __stdcall (*TAPI)(char *Command, void *Structure);
#ifdef __cplusplus
	extern "C"{
#endif
typedef unsigned char (WINAPI* TAPI)(char *Command, void *Structure);

//---------------------------------------------------------------------------
// STRUCTURES DEFINITION
//---------------------------------------------------------------------------
// Structure for all ANUMLFRF commands
#define API_STRING_SIZE 1024
struct TAPILFRF
{
    char          StringIn1[API_STRING_SIZE];
    char          StringIn2[API_STRING_SIZE];
    char          StringIn3[API_STRING_SIZE];
    char          StringIn4[API_STRING_SIZE];
    unsigned char ByteIn1;
    unsigned char ByteIn2;
    unsigned char ByteIn3;
    unsigned char ByteIn4;

    char          StringOut1[API_STRING_SIZE];
    char          StringOut2[API_STRING_SIZE];
    char          StringOut3[API_STRING_SIZE];
    char          StringOut4[API_STRING_SIZE];
    unsigned char ByteOut1;
    unsigned char ByteOut2;
    unsigned char ByteOut3;
    unsigned char ByteOut4;
};


//---------------------------------------------------------------------------
// RETURN VALUES
//---------------------------------------------------------------------------
#define API_OK              0x00    // If no error occur
#define API_ER_COMMAND      0x02    // Command name is not recognized
#define API_ERROR           0x03    // Specific error (see for each function)


//---------------------------------------------------------------------------
// COMMANDES
//---------------------------------------------------------------------------
/*
    LOAD : Load a configuration file
    --------------------------------
        IN  : StringIn1 = path and file name
        OUT : -
        RET : ERROR if file not exists else OK

    RUN : Start run
    ---------------
        IN  : -
        OUT : -
        RET : OK or ERROR (licence expired)

    LFPWR : modify the LF Power
    ---------------------------
        IN  : ByteIn1 = level [0..100]%
        OUT : -
        RET : OK or ERROR

    SENDF : Send a frame (yet defined in the list)
    ----------------------------------------------
        IN  : StringIn1  = Frame name
              ByteIn1    = Number of frames  [1..255]
              ByteIn2    = Interframe [0..255]ms
        OUT : -
        RET : OK or ERROR if the frame is not defined

    FSENT : Return flag to indicate the frame is sent
    ----------------------------------------------
        IN  : -
        OUT : ByteOut1 = 1 if Frame sent, else 0
        RET : OK

    FEXISTS : Return flag if the frame name is in the list
    -----------------------------------------------------
        IN  : StringIn1  = Frame name
        OUT : ByteOut1 = 1 if Frame exists, else 0
        RET : OK

    FREAD : Read a received frame
    -------------------------------------
        IN  : -
        OUT : ByteOut1   = Number of received frames
              StringOut1 = 1st received frame (complete)
              StringOut2 = 1st received frame (Hex field only)
        RET : OK

    IDREAD : Read the ID field in the 1st received frame
    ----------------------------------------------------
        IN  : -
        OUT : ByteOut1   = 1 if ID field exists, else 0
              StringOut1 = Received ID value
              StringOut2 = Received frame
        RET : OK

    STOP : Stop the run
    -------------------
        IN  : -
        OUT : -
        RET : OK

    STOPF : Stop LF emission(in case of CONT)
    ----------------------------------------------
        IN  : -
        OUT : -
        RET : OK

    CLRBUF : Clear the received buffer
    ----------------------------------
        IN  : -
        OUT : -
        RET : OK

    CALLBACK : define the callback function address
    -----------------------------------------------
        IN  : StringIn1 = callback function address (decimal format)
        OUT : -
        RET : OK or ERROR in case of address erro

    IDFILTER : specify the ID to be received
    ----------------------------------------------------
        IN  : List of ID, or null string for all ID
        OUT : -
        RET : OK

*/

   #ifdef __cplusplus
	}
#endif
