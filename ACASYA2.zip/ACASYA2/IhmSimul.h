/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/* Copyright (c) National Instruments 2010. All Rights Reserved.          */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL_SIMU                      1
#define  PANEL_SIMU_SECURITY_HOOD        2
#define  PANEL_SIMU_VARIATOR_COMM        3
#define  PANEL_SIMU_CONS_ATTEINTE        4
#define  PANEL_SIMU_ENGINE_WAY           5
#define  PANEL_SIMU_VENTILATION_FORCEE   6
#define  PANEL_SIMU_GACHE_OUVERTE        7
#define  PANEL_SIMU_USB6008_COMM         8
#define  PANEL_SIMU_DOOR_2               9
#define  PANEL_SIMU_DOOR_1               10
#define  PANEL_SIMU_ENGINE_RUNNING       11
#define  PANEL_SIMU_EMERGENCY_STOP       12
#define  PANEL_SIMU_SECURITY_LOOP        13
#define  PANEL_SIMU_SIMU_SPEED           14
#define  PANEL_SIMU_SIMU_PRESS           15
#define  PANEL_SIMU_RAMPE_ACCELERATION   16
#define  PANEL_SIMU_SPEED_TO_PROG        17
#define  PANEL_SIMU_PRESS_TO_PROG        18


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* (no callbacks specified in the resource file) */ 


#ifdef __cplusplus
    }
#endif
