// DEBUT TABLE
//******************************************************************************
// PRO: BANC DE TEST LSE
// PRG: GstGraphe.h
// VER: Version I00A00A du 09/08/2010
// AUT: C. BERENGER / MICROTEC
//
// ROL: Gestion des graphiques
//
// HST: Version I00A00A du 09/08/2010 / C. BERENGER MICROTEC / Cr�ation
//******************************************************************************
//
//*************************************************************************** 
// FIN TABLE
#ifndef LIB_GST_GRAPHE
 #define LIB_GST_GRAPHE

//***************************************************************************
// inclusions
//***************************************************************************

// Librairies standards

// Librairie FOURNISSEUR

// Librairie MICROTEC

// Librairie sp�cifiques � l'application

//***************************************************************************
// D�finition de constantes
//***************************************************************************


//***************************************************************************
// D�finition de types et structures
//***************************************************************************

//******************************************************************************
// Fonctions externes au source
//******************************************************************************

//***************************************************************************
//  - int iPanel			: Handle du panel
//	  int iControlDataGrid	: Handle du contr�le de la grille de donn�es
//	  int iControlGraphe	: Num�ro de contr�le du graphe
//	  BOOL bDelete			: 1=Effacement du graphique, sinon 0
//	  double *ptdTabX		: Tableau des abscisses
//	  double *ptdTabY		: Tableau des ordonn�es
//	  int iNbElts			: Nombre d'�l�ments du tableau de donn�es
//	  int iNumCycle			: Num�ro de cycle en cours
//	  int iColor			: Couleur de la courbe � tracer
//	  int iNbPixels			: Epaisseur du trait sur le graphique
//
//  - Trac� d'une courbe dans un graphiques
//
//  - 1 si probl�me d�tect�, 0 sinon
//***************************************************************************
void GstGrapheMajGrapheVit(	int iPanel, int iControlDataGrid, int iControlGraphe, 
							BOOL bDelete, double *ptdTabX, double *ptdTabY, 
							int iNbElts, int iNumCycle, int iColor, int iNbPixels);

void GstGrapheMajGraphePres(	int iPanel, int iControlDataGrid, int iControlGraphe, 
							BOOL bDelete, double *ptdTabX, double *ptdTabY, 
							int iNbElts, int iNumCycle, int iColor, int iNbPixels);


//***************************************************************************
//  - int iPanel			: Handle du panel
//	  int iControlDataGrid	: Handle de la tabme de donn�es
//    int iControlGraphe	: Handle du graphique
//	  int iColor			: Couleur de la courbe
//
//  - Trac� des courbes des relectures dans les graphiques
//
//  - 1 si probl�me d�tect�, 0 sinon
//***************************************************************************
// FIN ALGO
void GstGrapheMajRelecture(int iPanel, int iControlDataGrid, int iControlGraphe, int iColor);


//******************************************************************************
#endif
