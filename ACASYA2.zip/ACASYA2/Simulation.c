#include "IhmAccueil.h"

// DEBUT TABLE
//******************************************************************************
// PRO: BANC DE TEST LSE
// PRG: Simulation.C
// VER: Version I00A00A du 09/08/2010
// AUT: C. BERENGER / MICROTEC
//					 
// ROL: Gestion de l'�cran de simulation
//
// HST: Version I00A00A du 09/08/2010 / C. BERENGER MICROTEC / Cr�ation
//******************************************************************************
//
//******************************************************************************
// FIN TABLE

//******************************************************************************
// Inclusions
//******************************************************************************

// Librairies standards 
#include <utility.h>
#include <ansi_c.h>
#include <userint.h>
#include <cvirte.h>

// Librairies FOURNISSEUR

// Librairies MICROTEC


// Librairies sp�cifiques � l'application
#include "IhmSimul.h"
#include "Simulation.h"



//******************************************************************************
// D�finition de constantes
//******************************************************************************
#define sNOM_IHM_SIMUL	"IhmSimul.uir"



//******************************************************************************
// D�finition de types et structures
//******************************************************************************

//******************************************************************************
// Variables globales
//******************************************************************************
static int GiPanel=0;

//******************************************************************************
// Fonctions internes au source
//******************************************************************************

//******************************************************************************
// Corps des fonctions et proc�dures internes au source
//******************************************************************************



// DEBUT ALGO
//***************************************************************************
// void LoadPanelSimul(void)
//***************************************************************************
//  - Aucun
//
//  - Fonction de chargement et affichage de l'�cran de simulation
//
//  - Aucun 
//***************************************************************************
// FIN ALGO
void LoadPanelSimul(void)
{
	GiPanel = LoadPanel (0, sNOM_IHM_SIMUL, PANEL_SIMU);
		
	DisplayPanel(GiPanel);	
}

// DEBUT ALGO
//***************************************************************************
// void DiscardPanelSimul(void)
//***************************************************************************
//  - Aucun
//
//  - D�chargement de l'�cran de simulation
//
//  - Aucun 
//***************************************************************************
// FIN ALGO
void DiscardPanelSimul(void)
{
	DiscardPanel(GiPanel);
}

// DEBUT ALGO
//***************************************************************************
// int GetSimuHandle(void)
//***************************************************************************
//  - Aucun
//
//  - Renvoie le num�ro de handle vers l'�cran de simulation
//
//  - Num�ro de handle de l'�cran de simulation 
//***************************************************************************
// FIN ALGO
int GetSimuHandle(void)
{
	return GiPanel;
}


