// DEBUT TABLE
//******************************************************************************
// PRO: BANC DE TEST LSE
// PRG: GstGraphe.c
// VER: Version I00A00A du 09/08/2010
// AUT: C. BERENGER / MICROTEC
//
// ROL: Programme de gestion des graphiques
//
// HST: Version I00A00A du 14/09/2010 / MP. LACROIX MICROTEC / Cr�ation
// HST: Version I00A00B du 15/11/2010 / C.BERENGER / 
//		- Passage de la r�solution moteur � 0.1 tours/min
//		- Modification de l'affichage du graphique en mode manuel
//		- Correction du probl�me de gestion des limites apr�s le chargement
//	      d'un cycle dans une autre unit� de vitesse ou de pression que celle 
//	      utilis�e par d�faut.
// HST: Version I00A00C du 30/11/2010 / C. BERENGER MICROTEC / 
//	    - Ajout d'une gestion par watchdog pour couper le moteur et la pression 
//	      en cas de probl�me de blocage de l'application.
// HST: Version I00A00D du 04/01/2011 / C. BERENGER MICROTEC / 
//	    - Ajout de quelques Mutex
//		- Suppresison de l'utilisation du fichier "MessageIhm.ini", et remplacement par des constantes
//		- Recompilation du programme avec la version 8.6.0f5 du DAQmx (identique � la version install�e sur le banc du client)
//		- Passage de la variable "GptstConfig" en mode prot�g� dans le fichier "Modes.c"
//******************************************************************************
//
//******************************************************************************
// FIN TABLE

//******************************************************************************
// Inclusions
//******************************************************************************

// Librairies standards 
#include <utility.h>
#include <ansi_c.h>
#include <userint.h>
#include <cvirte.h>

// Librairies FOURNISSEUR

// Librairies MICROTEC
#include "ZoneMessage.h"
#include "MessageIhm.h"

// Librairies sp�cifiques � l'application
#include "IhmModes.h"
#include "GstFiles.h"
#include "Modes.h"



//******************************************************************************
// D�finition de constantes
//******************************************************************************
//----- Options -------
//---------------------


//******************************************************************************
// D�finition de types et structures
//******************************************************************************



//******************************************************************************
// Variables globales
//******************************************************************************



//******************************************************************************
// Fonctions internes au source
//******************************************************************************



//******************************************************************************
// Corps des fonctions et proc�dures internes au source
//******************************************************************************
#define CHECK_TAB_INDEX(sId, iIndex, iNdexMin, iIndexMax) 	\
{														\
	if ((iIndex < iNdexMin) || (iIndex > iIndexMax))	\
		MessagePopup(sId, "Index Error");		\
}

// DEBUT ALGO
//***************************************************************************
//void GstGrapheMajGraphe(	int iPanel, int iControlDataGrid, int iControlGraphe, 
//							BOOL bDelete, double *ptdTabX, double *ptdTabY, 
//							int iNbElts, int iColor, int iNbPixels)
//***************************************************************************
//  - int iPanel			: Handle du panel
//	  int iControlDataGrid	: Handle du contr�le de la grille de donn�es
//	  int iControlGraphe	: Num�ro de contr�le du graphe
//	  BOOL bDelete			: 1=Effacement du graphique, sinon 0
//	  double *ptdTabX		: Tableau des abscisses
//	  double *ptdTabY		: Tableau des ordonn�es
//	  int iNbElts			: Nombre d'�l�ments du tableau de donn�es
//	  int iNumCycle			: Num�ro de cycle en cours
//	  int iColor			: Couleur de la courbe � tracer
//	  int iNbPixels			: Epaisseur du trait sur le graphique
//
//  - Trac� d'une courbe dans un graphiques
//
//  - 1 si probl�me d�tect�, 0 sinon
//***************************************************************************
// FIN ALGO
void GstGrapheMajGrapheVit(	int iPanel, int iControlDataGrid, int iControlGraphe, 
							BOOL bDelete, double *ptdTabX, double *ptdTabY, 
							int iNbElts, int iNumCycle, int iColor, int iNbPixels)
{
double dTabDuree[iTAILLE_MAX_TAB+1]={0};
double dTabY[iTAILLE_MAX_TAB+1]={0};
int iPlotHandle;
int i;

	if (bDelete)
		// Reset du graphique si demand�
		DeleteGraphPlot (iPanel, iControlGraphe, -1, VAL_IMMEDIATE_DRAW);

	dTabDuree[0] = ptdTabX[0];
	
	memcpy(&dTabY[1], ptdTabY, sizeof(double) * (iTAILLE_MAX_TAB-1));
	dTabY[0] = ptdTabY[0];
	
	// Ajout des dur�es
	for(i=0; i< iNbElts + 1; i++){
		if (i == 0){
			dTabDuree[0] = 0.0;
		}
		else{
				dTabDuree[i] = dTabDuree[i-1] + ptdTabX[i-1];
			}
	}

	if(iNbElts > 1){
		// Cas du premier cycle
		iPlotHandle = PlotLine (iPanel, iControlGraphe, 0.0, 0.0, dTabDuree[1], dTabY[1], iColor);
		SetPlotAttribute (iPanel, iControlGraphe, iPlotHandle, ATTR_PLOT_THICKNESS, 1);
		if(iNumCycle == 1)
			SetPlotAttribute (iPanel, iControlGraphe, iPlotHandle, ATTR_LINE_STYLE, VAL_SOLID);
		else
			SetPlotAttribute (iPanel, iControlGraphe, iPlotHandle, ATTR_LINE_STYLE, VAL_DASH);
	
		// Cas des autres cycles
		iPlotHandle = PlotLine (iPanel, iControlGraphe, 0.0, dTabY[iNbElts], dTabDuree[1], dTabY[1], iColor);
		SetPlotAttribute (iPanel, iControlGraphe, iPlotHandle, ATTR_PLOT_THICKNESS, 1);
		if(iNumCycle > 1)
			SetPlotAttribute (iPanel, iControlGraphe, iPlotHandle, ATTR_LINE_STYLE, VAL_SOLID);
		else
			SetPlotAttribute (iPanel, iControlGraphe, iPlotHandle, ATTR_LINE_STYLE, VAL_DASH);

	
		// Affichage du segment de droite sur le graphique
		iPlotHandle = PlotXY (iPanel, iControlGraphe, &dTabDuree[1], &dTabY[1], iNbElts, VAL_DOUBLE, VAL_DOUBLE, VAL_CONNECTED_POINTS, VAL_X,
							  VAL_SOLID, 1, iColor);
		SetPlotAttribute (iPanel, iControlGraphe, iPlotHandle, ATTR_PLOT_THICKNESS, iNbPixels);
	}
}

// DEBUT ALGO
//***************************************************************************
//void GstGrapheMajGraphe(	int iPanel, int iControlDataGrid, int iControlGraphe, 
//							BOOL bDelete, double *ptdTabX, double *ptdTabY, 
//							int iNbElts, int iColor, int iNbPixels)
//***************************************************************************
//  - int iPanel			: Handle du panel
//	  int iControlDataGrid	: Handle du contr�le de la grille de donn�es
//	  int iControlGraphe	: Num�ro de contr�le du graphe
//	  BOOL bDelete			: 1=Effacement du graphique, sinon 0
//	  double *ptdTabX		: Tableau des abscisses
//	  double *ptdTabY		: Tableau des ordonn�es
//	  int iNbElts			: Nombre d'�l�ments du tableau de donn�es
//	  int iNumCycle			: Num�ro de cycle en cours
//	  int iColor			: Couleur de la courbe � tracer
//	  int iNbPixels			: Epaisseur du trait sur le graphique
//
//  - Trac� d'une courbe dans un graphiques
//
//  - 1 si probl�me d�tect�, 0 sinon
//***************************************************************************
// FIN ALGO
void GstGrapheMajGraphePres(int iPanel, int iControlDataGrid, int iControlGraphe, 
							BOOL bDelete, double *ptdTabX, double *ptdTabY, 
							int iNbElts, int iNumCycle, int iColor, int iNbPixels)
{
double dTabDuree[iTAILLE_MAX_TAB+1];
double dTabY[iTAILLE_MAX_TAB+1];
int iPlotHandle;
int i;

	if (bDelete)
		// Reset du graphique si demand�
		DeleteGraphPlot (iPanel, iControlGraphe, -1, VAL_IMMEDIATE_DRAW);
		
	dTabDuree[0] = ptdTabX[0];
	
	memcpy(&dTabY[1], ptdTabY, sizeof(double) * (iTAILLE_MAX_TAB-1));
	dTabY[0] = ptdTabY[0];
	
	// Ajout des dur�es
	for(i=0; i< iNbElts + 1; i++){
		if (i == 0){
			dTabDuree[0] = 0.0;
		}
		else{
				dTabDuree[i] = dTabDuree[i-1] + ptdTabX[i-1];
			}
	}

	if(iNbElts > 1){
		// Cas du premier cycle
		iPlotHandle = PlotLine (iPanel, iControlGraphe, 0.0, 0.0, dTabDuree[1], dTabY[1], iColor);
		SetPlotAttribute (iPanel, iControlGraphe, iPlotHandle, ATTR_PLOT_THICKNESS, 1);
		if(iNumCycle == 1)
			SetPlotAttribute (iPanel, iControlGraphe, iPlotHandle, ATTR_LINE_STYLE, VAL_SOLID);
		else
			SetPlotAttribute (iPanel, iControlGraphe, iPlotHandle, ATTR_LINE_STYLE, VAL_DASH);
	
		// Cas des autres cycles
		iPlotHandle = PlotLine (iPanel, iControlGraphe, 0.0, iNbElts, dTabDuree[1], dTabY[1], iColor);
		SetPlotAttribute (iPanel, iControlGraphe, iPlotHandle, ATTR_PLOT_THICKNESS, 1);
		if(iNumCycle > 1)
			SetPlotAttribute (iPanel, iControlGraphe, iPlotHandle, ATTR_LINE_STYLE, VAL_SOLID);
		else
			SetPlotAttribute (iPanel, iControlGraphe, iPlotHandle, ATTR_LINE_STYLE, VAL_DASH);

	
		// Affichage du segment de droite sur le graphique
		iPlotHandle = PlotXY (iPanel, iControlGraphe, &dTabDuree[1], &dTabY[1], iNbElts, VAL_DOUBLE, VAL_DOUBLE, VAL_CONNECTED_POINTS, VAL_X,
							  VAL_SOLID, 1, iColor);
		SetPlotAttribute (iPanel, iControlGraphe, iPlotHandle, ATTR_PLOT_THICKNESS, iNbPixels);
	}
}


