// DEBUT TABLE
//******************************************************************************
// PRO: WATCHDOG POUR LE BANC DE TEST LSE
// PRG: Main.C
// VER: Version I00A00C du 03/12/2010
// AUT: C. BERENGER / MICROTEC
//					 
// ROL: Programme principal du watchdog pour le banc LSE
//
// HST: Version I00A00A du 03/12/2010 / C. BERENGER MICROTEC / Cr�ation
//******************************************************************************
//
//******************************************************************************
// FIN TABLE

//******************************************************************************
// Inclusions
//******************************************************************************

// Librairies standards 
#include <windows.h>
#include <tlhelp32.h>
#include <stdio.h>
#include <stdlib.h>
#include <ansi_c.h>
#include <utility.h>
#include <userint.h>
#include <cvirte.h>

// Librairies FOURNISSEUR

// Librairies MICROTEC

// Librairies sp�cifiques � l'application

//******************************************************************************
// D�finition de constantes
//******************************************************************************
#define sAPP_NAME	"BancLSE.exe"

//******************************************************************************
// D�finition de types et structures
//******************************************************************************

//******************************************************************************
// Variables globales
//******************************************************************************
DefineThreadSafeScalarVar(int, 	GbQuitter, 	0);
DefineThreadSafeScalarVar(int, 	GbRunLse, 	0);

int GiThreadPoolHandleWatchdog;
int GiThreadFctIdWatchdog;

//******************************************************************************
// Fonctions internes au source
//******************************************************************************

//******************************************************************************
// Corps des fonctions et proc�dures internes au source
//******************************************************************************



// DEBUT ALGO
//****************************************************************************** 
// int CVICALLBACK Quitter (int panel, int control, int event,
//		void *callbackData, int eventData1, int eventData2)
//****************************************************************************** 
//	- Param�tres CVI
//
//  - Arr�t de l'application
//
//  - Code d'erreur (0 si OK)
//****************************************************************************** 
// FIN ALGO
int CVICALLBACK Quitter (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
int iStatus;

	switch (event){
		case EVENT_COMMIT:
			SetGbQuitter(1);
			
			#ifdef bDISPLAY_PANEL
			QuitUserInterface(0);
			#endif
		break;
	}
	return 0;
}


// DEBUT ALGO
//****************************************************************************** 
// static int CVICALLBACK ThreadWatchdog (void *functionData)
//****************************************************************************** 
//	- Param�tres CVI
//
//  - Thread de gestion du watchdog
//
//  - Code d'erreur (0 si OK)
//****************************************************************************** 
// FIN ALGO
static int CVICALLBACK ThreadWatchdog (void *functionData)
{
#define dDELAY_ATT_BEF_KILL_APP 	7.0
char sFileName[MAX_FILENAME_LEN];
char sLastFileName[MAX_FILENAME_LEN];
int iTimeDep	= 0;
int iCurrentTime= 0;
double dDureeEcoul = 0.0;

	strcpy(sFileName, 		"");
	strcpy(sLastFileName, 	"");

	iTimeDep = clock();

	do{
		// Calcul de la dur�e �coul�e
		dDureeEcoul = (double)((clock() - iTimeDep)) / ((double)CLOCKS_PER_SEC);

		// Lecture du nom de fichier
		GetFirstFile ("watch_*.txt", 1, 0, 0, 0, 0, 0, sFileName);
	
		// On doit quitter l'application
		if (strcmp(sFileName, "watch_quitter.txt") == 0){
			SetGbQuitter(1); 
			SetGbRunLse(0);
		}
		
		if ((dDureeEcoul > dDELAY_ATT_BEF_KILL_APP) && (!GetGbQuitter())){
			iTimeDep = clock();
			if (strcmp(sFileName, "watch_standby.txt") != 0){
				// Si les deux fichiers sont diff�rents
				if (strcmp(sFileName, sLastFileName) != 0)
					strcpy(sLastFileName, sFileName);
				else{
						// On tue l'application
						system("taskkill /IM "sAPP_NAME);
						Delay(1.0);
						SetGbQuitter(1); 
						SetGbRunLse(1);
					 }
			}
		}
		
		if(!GetGbQuitter())
			Delay(2.0);

	}while (!GetGbQuitter());
	
	return 0;
}
  
// DEBUT ALGO
//****************************************************************************** 
// void CreateThreadWatchdog(void)
//****************************************************************************** 
//	- Aucun
//
//  - Cr�ation du thread de gestion du watchdog
//
//  - Aucun
//****************************************************************************** 
// FIN ALGO
void CreateThreadWatchdog(void)
{
int iStatus;

	// Initialisation du thread
	iStatus = CmtNewThreadPool (1, &GiThreadPoolHandleWatchdog);
	iStatus = CmtScheduleThreadPoolFunction (GiThreadPoolHandleWatchdog, ThreadWatchdog, NULL, &GiThreadFctIdWatchdog);	
}

// DEBUT ALGO
//****************************************************************************** 
//int __stdcall WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
//					   LPSTR lpszCmdLine, int nCmdShow)
//****************************************************************************** 
//	- param�tres CVI 
//
//  - Programme principal
//
//  - 0 si Ok
//	  -1 sinon
//****************************************************************************** 
// FIN ALGO
int __stdcall WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
					   LPSTR lpszCmdLine, int nCmdShow)
{
int dwStatus;

	// Interdiction de relancer l'application si une instance existe
	CheckForDuplicateAppInstance (ACTIVATE_OTHER_INSTANCE, &dwStatus);
	if (dwStatus)
		return 0;	

	if (InitCVIRTE (hInstance, 0, 0) == 0)
		return -1;    /* out of memory */
	
	//--------------------
	InitializeGbQuitter();
	InitializeGbRunLse();
	SetGbQuitter(0);
	SetGbRunLse(0);
	
	// Cr�ation des threads
	CreateThreadWatchdog();

	do{
		Delay(1.0);
	}while (!GetGbQuitter());	

	// Attente de fin du thread
	CmtWaitForThreadPoolFunctionCompletion (GiThreadPoolHandleWatchdog, GiThreadFctIdWatchdog, OPT_TP_PROCESS_EVENTS_WHILE_WAITING);
	CmtReleaseThreadPoolFunctionID (GiThreadPoolHandleWatchdog, GiThreadFctIdWatchdog);
	CmtDiscardThreadPool (GiThreadPoolHandleWatchdog);
	
	if(GetGbRunLse())
		// Lancement du programme LSE si n�cessaire
		LaunchExecutable (sAPP_NAME); 
	
	//--------------------
	UninitializeGbQuitter();
	UninitializeGbRunLse();
	
	return 0;
}

