// DEBUT TABLE
//***************************************************************************
// PRO: Tous les programmes 
// PRG: ZoneMessage.H
// VER: Version 01 du 20/10/2004
//
// ROL: Gestion de la zone de message des Ihm
//
// INT: cvirte,userint,ansi_c (librairies NI)
//
//*************************************************************************** 
//*************************************************************************** 
// FIN TABLE
#ifndef LIB_ZoneMessage
#define LIB_ZoneMessage

#define DLLEXPORT __declspec(dllexport)
#ifdef __cplusplus
	extern "C"{
#endif

//***************************************************************************
// inclusions
//***************************************************************************

// Librairies standards 

// Librairie FOURNISSEUR

// Librairie MICROTEC

// Librairie sp�cifiques � l'application 

//***************************************************************************
// D�finition de constantes
//***************************************************************************

// Options de compilation

//***************************************************************************
// D�finition de types et structures
//***************************************************************************

// Messages d'erreurs

//***************************************************************************
// Variables globales
//***************************************************************************

//***************************************************************************
// Corps des fonctions et proc�dures internes au source
//***************************************************************************

//  - Version au format SIEMENS
void DLLEXPORT ZoneMessageVersion (double *dVersion);

//  - Version au format MICROTEC
void DLLEXPORT ZoneMessageVersionMicrotec (char *sVersion);

//	- Chargement de la librairie de gestion de la zone de message 
void DLLEXPORT ZoneMessageLoad(char *sPath);

//	- Donne le choix � l'utilisateur d'effacer, de sauver, ... la ZM
void DLLEXPORT ZoneMessageTraite (int iPanel, int iControl,char *sNomTrace) ;

//	- Si la zone de message est satur�e, sauvegarde automatique dans un 
//    fichier trace.
void DLLEXPORT ZoneMessageSaturee(int iPanel,
								int iControl, 
								char *sNomTrace, 
								int bForceTrace);

#ifdef __cplusplus
	}
#endif

#endif
