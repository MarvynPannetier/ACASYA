// DEBUT TABLE
//******************************************************************************
// PRO: BANC DE TEST LSE
// PRG: Usb6008.h
// VER: Version I00A00A du 17/09/2010
// AUT: MP. LACROIX / MICROTEC
//
// ROL: Gestion du module USB-6008
//
// HST: Version I00A00A du 17/09/2010 / MP. LACROIX MICROTEC / Cr�ation
//******************************************************************************
//
//******************************************************************************
// FIN TABLE

//******************************************************************************
// Inclusions
//******************************************************************************

// Librairies standards 

// Librairies FOURNISSEUR

// Librairies MICROTEC

// Librairies sp�cifiques � l'application

#ifndef LIB_USB_6008
	#define LIB_USB_6008

//******************************************************************************
// D�finition de constantes
//******************************************************************************

// Option de compilation pour simulation de la communication
//#define bSIMUL_USB_6008
//-------------------------

// Etat des entr�es
#define iUSB6008_ETAT_PORTE_1_OUVERTE					0
#define iUSB6008_ETAT_PORTE_2_OUVERTE					0
#define iUSB6008_ETAT_CAPOT_SECURITE_OUVERT				0
#define iUSB6008_ETAT_BOUCLE_SECURITE_OUVERTE			0
#define iUSB6008_ETAT_MOTEUR_ARRETE						0
#define iUSB6008_ETAT_ARRET_URGENCE_ACTIF				0
#define iUSB6008_ETAT_VIBRATIONS_DETECT_ACTIF			0

// Commande des sorties
#define iUSB6008_CMDE_VENTILATION_MOTEUR_ACTIFS			1
#define iUSB6008_CMDE_VENTILATION_MOTEUR_INACTIFS		0
#define iUSB6008_CMDE_OUVERTURE_GACHE_ACTIVE			1
#define iUSB6008_CMDE_OUVERTURE_GACHE_INACTIVE			0

//******************************************************************************
// D�finition de types et structures
//******************************************************************************

//******************************************************************************
// Variables globales
//******************************************************************************

//******************************************************************************
// Fonctions export�es
//******************************************************************************

//  - Initialisation du module
int Usb6008Init (void);

//  - Arr�t du module
void Usb6008Close (void);

//******************************************************************************
//	- int *iEtatPorte1Ouverte			: valeur de l'info "Porte 1 ouverte"
//	  int *iEtatPorte2Ouverte			: valeur de l'info "Porte 2 ouverte" 
//	  int *iEtatCapotSecuriteOuvert		: valeur de l'info "Capot s�curit� ouvert" 
//	  int *iEtatBoucleSecuriteOuverte	: valeur de l'info "Boucle s�curit� ouverte" 
//	  int *iEtatMoteurArrete			: valeur de l'info "Moteur arr�t�" 
//	  int *iEtatArretUrgenceActif		: valeur de l'info "Arr�t urgence actif"
//	  int *iEtatCaptVibrationsActif		: valeur de l'info "Capteur vibrations" 
//
//  - Acquisition �tat des entr�es logiques
//
//  - 0 si Ok
//	  erreur si <0
//	  warning si >0
//******************************************************************************
int Usb6008AcquisitionEtats 
	(int *iEtatPorte1Ouverte, int *iEtatPorte2Ouverte, int *iEtatCapotSecuriteOuvert, 
	int *iEtatBoucleSecuriteOuverte, int *iEtatMoteurArrete, int *iEtatArretUrgenceActif, 
	int *iEtatCaptVibrationsActif);
		
//  - Commande de la ventilation et du moteur
int Usb6008CommandeVentilationMoteur (int iCommande);

//  - Commande de l'ouverture de la g�che
int Usb6008CommandeOuvertureGache (int iCommande);

//  - Mesure de la pression
int Usb6008MesurePression (double *dPression);

//  - Commande de la pression
int Usb6008CommandePression (double dPression);

#endif

//******************************************************************************
