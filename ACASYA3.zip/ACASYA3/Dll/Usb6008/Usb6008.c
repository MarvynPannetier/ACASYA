// DEBUT TABLE
//******************************************************************************
// PRO: BANC DE TEST LSE
// PRG: Usb6008.c
// VER: Version I00A00A du 17/09/2010
// AUT: MP. LACROIX / MICROTEC
//
// ROL: Gestion du module USB-6008
//
// HST: Version I00A00A du 14/09/2010 / MP. LACROIX MICROTEC / Cr�ation
// HST: Version I00A00B du 15/11/2010 / C.BERENGER / 
//		- Passage de la r�solution moteur � 0.1 tours/min
//		- Modification de l'affichage du graphique en mode manuel
//		- Correction du probl�me de gestion des limites apr�s le chargement
//	      d'un cycle dans une autre unit� de vitesse ou de pression que celle 
//	      utilis�e par d�faut.
// HST: Version I00A00C du 30/11/2010 / C. BERENGER MICROTEC / 
//	    - Ajout d'une gestion par watchdog pour couper le moteur et la pression 
//	      en cas de probl�me de blocage de l'application.
// HST: Version I00A00D du 04/01/2011 / C. BERENGER MICROTEC / 
//	    - Ajout de quelques Mutex
//		- Suppresison de l'utilisation du fichier "MessageIhm.ini", et remplacement par des constantes
//		- Recompilation du programme avec la version 8.6.0f5 du DAQmx (identique � la version install�e sur le banc du client)
//		- Passage de la variable "GptstConfig" en mode prot�g� dans le fichier "Modes.c"
// HST: Version I00A00K du 17/10/2011 / C. BERENGER MICROTEC / 
//		Modification  du calcul de la lecture de pression (moyenne)
// HST: Version I00A00M (01/02/2012):
//		- Modifications dans la fonction "Usb6008CommandePression" pour limiter les 
//		  pressions n�gatives � z�ro.
//		  La prise en compte d'offsets de pression n�gatives dans le fichier "Config.ini" est 
//		  maintenant possible.	
//******************************************************************************
//
//******************************************************************************
// FIN TABLE

//******************************************************************************
// Inclusions
//******************************************************************************

// Librairies standards 
#include <analysis.h>
#include <userint.h>
#include <ansi_c.h>
#include <formatio.h>
#include "NIDAQmx.h"

// Librairies FOURNISSEUR

// Librairies MICROTEC

// Librairies sp�cifiques � l'application
#include "Usb6008.h"
#include "IhmSimul.h"
#include "Simulation.h"
#include "Mutex.h"

//******************************************************************************
// D�finition de constantes
//******************************************************************************

// Nom du module
#define sNOM_MODULE 							"Dev1/"

// Voies logiques
#define sNOM_PORT_ETATS							"port0"
#define sNOM_VOIE_CMDE_VENTILATION_MOTEUR		"port1/line0"
#define sNOM_VOIE_CMDE_OUVERTURE_GACHE			"port1/line1"

// Voies analogiques
#define sNOM_VOIE_MESURE_PRESSION				"ai0"
#define sNOM_VOIE_COMMANDE_PRESSION				"ao0"

// Acquisition des �tats
#define iBIT_ETAT_PORTE_1_OUVERTE				0
#define iBIT_ETAT_PORTE_2_OUVERTE				1
#define iBIT_ETAT_CAPOT_SECURITE_OUVERT			2
#define iBIT_ETAT_BOUCLE_SECURITE_OUVERTE		3
#define iBIT_ETAT_MOTEUR_ARRETE					4
#define iBIT_ETAT_ARRET_URGENCE_ACTIF			5
#define iBIT_ETAT_CAPT_VIBRATIONS				6

// Commande des sorties
#define iBIT_CMDE_VENTILATION_MOTEUR			0
#define iBIT_CMDE_OUVERTURE_GACHE				1

// Dur�e des time-out
#define fTIME_OUT_READ_DAQ						1.0	// seconde
#define fTIME_OUT_WRITE_DAQ						1.0	// seconde 

#define iNB_MAX_MEAS_MOY						5

#define GlTIMEOUT_MUTEX_MS						20000
//******************************************************************************
// D�finition de types et structures
//******************************************************************************

//******************************************************************************
// Variables globales
//******************************************************************************

//static int GiPanel=0;
static double GtdTabVal[iNB_MAX_MEAS_MOY];
static int iIndexLastMeas = 0;
static HANDLE GhMutex;

#ifndef bSIMUL_USB_6008
// T�ches logiques
static TaskHandle GhTacheAcquisitionEtats; 
static TaskHandle GhTacheCmdeVentilationMoteur; 
static TaskHandle GhTacheCmdeOuvertureGache; 

// T�ches analogiques
static TaskHandle GhTacheMesurePression; 
static TaskHandle GhTacheCommandePression; 
#endif

//******************************************************************************
// Fonctions internes au source
//******************************************************************************

// DEBUT ALGO
//****************************************************************************** 
// int Usb6008Init (void)
//******************************************************************************
//	- aucun
//
//  - Initialisation du module
//
//  - 0 si Ok
//	  erreur si <0
//	  warning si >0
//******************************************************************************
// FIN ALGO
int Usb6008Init (void)
{
	//int i;
	//int iErr;
	int iStatus;
	char sNomVoie [50];
	
   iStatus = CreationJeton (&GhMutex, "USB6008");
   
	#ifdef bSIMUL_USB_6008
		return 0;
	#else
		// Initialisation des t�ches logiques  
		if ((iStatus = DAQmxCreateTask ("", &GhTacheAcquisitionEtats)) != 0)
			return iStatus;

		sprintf (sNomVoie, "%s%s", sNOM_MODULE, sNOM_PORT_ETATS); 
		if ((iStatus = DAQmxCreateDIChan (GhTacheAcquisitionEtats, sNomVoie, "", DAQmx_Val_ChanForAllLines)) != 0)
			return iStatus;

		if ((iStatus = DAQmxStartTask (GhTacheAcquisitionEtats)) != 0)
			return iStatus;


		if ((iStatus = DAQmxCreateTask ("", &GhTacheCmdeVentilationMoteur)) != 0)
			return iStatus;

		sprintf (sNomVoie, "%s%s", sNOM_MODULE, sNOM_VOIE_CMDE_VENTILATION_MOTEUR); 
		if ((iStatus = DAQmxCreateDOChan (GhTacheCmdeVentilationMoteur, sNomVoie, "", DAQmx_Val_ChanForAllLines)) != 0)
			return iStatus;

		if ((iStatus = DAQmxStartTask (GhTacheCmdeVentilationMoteur)) != 0)
			return iStatus;

		
		if ((iStatus = DAQmxCreateTask ("", &GhTacheCmdeOuvertureGache)) != 0)
			return iStatus;

		sprintf (sNomVoie, "%s%s", sNOM_MODULE, sNOM_VOIE_CMDE_OUVERTURE_GACHE); 
		if ((iStatus = DAQmxCreateDOChan (GhTacheCmdeOuvertureGache, sNomVoie, "", DAQmx_Val_ChanForAllLines)) != 0)
			return iStatus;

		if ((iStatus = DAQmxStartTask (GhTacheCmdeOuvertureGache)) != 0)
			return iStatus;


		// Initialisation des t�ches analogiques  
		if ((iStatus = DAQmxCreateTask ("", &GhTacheMesurePression)) != 0)
			return iStatus;
		sprintf (sNomVoie, "%s%s", sNOM_MODULE, sNOM_VOIE_MESURE_PRESSION); 
		if ((iStatus = DAQmxCreateAIVoltageChan 
				(GhTacheMesurePression, sNomVoie, "", DAQmx_Val_RSE, 0, 10, DAQmx_Val_Volts, "")) != 0)
			return iStatus;
		
		// Configuration de ka fr�quence d'�chantillonnage de la pression					
		//if ((iStatus = DAQmxCfgSampClkTiming (GhTacheMesurePression, "", 10000, DAQmx_Val_Rising, DAQmx_Val_ContSamps, 200)) != 0)
		//	return iStatus; 
			
		if ((iStatus = DAQmxStartTask (GhTacheMesurePression)) != 0)
			return iStatus;
	
		if ((iStatus = DAQmxCreateTask ("", &GhTacheCommandePression)) != 0)
			return iStatus;
		sprintf (sNomVoie, "%s%s", sNOM_MODULE, sNOM_VOIE_COMMANDE_PRESSION); 
		if ((iStatus = DAQmxCreateAOVoltageChan 
				(GhTacheCommandePression, sNomVoie, "", 0, 5.0, DAQmx_Val_Volts, "")) != 0)
			return iStatus;

		if ((iStatus = DAQmxStartTask (GhTacheCommandePression)) != 0)
			return iStatus;
	#endif

	return 0;
}	

// DEBUT ALGO
//****************************************************************************** 
// void Usb6008Close (void)
//******************************************************************************
//	- aucun
//
//  - Arr�t du module
//
//  - aucun
//******************************************************************************
// FIN ALGO
void Usb6008Close (void)
{
	#ifdef bSIMUL_USB_6008
		return;
	#else
	
	// Arr�t des t�ches logiques 
	DAQmxStopTask (GhTacheAcquisitionEtats);
	DAQmxClearTask (GhTacheAcquisitionEtats);
	
	DAQmxStopTask (GhTacheCmdeVentilationMoteur);
	DAQmxClearTask (GhTacheCmdeVentilationMoteur);
	
	DAQmxStopTask (GhTacheCmdeOuvertureGache);
	DAQmxClearTask (GhTacheCmdeOuvertureGache);
	

	// Arr�t des t�ches analogiques
	DAQmxStopTask (GhTacheMesurePression);
	DAQmxClearTask (GhTacheMesurePression);
	
	DAQmxStopTask (GhTacheCommandePression);
	DAQmxClearTask (GhTacheCommandePression);
	#endif 
	
	DestructionJeton (GhMutex);
}

// DEBUT ALGO
//****************************************************************************** 
// int Usb6008AcquisitionEtats (...)
//******************************************************************************
//	- int *iEtatPorte1Ouverte			: valeur de l'info "Porte 1 ouverte"
//	  int *iEtatPorte2Ouverte			: valeur de l'info "Porte 2 ouverte" 
//	  int *iEtatCapotSecuriteOuvert		: valeur de l'info "Capot s�curit� ouvert" 
//	  int *iEtatBoucleSecuriteOuverte	: valeur de l'info "Boucle s�curit� ouverte" 
//	  int *iEtatMoteurArrete			: valeur de l'info "Moteur arr�t�" 
//	  int *iEtatArretUrgenceActif		: valeur de l'info "Arr�t urgence actif"
//	  int *iEtatCaptVibrationsActif		: valeur de l'info "Capteur vibrations" 
//
//  - Acquisition �tat des entr�es logiques
//
//  - 0 si Ok
//	  erreur si <0
//	  warning si >0
//******************************************************************************
// FIN ALGO
int Usb6008AcquisitionEtats 
	(int *iEtatPorte1Ouverte, int *iEtatPorte2Ouverte, int *iEtatCapotSecuriteOuvert, 
	int *iEtatBoucleSecuriteOuverte, int *iEtatMoteurArrete, int *iEtatArretUrgenceActif, 
	int *iEtatCaptVibrationsActif)
{
	#ifndef bSIMUL_USB_6008 
	uInt8 ucValeur;
	int32 iNbValeurs;
	#endif
	//double dSpeed;
	int iStatus;

	DemandeAttenteJeton(GhMutex, GlTIMEOUT_MUTEX_MS);

	#ifdef bSIMUL_USB_6008
		*iEtatPorte1Ouverte 		= 1;        		
		*iEtatPorte2Ouverte 		= 1;       		
		*iEtatCapotSecuriteOuvert 	= 1;  		
		*iEtatBoucleSecuriteOuverte = 1;		
		*iEtatArretUrgenceActif 	= 1;     		
		*iEtatMoteurArrete 			= 0;
		*iEtatCaptVibrationsActif	= 1;
		
		LiberationJeton (GhMutex);
		return 0;
	#else
	
	if ((iStatus = DAQmxReadDigitalU8 (GhTacheAcquisitionEtats, 1, fTIME_OUT_READ_DAQ, DAQmx_Val_GroupByScanNumber, &ucValeur, 1, &iNbValeurs, 0)) != 0){
		LiberationJeton (GhMutex); 	
		return iStatus;
	}
	
	*iEtatPorte1Ouverte 			= (ucValeur >> iBIT_ETAT_PORTE_1_OUVERTE) & 0x01;
	*iEtatPorte2Ouverte 			= (ucValeur >> iBIT_ETAT_PORTE_2_OUVERTE) & 0x01;   
	*iEtatCapotSecuriteOuvert 		= (ucValeur >> iBIT_ETAT_CAPOT_SECURITE_OUVERT) & 0x01;    
	*iEtatBoucleSecuriteOuverte  	= (ucValeur >> iBIT_ETAT_BOUCLE_SECURITE_OUVERTE) & 0x01;   
	*iEtatMoteurArrete 				= (ucValeur >> iBIT_ETAT_MOTEUR_ARRETE) & 0x01;   
	*iEtatArretUrgenceActif 		= (ucValeur >> iBIT_ETAT_ARRET_URGENCE_ACTIF) & 0x01;
	*iEtatCaptVibrationsActif 		= (ucValeur >> iBIT_ETAT_CAPT_VIBRATIONS) & 0x01; 
	
	if(*iEtatCaptVibrationsActif == 0)
			;
	#endif 
	
	LiberationJeton (GhMutex); 
	return 0;
}

// DEBUT ALGO
//****************************************************************************** 
// int Usb6008CommandeVentilationMoteur (int iCommande) 
//******************************************************************************
//	- int Commande	: valeur de la commande
//
//  - Commande de la ventilation et du moteur
//
//  - 0 si Ok
//	  erreur si <0
//	  warning si >0
//******************************************************************************
// FIN ALGO
int Usb6008CommandeVentilationMoteur (int iCommande)
{
	#ifndef bSIMUL_USB_6008
	uInt8 ucValeur;
	int32 iNbValeurs;
	#endif
	int iStatus;

	DemandeAttenteJeton(GhMutex, GlTIMEOUT_MUTEX_MS);	
	
	#ifdef bSIMUL_USB_6008
		LiberationJeton (GhMutex); 
		return 0;
	#else
	
	ucValeur = iCommande << iBIT_CMDE_VENTILATION_MOTEUR;
	iStatus = DAQmxWriteDigitalU8 
			(GhTacheCmdeVentilationMoteur, 1, FALSE, fTIME_OUT_WRITE_DAQ, DAQmx_Val_GroupByScanNumber, &ucValeur, &iNbValeurs, 0);
	#endif 
	
	LiberationJeton (GhMutex); 
	return iStatus;
}

// DEBUT ALGO
//****************************************************************************** 
// int Usb6008CommandeOuvertureGache (int iCommande) 
//******************************************************************************
//	- int Commande	: valeur de la commande
//
//  - Commande de l'ouverture de la g�che 
//
//  - 0 si Ok
//	  erreur si <0
//	  warning si >0
//******************************************************************************
// FIN ALGO
int Usb6008CommandeOuvertureGache (int iCommande)
{
	#ifndef bSIMUL_USB_6008 
	uInt8 ucValeur;
	int32 iNbValeurs;
	#endif
	int iStatus;
	
	DemandeAttenteJeton(GhMutex, GlTIMEOUT_MUTEX_MS);
	
	#ifdef bSIMUL_USB_6008
		LiberationJeton (GhMutex); 
		return 0;
	#else
	ucValeur = iCommande << iBIT_CMDE_OUVERTURE_GACHE;
	iStatus = DAQmxWriteDigitalU8 
			(GhTacheCmdeOuvertureGache, 1, FALSE, fTIME_OUT_WRITE_DAQ, DAQmx_Val_GroupByScanNumber, &ucValeur, &iNbValeurs, 0);
	#endif
	
	LiberationJeton (GhMutex); 
	return iStatus;
}

// DEBUT ALGO
//****************************************************************************** 
// int Usb6008MesurePression (double *dPression)
//******************************************************************************
//	- double *dPression		: valeur de la pression (bars)
//
//  - Mesure de la pression
//
//  - 0 si Ok
//	  erreur si <0
//	  warning si >0
//******************************************************************************
// FIN ALGO
int Usb6008MesurePression (double *dPression)
{
int i;
double dMoy;
double fValeur;

	// Filtre de Butterworth
	#define iFREQU_ECHANT	10000
	#define iFREQU_COUP_HZ	600
	#define iFILTER_ORDER	3
	// Nombre d'�chantillons
	#define iNB_ELTS_ACQU 	100
	
	#ifndef bSIMUL_USB_6008 
	float64 tfValeurIn[iNB_ELTS_ACQU];
	float64 tfValeurOut[iNB_ELTS_ACQU];
	//float64 fValeur;
	float64 fSum;
	int32 iNbValeurs;
	#endif
	//double dValeur;
	int iStatus;	  

	DemandeAttenteJeton(GhMutex, GlTIMEOUT_MUTEX_MS);
	fValeur = 0.0;

	#ifdef bSIMUL_USB_6008
		*dPression = 0.0;
		LiberationJeton (GhMutex); 
		return 0;
	#else 
	if ((iStatus = DAQmxReadAnalogF64 (GhTacheMesurePression, iNB_ELTS_ACQU, fTIME_OUT_READ_DAQ, DAQmx_Val_GroupByScanNumber, tfValeurIn, iNB_ELTS_ACQU,
									   &iNbValeurs, 0)) != 0){
		LiberationJeton (GhMutex); 
		return iStatus;
	}   
		
	fSum = 0.0;
	for(i=0; i <iNbValeurs; i++)
		fSum += tfValeurIn[i];
	
	//Modif du 17/10/2011 par CB ----- DEBUT ---------------- 
	fValeur = fSum / ((float64)iNbValeurs);
	//Modif du 17/10/2011 par CB ----- FIN ---------------- 

		
	//Modif du 26/06/2011 par CB ----- DEBUT ----------------
	/*if ((iNbValeurs > 0) && (iNbValeurs <= iNB_ELTS_ACQU)){
		// On applique un filtre passe bas sur les mesures
		Bw_LPF (tfValeurIn, iNbValeurs, iFREQU_ECHANT, iFREQU_COUP_HZ, iFILTER_ORDER, tfValeurOut);
	
		// On r�alise une moyenne sur les valeurs filtr�es
		for(i=0; i<iNbValeurs; i++) 
			fValeur += tfValeurOut[i];
		
		fValeur /= (float64)iNbValeurs;	
	}   
	*/
	//Modif du 26/06/2011 par CB ----- FIN ----------------
	
	// Pression lue en Bars
	*dPression = fValeur * 2.0;
	#endif
	
	LiberationJeton (GhMutex); 
	return 0;
}

// DEBUT ALGO
//****************************************************************************** 
// int Usb6008CommandePression (double dPression)
//******************************************************************************
//	- double dPression		: valeur de la pression (bars)
//
//  - Commande de la pression
//
//  - 0 si Ok
//	  erreur si <0
//	  warning si >0
//******************************************************************************
// FIN ALGO
int Usb6008CommandePression (double dPression)
{
	#ifndef bSIMUL_USB_6008
	float64 fValeur;
	int32 iNbValeurs;
	#endif
	int iStatus;

	DemandeAttenteJeton(GhMutex, GlTIMEOUT_MUTEX_MS);
	
	#ifdef bSIMUL_USB_6008
		LiberationJeton (GhMutex); 
		return 0;
	#else
	
	// Modif du 01/02/2012 par CB --- DEBUT -----
	if(dPression < 0.0)
		dPression = 0.0;
	// Modif du 01/02/2012 par CB --- FIN -----
	
	fValeur = dPression / 4;
	iStatus = DAQmxWriteAnalogScalarF64 (GhTacheCommandePression, FALSE, fTIME_OUT_WRITE_DAQ, fValeur, 0);
	#endif
	
	LiberationJeton (GhMutex); 
	return iStatus;
}

//******************************************************************************
