
#ifndef RESULT_TEXT_FILE_LIB
	#define RESULT_TEXT_FILE_LIB


#define DLLEXPORT __declspec(dllexport)
#ifdef __cplusplus
	extern "C"{
#endif

//------------ Modif du 31/07/2012 par C. BERENGER  DEBUT -----------
#define	iNB_MAX_BYTE_FILE_LINE							100000//5000
//------------ Modif du 31/07/2012 par C. BERENGER  FIN -----------
#define iNB_MAX_BYTE_OF_FILE_PATHNAME					FILENAME_MAX
#define iNB_MAX_FILE									100
#define iNB_MAX_BYTE_FILE_EXTENSION						4


// File structure
typedef struct
{
	BOOL bFileOpen;
	BOOL bProtectFile;
	FILE *ptSystemFileHandle;
	unsigned int uiFileLineMax;
	unsigned int uiFileSizeMax;
	char sFilePathName[iNB_MAX_BYTE_OF_FILE_PATHNAME];
	char sFullPathName[iNB_MAX_BYTE_OF_FILE_PATHNAME];
	char sExtension[iNB_MAX_BYTE_FILE_EXTENSION];
	char sFirstLineFile[iNB_MAX_BYTE_FILE_LINE];
	int iCptNbLineFile;
	unsigned int uiCptSizeFile;
	int iFileNameIndex;
} stTabFile;




// Functions to export
/****************************************************************************/
/*   PURPOSE : Return Dll Version                                           */
/*																			*/
/*	- double *ptdVersion	=> Dll version									*/
/****************************************************************************/
void DLLEXPORT ResultTextFileDllVersion(double *ptdVersion);

/****************************************************************************/
/*   PURPOSE : Reset the file structure and close all files			        */
/*																			*/
/*	- stTabFile *ptstTabFile	=> Address of the files structure			*/
/*	- unsigned int uiNbMaxFiles	=> Max number of files to use				*/
/*	- unsigned int uiNbElements => Number of elements to reset				*/
/****************************************************************************/
void DLLEXPORT ResultTextFileResetAll(stTabFile *ptstTabFile, 
							unsigned int uiNbMaxFiles,
							unsigned int uiNbElements,
							int *iptError);

/****************************************************************************/
/*   PURPOSE : Reset a file component                                       */
/*																			*/
/*	- stTabFile *ptstTabFile	=> Address of the files structure			*/
/*	- unsigned int uiNbMaxFiles	=> Max number of files to use				*/
/*  - unsigned int uiIndex		=> Index of file to reset    				*/
/*	- int *iptError				=> Error code (0=No error, -1=Error)		*/
/****************************************************************************/
void DLLEXPORT ResultTextFileResetFile(	stTabFile *ptstTabFile, 
								unsigned int uiNbMaxFiles,
								unsigned int uiIndex, 
								int *iptError);

/****************************************************************************/
/*   PURPOSE : Return the full pathname of the index file                   */
/*																			*/
/*	- stTabFile *ptstTabFile	=> Address of the files structure			*/
/*	- unsigned int uiIndex		=> Index of the result file					*/
/*	- unsigned int uiNbMaxFiles	=> Files number of the structure			*/
/*	- char *sFullPathname		=> Full pathname of the result file			*/
/*	- int *iptError				=> Error code (0=No error, -1=Error)		*/
/****************************************************************************/
void DLLEXPORT ResultTextFileGetFullPathname(	stTabFile *ptstTabFile, 
									unsigned int uiIndex,
									unsigned int uiNbMaxFiles,
									char *sFullPathname, 
									int *iptError);

/****************************************************************************/
/*   PURPOSE: Return the number of used files                               */
/*																			*/
/*	- Return: Number of files used											*/
/*	- stTabFile *ptstTabFile	=> Address of the files structure			*/
/*	- unsigned int uiNbMaxFiles	=> Files number of the structure			*/
/****************************************************************************/
int DLLEXPORT ResultTextFileGetNbFilesInUse(stTabFile *ptstTabFile, unsigned int uiNbMaxFiles);

/****************************************************************************/
/*   PURPOSE: Return the nmber of the first free index in the file list     */
/*																			*/
/*	- Return: First free file index											*/
/*	- stTabFile *ptstTabFile	=> Address of the files structure			*/
/*	- unsigned int uiNbMaxFiles	=> Files number of the structure			*/
/****************************************************************************/
int DLLEXPORT ResultTextFileGetFreeIndex(stTabFile *ptstTabFile, unsigned int uiNbMaxFiles);

/****************************************************************************/
/*   PURPOSE : Create a result text file	                                */
/*																			*/
/*	- stTabFile *ptstTabFile		=> Address of the files structure		*/
/*	- unsigned int uiNbMaxFiles		=> Files number of the structure		*/
/*	- char *sFilePathName			=> Full pathname of the result file		*/
/*	- char *sExtension				=> Extension of the result file			*/
/*	- unsigned int uiProtectFile	=> 1=Set file in Read only when closed	*/
/*	- unsigned int uiFileSizeMax	=> Size max of the result file(in bytes)*/
/*	- unsigned int uiFileLineMax	=> Max line number of the result file	*/
/*	- int *iptFileIndex				=> Index of the result file in the list	*/
/*	- int *iptError					=> Error code (0=No error, -1=Error)	*/
/****************************************************************************/
void DLLEXPORT ResultTextFileCreate(stTabFile *ptstTabFile, 
						  unsigned int uiNbMaxFiles,
						  char *sFilePathName, 
						  char *sExtension,
						  unsigned int uiProtectFile,
						  unsigned int uiFileSizeMax, 
						  unsigned int uiFileLineMax, 
						  int *iptFileIndex, 
						  int *iptError);

/****************************************************************************/
/*   PURPOSE : Open a result text file		                                */
/*																			*/
/*	- stTabFile *ptstTabFile		=> Address of the files structure		*/
/*	- unsigned int uiNbMaxFiles		=> Files number of the structure		*/
/*	- unsigned int uiFileIndex		=> Index of the file to open			*/
/*	- int *iptError					=> Error code (0=No error, <0=Error)	*/
/****************************************************************************/
void DLLEXPORT ResultTextFileOpen(stTabFile *ptstTabFile, 
						unsigned int uiNbMaxFiles,
						unsigned int uiFileIndex,
						int *iptError);

/****************************************************************************/
/*   PURPOSE : Add data to result text file		                            */
/*																			*/
/*	- stTabFile *ptstTabFile	=> Address of the files structure			*/
/*	- unsigned int uiNbMaxFiles	=> Files number of the structure			*/
/*	- unsigned int uiFileIndex	=> Index of the result file					*/
/*	- char *sTextBuffer			=> String to add in the result file			*/
/*	- BOOL bCloseFile			=> 1=Close file, 0= don't close file		*/
/*	- int *iptError				=> Error code (0=No error, <0 =Error)		*/
/****************************************************************************/
void DLLEXPORT ResultTextFileAdd(	stTabFile *ptstTabFile, 
						unsigned int uiNbMaxFiles,
						unsigned int uiFileIndex, 
						char *sTextBuffer, 
						BOOL bCloseFile, 
						int *iptError);

/****************************************************************************/
/*   PURPOSE : Close result text file			                            */
/*																			*/
/*	- stTabFile *ptstTabFile	=> Address of the files structure			*/
/*	- unsigned int uiNbMaxFiles	=> Files number of the structure			*/
/*	- unsigned int uiFileIndex	=> Index of the file to close				*/
/*	- int *iptError				=> Error code (0=No error, <0 =Error)		*/
/****************************************************************************/
void DLLEXPORT ResultTextFileClose(	stTabFile *ptstTabFile, 
							unsigned int uiNbMaxFiles,
							unsigned int uiFileIndex, 
							int *iptError);

/****************************************************************************/
/*   PURPOSE : Return the error message of the error code				    */
/*																			*/
/*	- int iError	=> Error number											*/
/*	- char sMsg[]	=> Error message										*/
/****************************************************************************/
void DLLEXPORT ResultTextFileGetLastError(int iError, char sMsg[]);



#ifdef __cplusplus
	}
#endif

#endif // End LIB
