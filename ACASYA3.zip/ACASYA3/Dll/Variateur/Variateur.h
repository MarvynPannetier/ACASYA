// DEBUT TABLE
//******************************************************************************
// PRO: BANC DE TEST LSE
// PRG: Variateur.h
// VER: Version I00A00A du 14/09/2010
// AUT: MP. LACROIX / MICROTEC
//
// ROL: Gestion du variateur
//
// HST: Version I00A00A du 14/09/2010 / MP. LACROIX MICROTEC / Cr�ation
//******************************************************************************
//
//******************************************************************************
// FIN TABLE

//******************************************************************************
// Inclusions
//******************************************************************************

// Librairies standards 

// Librairies FOURNISSEUR

// Librairies MICROTEC

// Librairies sp�cifiques � l'application

#ifndef LIB_VARIATEUR
	#define LIB_VARIATEUR

//******************************************************************************
// D�finition de constantes
//******************************************************************************

// Option de compilation pour simulation de la communication
//#define bSIMUL_VARIATEUR

// Sens de rotation
#define iVARIATEUR_MARCHE_AVANT				0
#define iVARIATEUR_MARCHE_ARRIERE			1

//******************************************************************************
// D�finition de types et structures
//******************************************************************************

//******************************************************************************
// Variables globales
//******************************************************************************

//******************************************************************************
// Fonctions export�es
//******************************************************************************

//  - Initialisation de la communication avec le variateur
int VariateurInitCom (int iPortCom, long lVitesse);

//  - Arr�t de la communication avec le variateur
void VariateurCloseCom (void);

//  - D�termination consigne vitesse atteinte
int VariateurConsigneVitesseAtteinte (short *wConsigneAtteinte);
	
//  - Mesure vitesse courante
int VariateurMesureVitesse (float *fVitesse);

//  - Emission consigne de vitesse et mise en route du variateur
int VariateurCommandeVitesse (float fVitesse, short wSens);
	
//  - Arr�t du variateur
int VariateurArret (void);

//  - Programmation d'une rampe
int VariateurProgrammationRampe (float fVitesseDebut, float fVitesseFin, float fDuree);

#endif

//******************************************************************************
