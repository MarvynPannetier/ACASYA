// DEBUT TABLE
//******************************************************************************
// PRO: BANC DE TEST LSE
// PRG: Serie.h
// VER: Version I00A00A du 14/09/2010
// AUT: MP. LACROIX / MICROTEC
//
// ROL: D�finition de constantes pour la liaison s�rie RS232  
//
// HST: Version I00A00A du 14/09/2010 / MP. LACROIX MICROTEC / Cr�ation
//******************************************************************************
//
//******************************************************************************
// FIN TABLE

#ifndef LIB_SERIE
	#define LIB_SERIE

//******************************************************************************
// D�finition de constantes
//******************************************************************************

// Caract�res ASCII
#define cSTX					0x02
#define cETX					0x03
#define cEOT					0x04
#define cENQ					0x05
#define cACK					0x06
#define cLINE_FEED				0x0A
#define cRETURN					0x0D
#define cNAK					0x15

// Parit�
#define iSANS_PARITE			0
#define iPARITE_IMPAIRE			1
#define iPARITE_PAIRE			2
#define iPARITE_1				3	// mark
#define iPARITE_0				4	// space

//******************************************************************************
// D�finition de types et structures
//******************************************************************************

//******************************************************************************
// Variables globales
//******************************************************************************

//******************************************************************************
// Fonctions export�es
//******************************************************************************

#endif

//****************************************************************************** 
