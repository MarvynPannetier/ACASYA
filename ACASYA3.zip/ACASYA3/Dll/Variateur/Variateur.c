// DEBUT TABLE
//******************************************************************************
// PRO: BANC DE TEST LSE
// PRG: Variateur.c
// VER: Version I00A00B du 15/11/2010
// AUT: MP. LACROIX / MICROTEC
//
// ROL: Gestion du variateur
//
// HST: Version I00A00A du 14/09/2010 / MP. LACROIX MICROTEC / Cr�ation
// HST: Version I00A00B du 15/11/2010 / C.BERENGER / 
//		- Passage de la r�solution moteur � 0.1 tours/min
//		- Modification de l'affichage du graphique en mode manuel
//		- Correction du probl�me de gestion des limites apr�s le chargement
//	      d'un cycle dans une autre unit� de vitesse ou de pression que celle 
//	      utilis�e par d�faut.
// HST: Version I00A00C du 30/11/2010 / C. BERENGER MICROTEC / 
//	    - Ajout d'une gestion par watchdog pour couper le moteur et la pression 
//	      en cas de probl�me de blocage de l'application.
// HST: Version I00A00D du 04/01/2011 / C. BERENGER MICROTEC / 
//	    - Ajout de quelques Mutex
//		- Suppresison de l'utilisation du fichier "MessageIhm.ini", et remplacement par des constantes
//		- Recompilation du programme avec la version 8.6.0f5 du DAQmx (identique � la version install�e sur le banc du client)
//		- Passage de la variable "GptstConfig" en mode prot�g� dans le fichier "Modes.c"
//******************************************************************************
//
//******************************************************************************
// FIN TABLE

//******************************************************************************
// Inclusions
//******************************************************************************

// Librairies standards 
#include <userint.h>
#include <utility.h>
#include <ansi_c.h>
#include <formatio.h>
#include <rs232.h>

// Librairies FOURNISSEUR

// Librairies MICROTEC

// Librairies sp�cifiques � l'application
#include "Serie.h"
#include "Variateur.h"
#include "IhmSimul.h"
#include "Simulation.h"
#include "Mutex.h"

//******************************************************************************
// D�finition de constantes
//******************************************************************************

// Option de compilation d�finissant le protocole de communication (MODBUS RTU | ANSI)
//#define bCOM_MODBUS_RTU

// Adresse du variateur
#ifdef bCOM_MODBUS_RTU
	#define iADRESSE_VARIATEUR					11
#else
	#define iGROUPE_VARIATEUR					1
	#define iUNITE_VARIATEUR					1
#endif

// Codes des fonctions
#define iFONCTION_LECTURE						0x03
#define iFONCTION_ECRITURE						0x10

// Type des donn�es
#define iTYPE_INT_16							0
#define iTYPE_INT_32							1
#define iTYPE_FLOAT_32							2

// Param�tres
#define iMENU_COMMANDE_VITESSE					1
#define iPARAMETRE_SELECTION_VITESSE			14
#define iPARAMETRE_VITESSE_UN_DIGIT				18
#define iPARAMETRE_VITESSE_DEUX_LAST_DIGITS		19
#define iMENU_RAMPES							2
#define iPARAMETRE_RAMPE_ACCELERATION			11
#define iPARAMETRE_RAMPE_DECELERATION			21
#define iMENU_ETAT_VITESSE						3
#define iPARAMETRE_VITESSE_MESUREE				2
#define iMENU_MARCHE_ARRET						6
#define iPARAMETRE_MARCHE_AVANT					30
#define iPARAMETRE_MARCHE_ARRIERE				32

#define iPARAMETRE_CTRL_MOTEUR					42		// Pilote la marche avant / arri�re
#define iPARAMETRE_VALID_CTRL_MOTEUR			43		// A 1 pour piloter le moteur

#define iMENU_ETAT								10
#define iPARAMETRE_CONSIGNE_ATTEINTE			6

#define iMARCHE_AVANT							131  // 10000011
#define iMARCHE_ARRIERE							137  // 10001001
#define iSTOP									193	 // 11000001

// Longueur des messages
#define iLG_MESSAGE_MAX							50

// Essais de liaison avec le variateur avant de d�clarer une erreur
#define NB_ESSAIS_LIAISON_VARIATEUR				1

// P�riode de silence apr�s une commande pour traitement par le variateur
#define fDELAI_VARIATEUR						0.010		// 10 ms
#define iTIMEOUT_READ_MS						2000
#define GlTIMEOUT_MUTEX_MS						20000   

//******************************************************************************
// D�finition de types et structures
//******************************************************************************

//******************************************************************************
// Variables globales
//******************************************************************************

// Port de communication
static int GiPortCom;
static int GiPanel = 0; 
static HANDLE GhMutex;

//******************************************************************************
// Fonctions internes au source
//******************************************************************************
#define CHECK_VAL(sId, dVal, dValMin, dValMax)			\
{														\
	if ((dVal < dValMin) || (dVal > dValMax))			\
		MessagePopup(sId, "Val Error");					\
}


// DEBUT ALGO
//****************************************************************************** 
// int VariateurReadByte (int iPortCom, long lVitesse)
//******************************************************************************
//	- int iPortCom		: adresse du port s�rie
//	  long lVitesse		: vitesse de communication (bauds)
//
//  - Initialisation de la communication avec le variateur
//
//  - 0 si Ok
//	  erreur sinon
//******************************************************************************
// FIN ALGO
int VariateurReadByte (int iPortCom)
{
int iByteRead;
int iReadQueueLength;
int iTimeDep;
int iTime;
int iStatus;

	// Initialisations
	iByteRead 		= 0x00;
	iReadQueueLength= 0;
	// Temps de d�part
	iTimeDep = clock();

	// Attente de r�ception d'un octet
	do{
		ProcessSystemEvents();
		
		// Lecture du nombre d'octets re�us
		iReadQueueLength = GetInQLen (iPortCom);

		if(iReadQueueLength > 0)
			iByteRead = ComRdByte (iPortCom);

		// Calcul du temps �coul�
		iTime = ((clock() - iTimeDep) * 1000) / ((double)CLOCKS_PER_SEC);
	}while ((iReadQueueLength <= 0) && (iTime < iTIMEOUT_READ_MS));
	
	// S'il y a eu un timeout
	if (iReadQueueLength <= 0)
		return -1;
	
	// On retourne l'octet lu
	return iByteRead;
}

// DEBUT ALGO
//****************************************************************************** 
// int VariateurInitCom (int iPortCom, long lVitesse)
//******************************************************************************
//	- int iPortCom		: adresse du port s�rie
//	  long lVitesse		: vitesse de communication (bauds)
//
//  - Initialisation de la communication avec le variateur
//
//  - 0 si Ok
//	  erreur sinon
//******************************************************************************
// FIN ALGO
int VariateurInitCom (int iPortCom, long lVitesse)
{
	int iStatus;
	
	iStatus = CreationJeton (&GhMutex, "VARIATEUR");
	
	GiPanel = GetSimuHandle();
	
	GiPortCom = iPortCom;
	
	#ifdef bSIMUL_VARIATEUR
		/*GetCtrlVal (GiPanel, PANEL_SIMU_VARIATOR_COMM, &iStatus);
		return iStatus;  */
		return 0;
	#endif
	

	#ifdef bCOM_MODBUS_RTU
		if ((iStatus = OpenComConfig (GiPortCom, "", lVitesse, iSANS_PARITE, 8, 2, 512, 512)) != 0)
			return 1;
	#else
		if ((iStatus = OpenComConfig (GiPortCom, "", lVitesse, iPARITE_PAIRE, 7, 1, 512, 512)) != 0)
			return 1;
	#endif
	
	#ifdef bSIMUL_VARIATEUR 
	if ((iStatus = SetComTime (GiPortCom, 0.01)) != 0)
		return 1;
	#else
	//if ((iStatus = SetComTime (GiPortCom, 0.3)) != 0)
	if ((iStatus = SetComTime (GiPortCom, 0.1)) != 0)
		return 1;
	#endif	
		
	if ((iStatus = FlushInQ (GiPortCom)) != 0)
		return iStatus;
	if ((iStatus = FlushOutQ (GiPortCom)) != 0)
		return 1;


	
	return 0;
}

// DEBUT ALGO
//****************************************************************************** 
// void VariateurCloseCom (void)
//******************************************************************************
//	- aucun
//
//  - Arr�t de la communication avec le variateur
//
//  - aucun
//******************************************************************************
// FIN ALGO
void VariateurCloseCom (void)
{
	#ifdef bSIMUL_VARIATEUR 
	#else
	CloseCom (GiPortCom);
	#endif
	
	DestructionJeton (GhMutex);  
}

// DEBUT ALGO
//****************************************************************************** 
// unsigned short VariateurValChecksum (char sData [], int iIdBegin, int iIdEnd) 
//******************************************************************************
//	- char sData []	: donn�es
//	  int iIdBegin	: indice de d�but du calcul
//	  int iIdEnd	: indice de fin du calcul
//
//  - Calcul du checksum
//
//  - valeur du checksum
//******************************************************************************
// FIN ALGO
unsigned short VariateurValChecksum (char sData [], int iIdBegin, int iIdEnd)
{
	unsigned short uwChecksum;
	int iData;
	int iCalcul;
	BOOL bImpair;
	
	#ifdef bCOM_MODBUS_RTU
		uwChecksum = 0xFFFF;
		for (iData = iIdBegin; iData < iIdEnd; iData++)	{
			uwChecksum ^= sData [iData];
			for (iCalcul = 0; iCalcul < 8; iCalcul++)	{
				bImpair = (uwChecksum & 0x0001) != 0x0000;
				uwChecksum = uwChecksum >> 1;
				if (bImpair)
					uwChecksum ^= 0xA001;
			}
		}
	#else
		uwChecksum = 0;
		for (iData = iIdBegin; iData < iIdEnd; iData++) 
			uwChecksum = uwChecksum ^ sData [iData];
		if (uwChecksum < 32)
			uwChecksum += 32;
	#endif

	return uwChecksum;
}

// DEBUT ALGO
//****************************************************************************** 
// int VariateurLectureParametre (...)
//******************************************************************************
//	- int iMenu			: indice du menu
//	  int iParametre	: indice du param�tre
//	  int iType, 		: type du param�tre
//	  void *pValeur		: valeur du param�tre
//
//  - Lecture d'un param�tre
//
//  - 0 si Ok
//	  erreur sinon
//******************************************************************************
// FIN ALGO
int VariateurLectureParametre (int iMenu, int iParametre, int iType, void *pValeur)
{
	unsigned char sCommande [iLG_MESSAGE_MAX];
	unsigned char sReponse [iLG_MESSAGE_MAX];
	unsigned char sParametre [iLG_MESSAGE_MAX];
	int iNbOctets;
	int iData;
	int iStatus;
 	int iLiaison;
 	int iAdresse;
 	int iLgReponse;
 	int *iValeur;
 	short *wValeur;
 	double dTime;
 	float *fValeur;
 	unsigned short uwChecksum;
 	BOOL bErreur;
 	BOOL bFinReponse;
  

	#ifdef bSIMUL_VARIATEUR
		return 0;
	#endif
	
	iLiaison = 0;
	iStatus = -1;
	while (iStatus != 0)	{
		if (iLiaison > 0){
		  	dTime = Timer();
		  	SyncWait(dTime, 0.1); 
			//Delay (0.1);
		}
		
		FlushInQ (GiPortCom);
		FlushOutQ (GiPortCom);
			
		#ifdef bCOM_MODBUS_RTU

			// Emission requ�te
			sCommande [0] = iADRESSE_VARIATEUR;
			sCommande [1] = iFONCTION_LECTURE;
			iNbOctets = sizeof (pValeur);
			iAdresse = (iMenu * 100) + iParametre - 1;
			switch (iType)	{
				case iTYPE_INT_16	:
						iNbOctets = 2;
					break;
				case iTYPE_INT_32	:
						iNbOctets = 4;
						iAdresse += 0x4000;
					break;
				case iTYPE_FLOAT_32	:
						iNbOctets = 4;
						iAdresse += 0x8000;
					break;
			}
			sCommande [2] = iAdresse / 256;
			sCommande [3] = iAdresse % 256;
			sCommande [4] = 0;						// Nb mots
			sCommande [5] = iNbOctets / 2;			// Nb mots
			uwChecksum = VariateurValChecksum (sCommande, 0, 6);    
			sCommande [6] = uwChecksum % 256;
			sCommande [7] = uwChecksum / 256;
		    if ((iStatus = ComWrt (GiPortCom, sCommande, 8)) > 0)
		    	iStatus = 0;
 
			// R�ception r�ponse
			bErreur = 0;
			iLgReponse = iLG_MESSAGE_MAX;
			iData = 0;
			while ((iStatus == 0) && (iData < iLgReponse)) {
				
				if ((iStatus = VariateurReadByte (GiPortCom)) > 0)	{
					sReponse [iData] = iStatus;
					iData++;
		 			iStatus = 0;
			 		if ((iData == 2) && ((sReponse [1] & 0x80) != 0))	{
			 			bErreur = 1;
			 			iLgReponse = 5;
		 			
			 		}
			 		if ((iData == 3) && (!bErreur))
			 			iLgReponse = sReponse [2] + 5;
				}
			 }
 	
	    	// Analyse syntaxe de la r�ponse
	    	if (iStatus == 0)	{
	 			if ((sReponse [0] != iADRESSE_VARIATEUR) || ((sReponse [1] & 0x7F) != iFONCTION_LECTURE))
					iStatus = kRS_InvalidParameter;
				else	{
					uwChecksum = VariateurValChecksum (sReponse, 0, iLgReponse - 2);    
					if ((sReponse [iLgReponse - 2] != (uwChecksum % 256)) 
							|| (sReponse [iLgReponse - 1] != (uwChecksum / 256)))
					iStatus = kRS_CheckSumError;
				}
			}
		
		 	// Extraction de la valeur
	 		if (iStatus == 0)	{
	    		if (bErreur)	{
					iStatus = kRS_InvalidParameter;
					iLiaison = NB_ESSAIS_LIAISON_VARIATEUR;
				}
				else
					switch (iType)	{
						case iTYPE_INT_16	:
								wValeur = pValeur;
								*wValeur = (sReponse [3] << 8) + sReponse [4];
							break;
						case iTYPE_INT_32	:
								iValeur = pValeur;
								*iValeur = (sReponse [3] << 24) + (sReponse [4] << 16) + (sReponse [5] << 8) + sReponse [6];
							break;
						case iTYPE_FLOAT_32	:
								memcpy (pValeur, &sReponse [3], sReponse [2]); 	
							break;
					}
			}

		#else

			// Emission requ�te
			sprintf (sCommande, "%c%d%d%d%d%02d%02d%c", 
					cEOT, iGROUPE_VARIATEUR, iGROUPE_VARIATEUR, iUNITE_VARIATEUR, iUNITE_VARIATEUR, iMenu, iParametre, cENQ);
		    if ((iStatus = ComWrt (GiPortCom, sCommande, strlen (sCommande))) > 0)
		    	iStatus = 0;
 
			// R�ception message <STX ... ETX>
			iLgReponse = 0;
			bFinReponse = 0;
			while ((iStatus == 0) && (iLgReponse < iLG_MESSAGE_MAX) && (!bFinReponse)) {
				if ((iData = VariateurReadByte (GiPortCom)) < 0)
		 			iStatus = iData;
		 		else	{
		 			iStatus = 0;
					sReponse [iLgReponse] = iData;
					if ((iLgReponse == 0) && (sReponse [iLgReponse] == cNAK))
			 			iStatus = kRS_InvalidParameter;
					bFinReponse = (sReponse [iLgReponse] == cETX);
					iLgReponse ++;
				}
			 }
 	
			// R�ception checksum message 
			if (iStatus == 0)	{
				if ((iData = VariateurReadByte (GiPortCom)) < 0) 
					iStatus = iData;
			}

	    	// Analyse syntaxe de la r�ponse
	    	if (iStatus == 0)	{
	 			if ((sReponse [0] != cSTX) || (sReponse [(iLgReponse - 1)] != cETX))
					iStatus = kRS_InvalidParameter;
			}
	    	if (iStatus == 0)	{
				uwChecksum = VariateurValChecksum (sReponse, 1, iLgReponse);
				if (uwChecksum != iData)
					iStatus = kRS_CheckSumError;
			}
		
		 	// Extraction de la valeur
	 		if (iStatus == 0)	{
 				memcpy (sParametre, &sReponse [5], iLgReponse - 6);
 				sParametre [iLgReponse - 6] = '\0';
				switch (iType)	{
					case iTYPE_INT_16	:
							wValeur = pValeur;
							sscanf (sParametre, "%hd", wValeur);
						break;
					case iTYPE_INT_32	:
							iValeur = pValeur;
							sscanf (sParametre, "%d", iValeur);
						break;
					case iTYPE_FLOAT_32	:
							fValeur = pValeur;
							sscanf (sParametre, "%f", fValeur);
						break;
				}
	 		}

		#endif
		
		iLiaison++;   
		
		if ((iStatus == 0) || (iLiaison >= NB_ESSAIS_LIAISON_VARIATEUR))	
			return iStatus;
	}
	
	return 0;
}

// DEBUT ALGO
//****************************************************************************** 
// int VariateurEcritureParametre (...)
//******************************************************************************
//	- int iMenu			: indice du menu
//	  int iParametre	: indice du param�tre
//	  int iType, 		: type du param�tre
//	  void *pValeur		: valeur du param�tre
//
//  - Ecriture d'un param�tre
//
//  - 0 si Ok
//	  erreur sinon
//******************************************************************************
// FIN ALGO
int VariateurEcritureParametre (int iMenu, int iParametre, int iType, void *pValeur)
{
	unsigned char sCommande [iLG_MESSAGE_MAX];
	unsigned char sReponse [iLG_MESSAGE_MAX];
	unsigned char sParametre [iLG_MESSAGE_MAX];
	int iNbOctets;
	int iData;
	int iStatus;
 	int iLiaison;
 	int iAdresse;
 	int iLgReponse;
 	int *iValeur;
 	short *wValeur;
 	double dTime;
 	float *fValeur;
 	unsigned short uwChecksum;
 	BOOL bErreur;
   

	#ifdef bSIMUL_VARIATEUR
		return 0;
	#endif
	
	iLiaison = 0;
	iStatus = -1;
	while (iStatus != 0)	{
		if (iLiaison > 0){
		  	dTime = Timer();
		  	SyncWait(dTime, 0.1); 
			//Delay (0.1);
		}
			
		FlushInQ (GiPortCom);
		FlushOutQ (GiPortCom);
			
		#ifdef bCOM_MODBUS_RTU
		
			// Emission commande
			sCommande [0] = iADRESSE_VARIATEUR;
			sCommande [1] = iFONCTION_ECRITURE;
			iNbOctets = sizeof (pValeur);
			iAdresse = (iMenu * 100) + iParametre - 1;
			switch (iType)	{
				case iTYPE_INT_16	:
						iNbOctets = 2;
					break;
				case iTYPE_INT_32	:
						iNbOctets = 4;
						iAdresse += 0x4000;
					break;
				case iTYPE_FLOAT_32	:
						iNbOctets = 4;
						iAdresse += 0x8000;
					break;
			}
			sCommande [2] = iAdresse / 256;
			sCommande [3] = iAdresse % 256;
			sCommande [4] = 0;				// Nb mots
			sCommande [5] = iNbOctets / 2;	// Nb mots
			sCommande [6] = iNbOctets;		// Nb octets
			switch (iType)	{
				case iTYPE_INT_16	:
						wValeur = pValeur;
						sCommande [7] = (*wValeur >> 8) & 0xFF;
						sCommande [8] = *wValeur & 0xFF;
					break;
				case iTYPE_INT_32	:
						iValeur = pValeur;
						sCommande [7] = (*iValeur >> 24) & 0xFF;
						sCommande [8] = (*iValeur >> 16) & 0xFF;
						sCommande [9] = (*iValeur >> 8) & 0xFF; 
						sCommande [10] = *iValeur & 0xFF;
					break;
				case iTYPE_FLOAT_32	:
						memcpy (&sCommande [7], pValeur, iNbOctets); 	
					break;
			}
			uwChecksum = VariateurValChecksum (sCommande, 0, 7 + iNbOctets);    
			sCommande [7 + iNbOctets] = uwChecksum % 256;
			sCommande [8 + iNbOctets] = uwChecksum / 256;
		    if ((iStatus = ComWrt (GiPortCom, sCommande, 9 + iNbOctets)) > 0)
		    	iStatus = 0;

			// R�ception r�ponse
			bErreur = 0;
			iLgReponse = iLG_MESSAGE_MAX;
			iData = 0;
			while ((iStatus == 0) && (iData < iLgReponse)) {
				if ((iStatus = VariateurReadByte (GiPortCom)) > 0)	{
					sReponse [iData] = iStatus;
					iData++;
		 			iStatus = 0;
			 		if (iData == 2)	{
			 			if ((sReponse [1] & 0x80) != 0)	{
			 				bErreur = 1;
			 				iLgReponse = 5;
			 			}
			 			else
			 				iLgReponse = 8;
			 		}
				}
			 }
 	
	    	// Analyse syntaxe de la r�ponse
	    	if (iStatus == 0)	{
	 			if ((sReponse [0] != iADRESSE_VARIATEUR) || ((sReponse [1] & 0x7F) != iFONCTION_ECRITURE))
					iStatus = kRS_InvalidParameter;
				else	{
					uwChecksum = VariateurValChecksum (sReponse, 0, iLgReponse - 2);    
					if ((sReponse [iLgReponse - 2] != (uwChecksum % 256)) 
							|| (sReponse [iLgReponse - 1] != (uwChecksum / 256)))
					iStatus = kRS_CheckSumError;
				}
			}
		
	 		if (iStatus == 0)	{
	    		if (bErreur)	{
					iStatus = kRS_InvalidParameter;
					iLiaison = NB_ESSAIS_LIAISON_VARIATEUR;
				}
			}
		
		
		#else		
		
			// Emission commande
			switch (iType)	{
				case iTYPE_INT_16	:
						wValeur = pValeur;
						sprintf (sParametre, "%d", *wValeur);
					break;
				case iTYPE_INT_32	:
						iValeur = pValeur;
						sprintf (sParametre, "%d", *iValeur);
					break;
				case iTYPE_FLOAT_32	:
						fValeur = pValeur;
						//----------- Modif du 15/11/2010 par C.BERENGER ----- DEBUT -------
						//sprintf (sParametre, "%.2f", *fValeur);
						if ((iMenu == iMENU_COMMANDE_VITESSE) && (iParametre == iPARAMETRE_VITESSE_UN_DIGIT))
							sprintf(sParametre, "%.01f", *fValeur);
						else
							if ((iMenu == iMENU_COMMANDE_VITESSE) && (iParametre == iPARAMETRE_VITESSE_DEUX_LAST_DIGITS)){
								sprintf(sParametre, "0.0%d", (int) ( ( (*fValeur - TruncateRealNumber (*fValeur))) * 1000.0 ));
								sParametre[3] = sParametre[4];
								sParametre[4] = sParametre[5];
								sParametre[5] = sParametre[6];						
							}
						else
							sprintf (sParametre, "%.2f", *fValeur);
						//----------- Modif du 15/11/2010 par C.BERENGER ----- FIN -------
					break;
			}
			sprintf (sCommande, "%c%d%d%d%d%c%02d%02d%s%c", 
					cEOT, iGROUPE_VARIATEUR, iGROUPE_VARIATEUR, iUNITE_VARIATEUR, iUNITE_VARIATEUR, cSTX, iMenu, iParametre, sParametre, cETX);
			uwChecksum = VariateurValChecksum (sCommande, 6, strlen (sCommande));    
			sprintf (sCommande, "%s%c", sCommande, uwChecksum);
			iStatus = ComWrt (GiPortCom, sCommande, strlen (sCommande));

			// V�rification commande comprise par le variateur
			if (iStatus >= 0)	{
				if ((iStatus = VariateurReadByte (GiPortCom)) == cACK)
					iStatus = 0;
				else
		 			iStatus = kRS_NoAckReceived;
		 	}

		#endif		
		
		iLiaison++;
		

		if ((iStatus == 0) || (iLiaison >= NB_ESSAIS_LIAISON_VARIATEUR))	
			return iStatus;
	
	}
	return 0;
}

// DEBUT ALGO
//****************************************************************************** 
// int VariateurConsigneVitesseAtteinte (short *wConsigneAtteinte)
//******************************************************************************
//	- short *wConsigneAtteinte	: indicateur consigne vitesse atteinte 
//
//  - D�termination consigne vitesse atteinte
//
//  - 0 si Ok
//	  erreur sinon
//******************************************************************************
// FIN ALGO
int VariateurConsigneVitesseAtteinte (short *wConsigneAtteinte)
{
	int iStatus;
	int iConsAtt;
	double dTime;
  
  DemandeAttenteJeton(GhMutex, GlTIMEOUT_MUTEX_MS);
  
	#ifdef bSIMUL_VARIATEUR
		/*GetCtrlVal (GiPanel, PANEL_SIMU_VARIATOR_COMM, &iStatus);
		GetCtrlVal (GiPanel, PANEL_SIMU_CONS_ATTEINTE, &iConsAtt);
		
		*wConsigneAtteinte = iConsAtt;
		return iStatus;*/
		*wConsigneAtteinte = 1;
		
		LiberationJeton (GhMutex); 
		return 0;
	#endif
	
	iStatus = VariateurLectureParametre 
			(iMENU_ETAT, iPARAMETRE_CONSIGNE_ATTEINTE, iTYPE_INT_16, wConsigneAtteinte);
	
  	dTime = Timer();                    	
  	SyncWait(dTime, fDELAI_VARIATEUR); 
  	
  	LiberationJeton (GhMutex); 
  	
  	// Modif du 01/02/2012 par CB ----- DEBUT ------
  	if(*wConsigneAtteinte == 1)
  		Delay(0.3);
  	// Modif du 01/02/2012 par CB ----- FIN ------
  	
  	return iStatus;
}

// DEBUT ALGO
//****************************************************************************** 
// int VariateurMesureVitesse (...)
//******************************************************************************
//	- adresse du port s�rie 
//
//  - Mesure vitesse courante
//
//  - 0 si Ok
//	  erreur sinon
//******************************************************************************
// FIN ALGO
int VariateurMesureVitesse (float *fVitesse)
{
	int iStatus;
	double dSpeed;
	double dTime;
   
   DemandeAttenteJeton(GhMutex, GlTIMEOUT_MUTEX_MS);
	#ifdef bSIMUL_VARIATEUR
		/*GetCtrlVal (GiPanel, PANEL_SIMU_SIMU_SPEED, &dSpeed);
		*fVitesse = (float)dSpeed;
		
		GetCtrlVal (GiPanel, PANEL_SIMU_VARIATOR_COMM, &iStatus);
		return iStatus;
		*/
		*fVitesse = 0.0;
		
		LiberationJeton (GhMutex);
		return 0;
	#endif   
   
	iStatus = VariateurLectureParametre 
			(iMENU_ETAT_VITESSE, iPARAMETRE_VITESSE_MESUREE, iTYPE_FLOAT_32, fVitesse);

  	dTime = Timer();                    	
  	SyncWait(dTime, fDELAI_VARIATEUR);  	
  	
  	LiberationJeton (GhMutex);
  	return iStatus;
}

// DEBUT ALGO
//****************************************************************************** 
// int VariateurCommandeVitesse (float fVitesse, short wSens)
//******************************************************************************
//	- float fVitesse	: valeur de la vitesse
//	  short wSens		: sens de rotation
//
//  - Emission consigne de vitesse et mise en route du variateur
//
//  - 0 si Ok
//	  erreur sinon
//******************************************************************************
// FIN ALGO
int VariateurCommandeVitesse (float fVitesse, short wSens)
{
	short wCommandeActive = 1;
	short wCommandeInactive = 0;
	short wReferenceVitesse;
	short wSensRotation;
	short wActivPilotMoteur;
	double dTime;
	float fVitesseEntiere;
	float fVitesseDecimale;
	int iParametreActif;
	int iParametreInactif;
 	int iStatus;
   

	DemandeAttenteJeton(GhMutex, GlTIMEOUT_MUTEX_MS); 
	#ifdef bSIMUL_VARIATEUR
		/*// Affichage dans l'�cran de simulation
		SetCtrlVal (GetSimuHandle(), PANEL_SIMU_SPEED_TO_PROG, (double)fVitesse);
		
		GetCtrlVal (GiPanel, PANEL_SIMU_VARIATOR_COMM, &iStatus);
		
		if (wSens == iVARIATEUR_MARCHE_AVANT)
			SetCtrlVal (GetSimuHandle(), PANEL_SIMU_ENGINE_WAY, 1);
		else
			SetCtrlVal (GetSimuHandle(), PANEL_SIMU_ENGINE_WAY, 0);	

		return iStatus;*/
		LiberationJeton (GhMutex); 
		return 0;
	#endif	

	
	//   Modification du 17/10/2011 par C. BERENGER --- DEBUT ----
	//----------------------------
	// Sens de rotation
	switch (wSens)	{
		case iVARIATEUR_MARCHE_AVANT	:
			wSensRotation = iMARCHE_AVANT;
		break;
		case iVARIATEUR_MARCHE_ARRIERE	:
			wSensRotation = iMARCHE_ARRIERE;
		break;
	}
	
	// Param�tre contr�le moteur
	if ((iStatus = VariateurEcritureParametre 
			(iMENU_MARCHE_ARRET, iPARAMETRE_CTRL_MOTEUR, iTYPE_INT_16, &wSensRotation)) != 0){
		LiberationJeton (GhMutex); 
		return iStatus;
	}
	//----------------------------		
	//   Modification du 17/10/2011 par C. BERENGER --- FIN ---- 

	// R�f�rence vitesse = 5 (R�f�rence de pr�cision) 
	wReferenceVitesse = 5;
	if ((iStatus = VariateurEcritureParametre (iMENU_COMMANDE_VITESSE, iPARAMETRE_SELECTION_VITESSE, iTYPE_INT_16, &wReferenceVitesse)) != 0){
		LiberationJeton (GhMutex);
		return iStatus;
	}
	
  	dTime = Timer();
  	SyncWait(dTime, fDELAI_VARIATEUR); 
	//Delay (fDELAI_VARIATEUR);
	
    // Vitesse
	//----------- Modification du 15/11/2010 par C.BERENGER ---- DEBUT -------
	//fVitesseEntiere = TruncateRealNumber (fabs (fVitesse));
	//if ((fVitesseDecimale = fabs (fVitesse) - fVitesseEntiere) > 0.99)	{
	//	fVitesseEntiere++;
	//	fVitesseDecimale = 0;
	//}
	fVitesseEntiere = fabs (fVitesse);
	fVitesseDecimale= fVitesseEntiere;
	//----------- Modification du 15/11/2010 par C.BERENGER ---- FIN -------
	
	// Ecriture de la valeur de vitesse avec seulement un digit apr�s la virgule (ex: 196.5 pour 196.561)
	if ((iStatus = VariateurEcritureParametre 
			(iMENU_COMMANDE_VITESSE, iPARAMETRE_VITESSE_UN_DIGIT, iTYPE_FLOAT_32, &fVitesseEntiere)) != 0){
		LiberationJeton (GhMutex); 
		return iStatus;
	}
  	dTime = Timer();
  	SyncWait(dTime, fDELAI_VARIATEUR); 
	
	// Ecriture de la valeur de vitesse avec les deux derniers digits (ex: 0.061 pour 196.561)
 	if ((iStatus = VariateurEcritureParametre 
 			(iMENU_COMMANDE_VITESSE, iPARAMETRE_VITESSE_DEUX_LAST_DIGITS, iTYPE_FLOAT_32, &fVitesseDecimale)) != 0){
 		LiberationJeton (GhMutex); 
		return iStatus;
	}
  	dTime = Timer();
  	SyncWait(dTime, fDELAI_VARIATEUR); 
	
	// Commande � 1 pour piloter le moteur
	wActivPilotMoteur = 1;
	if ((iStatus = VariateurEcritureParametre 
			(iMENU_MARCHE_ARRET, iPARAMETRE_VALID_CTRL_MOTEUR, iTYPE_INT_16, &wActivPilotMoteur)) != 0){
		LiberationJeton (GhMutex); 
		return iStatus;
	}
  	dTime = Timer();
  	SyncWait(dTime, fDELAI_VARIATEUR); 
	
	//   Modification du 17/10/2011 par C. BERENGER --- DEBUT ---- 
	/*
	// Sens de rotation
	switch (wSens)	{
		case iVARIATEUR_MARCHE_AVANT	:
			wSensRotation = iMARCHE_AVANT;
		break;
		case iVARIATEUR_MARCHE_ARRIERE	:
			wSensRotation = iMARCHE_ARRIERE;
		break;
	}
	
	// Param�tre contr�le moteur
	if ((iStatus = VariateurEcritureParametre 
			(iMENU_MARCHE_ARRET, iPARAMETRE_CTRL_MOTEUR, iTYPE_INT_16, &wSensRotation)) != 0){
		LiberationJeton (GhMutex); 
		return iStatus;
	}
	*/
	//   Modification du 17/10/2011 par C. BERENGER --- FIN ---- 
	
  	dTime = Timer();
  	SyncWait(dTime, fDELAI_VARIATEUR); 
	
	LiberationJeton (GhMutex);
	return 0;
}

// DEBUT ALGO
//****************************************************************************** 
// int VariateurArret (void)
//******************************************************************************
//	- aucun
//
//  - Arr�t du variateur
//
//  - 0 si Ok
//	  erreur sinon
//******************************************************************************
// FIN ALGO
int VariateurArret (void)
{
	double dTime;
	short wCommande = 0;
	short wActivPilotMoteur;
 	int iStatus;
  
  	DemandeAttenteJeton(GhMutex, GlTIMEOUT_MUTEX_MS);
  	
	#ifdef bSIMUL_VARIATEUR
		/*// Affichage de la vitesse dans l'�cran de simulation
		SetCtrlVal (GetSimuHandle(), PANEL_SIMU_SPEED_TO_PROG, 0.0);
		
		GetCtrlVal (GiPanel, PANEL_SIMU_VARIATOR_COMM, &iStatus);
		return iStatus; */
		LiberationJeton (GhMutex); 
		return 0;
	#endif
	

	// Commande � 1 pour piloter le moteur
	wActivPilotMoteur = 1;
	if ((iStatus = VariateurEcritureParametre 
			(iMENU_MARCHE_ARRET, iPARAMETRE_VALID_CTRL_MOTEUR, iTYPE_INT_16, &wActivPilotMoteur)) != 0){
		LiberationJeton (GhMutex); 	
		return iStatus;
	}
	
  	dTime = Timer();
  	SyncWait(dTime, fDELAI_VARIATEUR); 
	//Delay (fDELAI_VARIATEUR);
	
	// Param�tre contr�le moteur
	wCommande = iSTOP;
	if ((iStatus = VariateurEcritureParametre 
			(iMENU_MARCHE_ARRET, iPARAMETRE_CTRL_MOTEUR, iTYPE_INT_16, &wCommande)) != 0){
		LiberationJeton (GhMutex); 
		return iStatus;
	}
	
  	dTime = Timer();
  	SyncWait(dTime, fDELAI_VARIATEUR); 
	//Delay (fDELAI_VARIATEUR);
	
	LiberationJeton (GhMutex); 
 	return 0;
}

// DEBUT ALGO
//****************************************************************************** 
// int VariateurProgrammationRampe (float fVitesseDebut, fVitesseFin, fDuree)
//******************************************************************************
//	- float fVitesseDebut	: valeur de la vitesse en d�but de rampe (tr/mn)
//	- float fVitesseFin		: valeur de la vitesse en fin de rampe (tr/mn)
//	  float fDuree			: dur�e de la rampe (secondes)
//
//  - Programmation d'une rampe
//
//  - 0 si Ok
//	  erreur sinon
//******************************************************************************
// FIN ALGO
int VariateurProgrammationRampe (float fVitesseDebut, float fVitesseFin, float fDuree)  
{
	double dTime;
	float fValeurDebut;
	float fValeurFin;
	float fValeurParametre;
	int iParametre;
	int iStatus;
	
	DemandeAttenteJeton(GhMutex, GlTIMEOUT_MUTEX_MS);
	
	fValeurDebut = fabs (fVitesseDebut);
	fValeurFin = fabs (fVitesseFin);
	

	if (fValeurDebut <= fValeurFin)	{
		iParametre = iPARAMETRE_RAMPE_ACCELERATION;
		fValeurParametre = (1000.0 * fDuree) / (fValeurFin - fValeurDebut);
	}
	else{
			iParametre = iPARAMETRE_RAMPE_DECELERATION;
			fValeurParametre = (1000.0 * fDuree) / (fValeurDebut - fValeurFin);
		}
	
	#ifdef bSIMUL_VARIATEUR 
		//SetCtrlVal (GetSimuHandle(), PANEL_SIMU_RAMPE_ACCELERATION, (double)fValeurParametre);
		LiberationJeton (GhMutex); 
		return 0;
	#endif
	
	#ifdef bSIMUL_VARIATEUR
	GetCtrlVal (GiPanel, PANEL_SIMU_VARIATOR_COMM, &iStatus);
	LiberationJeton (GhMutex); 
	return iStatus;
	#endif	
	
	if ((iStatus = VariateurEcritureParametre (iMENU_RAMPES, iParametre, iTYPE_FLOAT_32, &fValeurParametre)) != 0){
		LiberationJeton (GhMutex); 
		return iStatus;
	}
  	dTime = Timer();
  	SyncWait(dTime, fDELAI_VARIATEUR); 

	LiberationJeton (GhMutex); 
	return 0;
}

//******************************************************************************
