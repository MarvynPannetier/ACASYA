// ----------------------------------------------------------------------------
// This header part is automaticly filled in by clearcase. 
// Do not modify unless you know what you are doing.
// #F# Filename : Mutex.h #/F#
// #D#     Date : 08/01/2010 #/D#
// #V#  Version : \main\2 #/V#
// #LOG#
//      08/01/2010     /main/2     Creation et correction import perl
//  #/LOG#
// ----------------------------------------------------------------------------
// This header part is user free.
// ----------------------------------------------------------------------------

// DEBUT TABLE
//****************************************************************************** 
// PRO: Valise TCR Simulator
// PRG: Mutex.H
// VER: Version n�1 du 09/03/2009
//
// ROL: Gestion des mutex
//****************************************************************************** 
// FIN TABLE

#ifndef LIB_GESTION_MUTEX
	#define LIB_GESTION_MUTEX    

//****************************************************************************** 
// Inclusions
//****************************************************************************** 
	
// Librairies standards
//#include "MonWin.h"

// Librairies FOURNISSEUR

// Librairies MICROTEC

// Librairies sp�cifiques � l'application

//******************************************************************************
// D�finition de constantes
//******************************************************************************
#define bMUTEX_ENABLE

//******************************************************************************
// D�finition de types et structures
//******************************************************************************

//******************************************************************************
// Variables globales
//******************************************************************************

//******************************************************************************
// Fonctions export�es
//******************************************************************************

//  - Cr�ation d'un jeton
long CreationJeton (HANDLE *hMutex, char *sName);

//  - Demande et attente d'un jeton
long DemandeAttenteJeton (HANDLE hMutex, long lTimeOut);

//  - Lib�ration d'un jeton
long LiberationJeton (HANDLE hMutex);

//  - Destruction d'un jeton
void DestructionJeton (HANDLE hMutex);

#endif

//****************************************************************************** 
