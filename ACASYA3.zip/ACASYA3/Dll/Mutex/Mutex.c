// ----------------------------------------------------------------------------
// This header part is automaticly filled in by clearcase. 
// Do not modify unles you know what you are doing.
// #F# Filename : Mutex.c #/F#
// #D#     Date : 08/01/2010 #/D#
// #V#  Version : \main\2 #/V#
// #LOG#
//      08/01/2010     /main/2     Creation et correction import perl
//  #/LOG#
// ----------------------------------------------------------------------------
// This header part is user free.
// ----------------------------------------------------------------------------

// DEBUT TABLE
//****************************************************************************** 
// PRO: Valise TCR Simulator
// PRG: Fichier Mutex.C
// VER: Version n�1 du 09/03/2009
//
// ROL: Gestion des mutex
//****************************************************************************** 
// FIN TABLE

//****************************************************************************** 
// Inclusions
//****************************************************************************** 

// Librairies standards
#include "MonWin.h"
#include <windows.h>  

// Librairies FOURNISSEUR

// Librairies MICROTEC

// Librairies sp�cifiques � l'application
#include "Mutex.h"

//******************************************************************************
// D�finition de constantes
//******************************************************************************

//******************************************************************************
// D�finition de types et structures
//******************************************************************************

//******************************************************************************
// Variables globales
//******************************************************************************

//******************************************************************************
// Fonctions internes au source
//******************************************************************************

//******************************************************************************
// Corps des fonctions et proc�dures internes au source
//******************************************************************************

// DEBUT ALGO
//****************************************************************************** 
// long CreationJeton (HANDLE *hMutex, char *sName)
//****************************************************************************** 
//	- HANDLE *hMutex	: handle du jeton
//	  char *sName		: nom du jeton
//
//  - Cr�ation d'un jeton
//
//  - 0 si Ok
//	  erreur sinon
//****************************************************************************** 
// FIN ALGO
long CreationJeton (HANDLE *hMutex, char *sName)
{
	long lStatus;

	#ifdef bMUTEX_ENABLE
	*hMutex = CreateMutex (NULL, FALSE, sName);       
	if (hMutex == NULL) 
		lStatus = GetLastError ();
	else	{
		if (GetLastError () == ERROR_ALREADY_EXISTS)
			lStatus = 0;
		else 
			lStatus = GetLastError ();
	}
	return lStatus;
	#else
		return 0;
	#endif
}

// DEBUT ALGO
//****************************************************************************** 
// long DemandeAttenteJeton (HANDLE hMutex, long lTimeOut)
//****************************************************************************** 
//	- HANDLE hMutex		: handle du jeton
//	  long lTimeOut		: dur�e de l'attente du jeton en milli-secondes
//
//  - Demande et attente d'un jeton
//
//  - 0 si Ok
//	  erreur sinon
//****************************************************************************** 
// FIN ALGO
long DemandeAttenteJeton (HANDLE hMutex, long lTimeOut)
{
	long lStatus;

	#ifdef bMUTEX_ENABLE
	lStatus = WaitForSingleObject (hMutex, lTimeOut);
  	if (lStatus == WAIT_OBJECT_0)
  		return 0;
  	else
		return lStatus;
	#else
		return 0;
	#endif		
}

// DEBUT ALGO
//****************************************************************************** 
// long LiberationJeton (HANDLE hMutex)
//****************************************************************************** 
//	- HANDLE hMutex		: handle du jeton
//
//  - Lib�ration d'un jeton
//
//  - 0 si Ok
//	  erreur sinon
//****************************************************************************** 
// FIN ALGO
long LiberationJeton (HANDLE hMutex)
{
	long lStatus;

	#ifdef bMUTEX_ENABLE
	lStatus = ReleaseMutex (hMutex);
	return lStatus;
	#else
		return 0;
	#endif	
}

// DEBUT ALGO
//****************************************************************************** 
// void DestructionJeton (HANDLE hMutex)
//****************************************************************************** 
//	- HANDLE hMutex		: handle du jeton
//
//  - Destruction d'un jeton
//
//  - aucun
//****************************************************************************** 
// FIN ALGO
void DestructionJeton (HANDLE hMutex)
{
	#ifdef bMUTEX_ENABLE
	CloseHandle (hMutex);
	#endif	
}

//****************************************************************************** 
