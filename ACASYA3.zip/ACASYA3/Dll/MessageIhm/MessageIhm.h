
#ifndef MESSAGE_IHM_LIB
	#define MESSAGE_IHM_LIB

#define DLLEXPORT __declspec(dllexport)
#ifdef __cplusplus
	extern "C"{
#endif


//---------------------------------------------------------------------------
//---------------- Fonctions � exporter -------------------------------------

//***************************************************************************
//	- double *ptdVersion => Version de la Dll
//
//  - Retourne la version de Dll utilis�e
//
//  - Aucun
//***************************************************************************
void DLLEXPORT MessageIhmVersion(double *ptdVersion);

//***************************************************************************
//	- char *sVersion => Version de la Dll (Ex: "I03A00A")
//
//  - Retourne la version de Dll utilis�e sous forme d'une cha�ne de caract�res
//
//  - Aucun
//***************************************************************************
void DLLEXPORT MessageIhmVersionMicrotec(char *sVersion);

//***************************************************************************
//	- char *sFullPathName	=> chemin complet vers le fichier de messages
//
//  - Enregistre le chemin complet vers le fichier de messages
//
//  - Aucun
//***************************************************************************
void DLLEXPORT MessageIhmSetPathFile(char *sFullPathName);

//***************************************************************************
//	- char *sNomSection 			=> Nom de la section ou il faut lire un message
//	  int iIndiceMsg				=> Indice du message � lire dans la section indiqu�e
//
//  - Retourne le message associ� � l'indice du message
//
//  - Aucun
//***************************************************************************
char DLLEXPORT *MessageIhmGet(char *sNomSection,int iIndiceMsg);

#ifdef __cplusplus
	}
#endif

#endif // End LIB
