#include <ansi_c.h>
#include <cvirte.h>		
#include <userint.h>
#include "MultiFile.h"

static int panelHandle;

int SortByName(const void *element1, const void *element2);

int main (int argc, char *argv[])
{
	if (InitCVIRTE (0, argv, 0) == 0)
		return -1;	/* out of memory */
	if ((panelHandle = LoadPanel (0, "MultiFile.uir", PANEL)) < 0)
		return -1;
	DisplayPanel (panelHandle);
	RunUserInterface ();
	DiscardPanel (panelHandle);
	return 0;
}

int CVICALLBACK QuitCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_COMMIT:
			QuitUserInterface (0);
			break;
		}
	return 0;
}

int CVICALLBACK BrowseCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int numberSelected, i;
	char **fileList, fileName[260];
	int selectStatus;
	switch (event)
		{
		case EVENT_COMMIT:
		
			//selectStatus = MultiFileSelectPopup ("", "*.txt", "*.txt", "Select files", 0, 0, 1,  &numberSelected, &fileList);
			 selectStatus = MultiFileSelectPopupEx ("", "*.txt", "*.txt", "Select files", 0, 0,  &numberSelected, &fileList);          
			if (numberSelected > 0)
			{
				int sortEnable;
				ResetTextBox (panelHandle, PANEL_TEXTBOX, "");
				
				GetCtrlVal (panelHandle, PANEL_SORTCHECKBOX, &sortEnable);
				if (sortEnable)
					qsort (fileList, numberSelected,
							sizeof(fileList), SortByName);
				for (i=0; i<numberSelected; i++)
				{
					sprintf(fileName, "%s\n",*(fileList+i));
					SetCtrlVal (panelHandle, PANEL_TEXTBOX, fileName);
				}					
			}
			break;
		}
	return 0;
}

int SortByName(const void *element1, const void *element2)
{
	int caseSensitive, i;
	char **file1, **file2;
	int descreasingSort;
	char compareFile1[260];
	char compareFile2[260];

	file1 = element1;
	file2 = element2;
	
	GetCtrlVal (panelHandle, PANEL_DECREASINGBUTTON, &descreasingSort);
	GetCtrlVal (panelHandle, PANEL_CASECHECKBOX, &caseSensitive);
	
	if (caseSensitive)
	{
		strcpy(compareFile1, *file1);
		strcpy(compareFile2, *file2);
	}
	else
	{
		for (i=0; i< strlen(*file1); i++)
			compareFile1[i] = toupper((*file1)[i]);
		for (i=0; i< strlen(*file2); i++)
			compareFile2[i] = toupper((*file2)[i]);
	}
	
	if (descreasingSort)
		return (-1 * strcmp (compareFile1, compareFile2));
	else
		return (strcmp (compareFile1, compareFile2));
	
}

int CVICALLBACK EnableSortOptions_Callback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int sortEnable;
	switch (event)
		{
		case EVENT_COMMIT:
			GetCtrlVal (panelHandle, PANEL_SORTCHECKBOX, &sortEnable);
			SetCtrlAttribute (panelHandle, PANEL_DECREASINGBUTTON,
							ATTR_DIMMED, !sortEnable);
			SetCtrlAttribute (panelHandle, PANEL_INCREASINGBUTTON,
							ATTR_DIMMED, !sortEnable);
			SetCtrlAttribute (panelHandle, PANEL_CASECHECKBOX,
							ATTR_DIMMED, !sortEnable);
				
			break;
		}
	return 0;
}

int CVICALLBACK SetIncreaseOrDecrease_Callback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int isSelected;
	switch (event)
		{
		case EVENT_COMMIT:
			SetCtrlVal (panel, control, 1);
			if (control == PANEL_INCREASINGBUTTON)
				SetCtrlVal (panelHandle, PANEL_DECREASINGBUTTON, 0);
			else
				SetCtrlVal (panelHandle, PANEL_INCREASINGBUTTON, 0);
			

			break;
		}
	return 0;
}
