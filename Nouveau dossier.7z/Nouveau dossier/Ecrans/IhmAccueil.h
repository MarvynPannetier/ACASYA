/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                            1
#define  PANEL_MESSAGES                   2       /* control type: textBox, callback function: (none) */
#define  PANEL_BOUTON_REINIT              3       /* control type: command, callback function: Reinitialisation */
#define  PANEL_COMMANDBUTTON              4       /* control type: command, callback function: BtnQuitter */
#define  PANEL_TEXTMSG                    5       /* control type: textMsg, callback function: (none) */
#define  PANEL_TEXTMSG_2                  6       /* control type: textMsg, callback function: (none) */
#define  PANEL_PICTURE                    7       /* control type: picture, callback function: (none) */
#define  PANEL_TITLE                      8       /* control type: textMsg, callback function: (none) */


     /* Control Arrays: */

          /* (no control arrays in the resource file) */


     /* Menu Bars, Menus, and Menu Items: */

#define  MENU                             1
#define  MENU_MODE                        2       /* callback function: ModeFonctionnement */
#define  MENU_MODE_MODE_RUN               3       /* callback function: ModeFonctionnement */
#define  MENU_MODE_QUITTER                4       /* callback function: QuitterAccueil */


     /* Callback Prototypes: */

int  CVICALLBACK BtnQuitter(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
void CVICALLBACK ModeFonctionnement(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK QuitterAccueil(int menubar, int menuItem, void *callbackData, int panel);
int  CVICALLBACK Reinitialisation(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif
