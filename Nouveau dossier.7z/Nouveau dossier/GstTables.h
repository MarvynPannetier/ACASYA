// DEBUT TABLE
//******************************************************************************
// PRO: BANC DE TEST LSE
// PRG: GstTables.h
// VER: Version I00A00A du 09/08/2010
// AUT: C. BERENGER / MICROTEC
//
// ROL: Programme de gestion des tables de vitesse et pression
//
// HST: Version I00A00A du 09/08/2010 / C. BERENGER MICROTEC / Cr�ation
//******************************************************************************
//
//*************************************************************************** 
// FIN TABLE
#ifndef LIB_GST_TABLES
 #define LIB_GST_TABLES

//***************************************************************************
// inclusions
//***************************************************************************

// Librairies standards

// Librairie FOURNISSEUR

// Librairie MICROTEC

// Librairie sp�cifiques � l'application

//***************************************************************************
// D�finition de constantes
//***************************************************************************
#define bINSERT_HERE	0
#define bINSERT_BEFORE	1
#define bINSERT_AFTER  	2
#define bINSERT_END		3

#define iERROR_SUPPR	100

//***************************************************************************
// D�finition de types et structures
//***************************************************************************

//******************************************************************************
// Fonctions externes au source
//******************************************************************************

//****************************************************************************** 
//	- int iPanel			: Handle du panel
//	  int iControl			: Num�ro de contr�le de la table
//	  int iTypeTable		: Type de table s�lectionn�e (vitesse ou pression)
//	  stTabVitesse *ptstTabVitesse	: Pointeur vers le tableau des vitesses
//	  stTabPression *ptstTabPression: POinteur vers le tableau des pressions 
//	  char *sMsgErr			: Message d'erreur
//
//  - Mise � jour des donn�es (vitesse ou pression) � partir de la table affich�e � l'�cran
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
int GstTablesMajTableau(int iPanel, int iControl, int iTypeTable, 
						stTabVitesse *ptstTabVitesse, stTabPression *ptstTabPression,
						char *sMsgErr);
						
//****************************************************************************** 
//	- int iPanel			: Handle du panel
//	  int iControl			: Num�ro de contr�le de la table
//	  int *ptiNumRow		: Num�ro de ligne dans la table
//	  int *ptiNumCol		: Num�ro de colonne dans la table
//	  int *ptiPosMouseX		: Coordonn�es du pointeur de la souris en X
//	  int *ptiPosMouseY		: Coordonn�es du pointeur de la souris en Y
//	  BOOL *ptbCoordValid	: 1=Coordonn�es valides, sinon 0
//
//  - Retourne les coordonn�es (ligne/colonne de la table) par rapport au curseur de la souris
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
int GstTablesGetRowColFromMouse(int iPanel, int iControl, int *ptiNumRow, int *ptiNumCol, 
								int *ptiPosMouseX, int *ptiPosMouseY, BOOL *ptbCoordValid);

//****************************************************************************** 
//	- int iPanel			: Handle du panel
//	  int iControl			: Num�ro de contr�le de la table
//	  int iNumRowMouse		: Num�ro de ligne dans la table ou se trouve le pointeur de la souris
//	  int iNumColMouse		: Num�ro de colonne dans la table ou se trouve le pointeur de la souris
//	  int *ptiHeightSelect  : Hauteur de la s�lection (en lignes)
//	  int *ptiWidthSelect   : Largeur de la s�lection (en colonnes)
//	  int *ptiLeftSelect	: Position gauche de la s�lection (1,...)
//	  int *ptiTopSelect		: Position haute de la s�lection (1,...)
//	  BOOL *ptbValid		: 1: S�lection valide, sinon invalide
//
//  - Retourne la taille de la zone de s�lection
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
int GstTablesGstZoneSelect(int iPanel, int iControl, int iNumRowMouse, int iNumColMouse,
							int *ptiHeightSelect, int *ptiWidthSelect, int *ptiLeftSelect,
							int *ptiTopSelect, BOOL *ptbValid);

//****************************************************************************** 
//	- int iPanel			: Handle du panel
//	  int iControl			: Num�ro de contr�le de la table
//	  int iOneBaseRowIndex	: Num�ro de la ligne � partir de laquelle il faut rajouter des lignes 
//	  double dLimMinTpsSpeed: Dur�e par d�faut des vitesses
//	  double dLimMinTpsPress: Temps par d�faut des pressions
// 	  int iNbMaxRows		: Nombre maximal de lignes de la table
//	  int iNbRowsToAdd		: Nombre de lignes � rajouter
//	  int iOptionbInsert	: Option d'insertion des lignes:
//								- A partir de la ligne s�lectionn�e
//								- Avant la ligne s�lectionn�e
//								- Apr�s la ligne ss�lectionn�e
//								- A la fin de la table,
//	  int iTypeTable		: Type de table s�lectionn�e (vitesse ou pression)
//	  stTabVitesse *ptstTabVitesse	: Pointeur vers le tableau des vitesses
//	  stTabPression *ptstTabPression: POinteur vers le tableau des pressions 
//	  int *ptiNbRowsAdded	: Nombre de lignes ajout�es
//	  char *sMsgErr			: Message d'erreur
//
//  - Ajout d'une ou plusieurs lignes dans une table
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
int GstTablesAddRows(	int iPanel, int iControl, int iOneBaseRowIndex, 
						double dLimMinTpsSpeed, double dLimMinTpsPress,
						int iNbMaxRows, int iNbRowsToAdd, int iOptionbInsert,
						int iTypeTable, stTabVitesse *ptstTabVitesse, 
						stTabPression *ptstTabPression, int *ptiNbRowsAdded,
						char *sMsgErr);
						
//****************************************************************************** 
//	- int iPanel			: Handle du panel
//	  int iControl			: Num�ro de contr�le de la table
//	  int iHeightSelect  	: Hauteur de la s�lection (en lignes)
//	  int iWidthSelect  	: Largeur de la s�lection (en colonnes)
//	  int iLeftSelect		: Position gauche de la s�lection (1,...)
//	  int iTopSelect		: Position haute de la s�lection (1,...)
//	  int iTypeTable		: Type de table s�lectionn�e (vitesse ou pression)
//	  stTabVitesse *ptstTabVitesse	: Pointeur vers le tableau des vitesses
//	  stTabPression *ptstTabPression: POinteur vers le tableau des pressions 
//	  char *sMsgErr			:Message d'erreur
//
//  - Suppression d'une s�lection
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
int GstTablesSupprSelect(int iPanel, int iControl, int iHeightSelect, int iWidthSelect,
						int iLeftSelect, int iTopSelect,int iTypeTable, 
						stTabVitesse *ptstTabVitesse, stTabPression *ptstTabPression,
						char *sMsgErr);

//****************************************************************************** 
//	- int iPanel			: Handle du panel
//	  int iControl			: Num�ro de contr�le de la table
//	  Rect rSelectSource	: S�lection source
//	  Rect rSelectDest		: S�lection de destination
//	  int iTypeTable		: Type de table s�lectionn�e (vitesse ou pression)
//	  int iUnitVitesse		: Unit� de vitesse
//	  int iUnitPression		: Unit� de pression
//	  stTabVitesse *ptstTabVitesse	: Pointeur vers le tableau des vitesses
//	  stTabPression *ptstTabPression: POinteur vers le tableau des pressions 
//
//  - Colle une s�lection
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
int GstTablesColler(int iPanel, int iControl, Rect rSelectSource, Rect rSelectDest,
					int iTypeTable, int iUnitVitesse, int iUnitPression,
					stTabVitesse *ptstTabVitesse, stTabPression *ptstTabPression);

//****************************************************************************** 
//	- int iPanel			: Handle du panel
//	  int iIdTabVitesse		: Num�ro de contr�le de la table de vitesse
//	  int iIdTabPress		: Num�ro de contr�le de la table de pression
//	  int iUnitVitesse		: Unit� de vitesse
//	  int iUnitPress		: Unit� de pression
//	  stConfig *ptStConfig	: Pointeur sur la structure des param�tres
//
//  - // Fixe les limites des tableaux de pression et de vitesse 
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
int GstTablesSetLim(int iPanel, int iIdTabVitesse, int iIdTabPress, int iUnitVitesse,
					int iUnitPress, stConfig *ptStConfig);


int GstDataGrid(int iPanel, int iPopupMenuHandle, int iStatusPanel, int iPopupAdd, 
				int iControl, int iTypeGrid, int iColorSpeed, int iColorPress, stConfig *ptstConfig, 
				stTabVitesse *ptstTabVitesse, stTabPression *ptstTabPression, 
				int *ptiPanelStatusDisplayed, int *ptiAffMsg, char *sPathConfigFile);
//******************************************************************************
#endif
