// DEBUT TABLE
//******************************************************************************
// PRO: BANC DE TEST LSE
// PRG: Modes.c
// VER: Version I00A00M du 01/02/2012
// AUT: C. BERENGER / MICROTEC
//
// ROL: Programme de gestion de l'�cran du mode Automatique/Manuel
//
// HST: Version I00A00A du 14/09/2010 / MP. LACROIX MICROTEC / Cr�ation
// HST: Version I00A00B du 15/11/2010 / C.BERENGER / 
//		- Passage de la r�solution moteur � 0.1 tours/min
//		- Modification de l'affichage du graphique en mode manuel
//		- Correction du probl�me de gestion des limites apr�s le chargement
//	      d'un cycle dans une autre unit� de vitesse ou de pression que celle 
//	      utilis�e par d�faut.
// HST: Version I00A00C du 30/11/2010 / C. BERENGER MICROTEC / 
//	    - Ajout d'une gestion par watchdog pour couper le moteur et la pression 
//	      en cas de probl�me de blocage de l'application.
// HST: Version I00A00D du 04/01/2011 / C. BERENGER MICROTEC / 
//	    - Ajout de quelques Mutex
//		- Suppresison de l'utilisation du fichier "MessageIhm.ini", et remplacement par des constantes
//		- Recompilation du programme avec la version 8.6.0f5 du DAQmx (identique � la version install�e sur le banc du client)
//		- Passage de la variable "GptstConfig" en mode prot�g� dans le fichier "Modes.c"
// HST: Version I00A00E du 15/01/2011 / C. BERENGER MICROTEC / 
//		- Modification du nombre de r��ssais RS232 => Passage de 1 � 3 r��ssais
// HST: Version I00A00F (20/01/2011):
//		- Modification du nombre de r��ssais de communication RS232 en cas de probl�me
//		- Diminution du timeout RS232 de 2s � 0.3s
//
// HST: Version I00A00G (24/01/2011):
//		- Utilisation du DAQmx 9.02
//		- Suppression de l'attente entre l'�criture et la lecture sur le port RS232 (pilotage du moteur)
//
// HST: Version I00A00H (26/01/2011):
//		- Utilisation du DAQmx 9.02
//		- Simplification de l'application (suppression de mutex, AsyncTimer pour les acquisitions)
//		   => Report des mutex dans les librairies Variateur et USB6008.
//
// HST: Version I00A00I (26/06/2011):
//		- Filtrage des bruits de relectures de la pression
//
// HST: Version I00A00J (07/07/2011):
//		- Ajout d'un message d'erreur si d�tection de vibrations
// HST: Version I00A00M (01/02/2012):
//		- Modifications dans la fonction "ProgRampeVariateur" pour limiter les 
//		  dur�es de rampes de vitesse � 0.4s au minimum.
//		  La prise en compte de dur�es inf�rieures provoquait des pics (overshoot) 
//		  dans les rampes de vitesse.
//		- Modification dans la Callback "Configuration":
//******************************************************************************
//
//******************************************************************************
// FIN TABLE

//******************************************************************************
// Inclusions
//******************************************************************************

// Librairies standards 
#include <windows.h>
#include "LseNet.h"
#include <utility.h>
#include <ansi_c.h>
#include <userint.h>
#include <cvirte.h>

// Librairies FOURNISSEUR

// Librairies MICROTEC
#include "ZoneMessage.h"
//#include "MessageIhm.h"
#include "ResultTextFile.h"

// Librairies sp�cifiques � l'application
#include "IhmModes.h"
#include "GstFiles.h"
#include "Modes.h"
#include "GstTables.h"
#include "IhmAccueil.h"
#include "GstGraphe.h"
#include "Usb6008.h"
#include "Variateur.h"
#include "IhmSimul.h"
#include "Simulation.h"
#include "Mutex.h"
#include "asynctmr.h"

#include "API.h"

//******************************************************************************
// D�finition de constantes
//******************************************************************************
//----- Options -------
//#define bSIMULATION
#define bDISPLAY_ENTIRE_RESULT  0
//---------------------

#define sNOM_IHM_MODES				"IhmModes.uir"

// Couleur des courbes de consignes
#define iCOUL_CONS_VITESSE			VAL_DK_RED
#define iCOUL_CONS_PRESSION			VAL_DK_BLUE
// Couleur des courbes de relectures
#define iCOUL_VITESSE				0x00FF0000 // 0x00RRVVBB
#define iCOUL_PRESSION				0x000000FF // 0x00RRVVBB

#define iEN_COURS					1
#define iARRET						0

#define sEXT_FICHIERS				"csv"
#define sREP_CONFIGURATIONS			"Cycles"
#define sREP_RESSULTATS				"Results"

#define sNOM_LIBRAIRIE 				"Modes"
#define sANUM_DLL			        "API.dll"   
#define sANUM_CFG			        "Anum.cfg"
#define dRUN			        	4
#define dSTOP			        	5  

// Format de dur�e d'essai �coul�e
#define sFORMAT_DUREE_ECOULEE		"%dh%02dmn%02ds"

#define iFORMAT_SPEED_RESULT		"%d;%.02f;%d;%d;%.03f;%.03f;"
#define iFORMAT_PRESS_RESULT		"<-->;%d;%.02f;%d;%d;%.03f;%.03f;"

#define iGACHE_FERMEE				0
#define iGACHE_OUVERTE				1

#define dVIT_ABS_START_TEST			0.5
#define dMAX_PRESS_START_TEST		0.4  // 0.4 bars max pour autoriser le depart essai

#define dPI							3.14159
#define dGRAVITE					9.81

#define lTIMEOUT_MUTEX_PANEL		20000
#define iNB_REESSAIS_DIAL_VARIAT	6

//******************************************************************************
// D�finition de types et structures
//******************************************************************************



//******************************************************************************
// Variables globales
//******************************************************************************
// Fonction de retour du panel
void *GFonctionRetourIhm;

int  GiThreadPoolHandleAcquisitions;
int  GiThreadAcquisitions;
int  GiThreadPoolHandleGestionVitesse;
int  GiThreadCycleVitesse;
int  GiThreadPoolHandleGestionPression;
int  GiThreadCyclePression;
int  GiThreadPoolHandleGestionSecurite;
int  GiThreadGestionSecurite;
int  GiThreadCycleRun;
int  GiThreadCycleAnum;  
BOOL GbThreadPoolActive	= 0;

BOOL GbAnumInit = 0;
CheckLse_LSE instanceLseNetModes; 
CheckLse_LFComand *TabAnumCmd;

/*
HINSTANCE hDLL=NULL;                // Instance of DLL
TAPI      myFUnc=0;                  // Pointeur on API function (described in API.h)
struct    TAPILFRF sAPILFRF;
unsigned char cAPI;
char aCommand[128];
 */
// Tableau contenant la liste des vitesses
stTabVitesse  GstTabVitesse;
// Tableau contenant la liste des pressions
stTabPression GstTabPression;
// Pointeur vers la structure contenant lesparam�tres de configuration
DefineThreadSafeScalarVar(stConfig, GptstConfig, 			10);

char GsPathResult[500];

char GsMsgErr[3000]="";
char GsPathConfigFile[MAX_PATHNAME_LEN];
char GsPathApplication[MAX_PATHNAME_LEN];


volatile int GiPanel			= 0; 
volatile int GiPanelPere		= 0;
volatile int GiPopupAdd			= 0;
volatile int GiStatusPanel		= 0;
volatile int GiEvtRetourIhm;
volatile int GiPopupMenuHandle	= 0;


DefineThreadSafeScalarVar(int, GiAffMsg, 					0);
DefineThreadSafeScalarVar(int, GiUnitVitesse, 				0);

DefineThreadSafeScalarVar(int, GiUnitPression, 				0);


DefineThreadSafeScalarVar(int, GiSelectionHandlePression, 	0);
DefineThreadSafeScalarVar(int, GiSelectionHandle, 			0);
DefineThreadSafeScalarVar(int, GiControlGrapheSelection, 	0);  

DefineThreadSafeScalarVar(int, GiPanelStatusDisplayed, 		0);

DefineThreadSafeScalarVar(int, GiMode, 						0);  

DefineThreadSafeScalarVar(int, GbQuitter, 					0);  
DefineThreadSafeScalarVar(int, GiEtat, 						0);  
DefineThreadSafeScalarVar(int, GiHandleFileResult, 			0);  

DefineThreadSafeScalarVar(int, GiErrUsb6008, 				0);
DefineThreadSafeScalarVar(int, GiErrVaria,   				0);

DefineThreadSafeScalarVar(int, GiIndexStepVitesse,  		0);
DefineThreadSafeScalarVar(int, GiIndexCycleVitesse, 		0);
DefineThreadSafeScalarVar(float, GfVitesse, 				0);
DefineThreadSafeScalarVar(int, GbEndCycleVitesse, 			0);
DefineThreadSafeScalarVar(int, GbRazTimeVit, 				0);
DefineThreadSafeScalarVar(int, GiDisableMajGrapheVitesse, 	0);
DefineThreadSafeScalarVar(int, GiStartCycleVitesse, 		0);
DefineThreadSafeScalarVar(int, GiSelectionHandleVitesse, 	0);
DefineThreadSafeScalarVar(double, GdVitesseAProg, 			0);
DefineThreadSafeScalarVar(double, GdDurEcoulEssaiSpeed, 	0);
DefineThreadSafeScalarVar(int, GiTimeDepartEssaiSpeed, 		0);


DefineThreadSafeScalarVar(double, GdPression, 				0);
DefineThreadSafeScalarVar(int, 	GiIndexStepPression, 		0);
DefineThreadSafeScalarVar(int, GiIndexCyclePression, 		0);
DefineThreadSafeScalarVar(int, GbRazTimePress, 				0);
DefineThreadSafeScalarVar(int, GiDisableMajGraphePression, 	0);
DefineThreadSafeScalarVar(int, GiStartVitPress, 			0);
DefineThreadSafeScalarVar(int, GiStartCyclePression, 		0);
DefineThreadSafeScalarVar(double, GdPressionAProg, 			0);
DefineThreadSafeScalarVar(double, GiTimeDepartEssaiPress, 	0);
DefineThreadSafeScalarVar(double, GdDurEcoulEssaiPress, 	0);
DefineThreadSafeScalarVar(int, GbEndCyclePression, 			0);
DefineThreadSafeScalarVar(int, GbGacheActive, 				0);


DefineThreadSafeScalarVar(int, GiStartCycleRun, 		0);
DefineThreadSafeScalarVar(int, GiStartCycleAnum, 		0);
//******************************************************************************
// Fonctions internes au source
//******************************************************************************
void ModesAddMessageZM(char *sMsg);
static int CVICALLBACK ThreadCycleVitesse (void *functionData);
static int CVICALLBACK ThreadCyclePression (void *functionData);
static int CVICALLBACK ThreadGestionSecurite (void *functionData);
static int CVICALLBACK ThreadCycleRun (void *functionData);
static int CVICALLBACK ThreadCycleAnum (void *functionData);   
//static int CVICALLBACK ThreadAcquisitions (void *functionData);
int CVICALLBACK ThreadAcquisitions (int reserved, int theTimerId, int event,
                                 void *callbackData, int eventData1,
                                 int eventData2);
                                 
static int CVICALLBACK ThreadAffMsg (void *functionData);
int SetUnitVitesse(int iPanel, int iControl);
int SetUnitPression(int iPanel, int iControl);

//******************************************************************************
// Corps des fonctions et proc�dures internes au source
//******************************************************************************
#define CHECK_ERROR(Error, Title, sMsgErr)					\
{															\
	if (Error != 0){										\
		if(GetGiAffMsg() == 0){								\
			strcpy(sTitle, Title);							\
			strcpy(GsMsgErr, sMsgErr);						\
			SetGiStartCycleVitesse(0);						\
			SetGiStartCyclePression(0);						\
			SetGiStartCycleRun(0);							\
			SetGiStartCycleAnum(0);							\
			GstIhmCycles(GiPanel,GetGiStartVitPress(),  GetGiStartCycleVitesse(), GetGiStartCyclePression());	\
			SetGiAffMsg(1);									\
			SetPanelAttribute (GiPanel, ATTR_VISIBLE, 0);	\
			if(GetGiPanelStatusDisplayed()==0){				\
				DisplayPanel (GiStatusPanel);				\
				SetGiPanelStatusDisplayed(1);				\
			}												\
			ResetTextBox (GiStatusPanel, PANEL_STAT_MESSAGES, sMsgErr);	\
		}													\
	}														\
}


#define CHECK_TAB_INDEX(sId, iIndex, iNdexMin, iIndexMax) 	\
{															\
	if ((iIndex < iNdexMin) || (iIndex > iIndexMax))		\
		MessagePopup(sId, "Index Error");					\
}

#define CHECK_VAL(sIndex, dVal, dValMin, dValMax)			\
{															\
	if ((dVal < dValMin) || (dVal > dValMax))				\
		MessagePopup(sIndex, "Val Error");					\
}


void UpDemandeAttenteJeton (int iLine, HANDLE pthLock, long lTimeout)
{
	int iStatus;

	iStatus = DemandeAttenteJeton(pthLock, lTimeout);
}

//----------- Modif du 30/11/2010 par C.BERENGER ---- DEBUT ---------
// DEBUT ALGO
//***************************************************************************
// void ModesGetEtatCycles(int *iVitesse, int *iPression, int *iDurEssVit, int *iDurEssPress)
//***************************************************************************
//	- int *iVitesse		= Etat du cycle de vitesse
//	  int *iPression	= Etat du cycle de pression
//	  int *iDurEssVit	= Dur�e de l'essai de vitesse
//	  int *iDurEssPress	= Dur�e de l'essai de pression 
//
//  - Retourne l'�tat des cycles de vitesse ou pression
//
//  - Aucun
//***************************************************************************
// FIN ALGO
void ModesGetEtatCycles(int *iVitesse, int *iPression, int *iDurEssVit, int *iDurEssPress)
{
	if(GbThreadPoolActive){
		*iVitesse 		= GetGiStartCycleVitesse();
		*iPression 		= GetGiStartCyclePression();
	
		*iDurEssVit		= GetGdDurEcoulEssaiSpeed();
		*iDurEssPress	= GetGdDurEcoulEssaiPress();
	}
	else{
			*iVitesse 		= 0;
			*iPression 		= 0;
	
			*iDurEssVit		= 0.0;
			*iDurEssPress	= 0.0;
		}
}
//----------- Modif du 30/11/2010 par C.BERENGER ---- FIN ---------

// DEBUT ALGO
//***************************************************************************
// void DisplayCurrentCycle(int iPanel, char *sPathConfigFile) 
//***************************************************************************
//  - int iPanel				: Handle du panel
//	  char *sPathConfigFile		: Chemin complet vers le fichier de configuration
//
//  - Affichage du cycle en cours dans le menu
//
//  - Cha�ne de caract�res du temps en heures/minutes/secondes
//***************************************************************************
// FIN ALGO
void DisplayCurrentCycle(int iPanel, char *sPathConfigFile)
{
char sPathToPrint[MAX_PATHNAME_LEN*2];	
	
	sprintf(sPathToPrint, "Current Cycle = \"%s\"", sPathConfigFile);
	SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_CONFIG_SEE_CURR_CYCLE, ATTR_ITEM_NAME, sPathToPrint);
}

// DEBUT ALGO
//****************************************************************************** 
//void AffStatusPanel(int iPanel, int iStatusPanel, char *sTitle, char *sMsg,
//					int *ptiPanelStatDisplayed, int *ptiAffMsg)
//****************************************************************************** 
//	- int iPanel		: Handle du panel d'essai
//	  int iStatusPanel	: Handle du panel de status
//	  char *sTitle		: Titre 
//	  char *sMsg		: Message � afficher
//	  int *ptiPanelStatDisplayed	: 1=Ecran d�j� affich�, sinon 0
//	  int *ptiAffMsg	: 1=Message affich�, sinon, 0
//
//  - Gestion des fichiers de donn�es (vitesse et pression)
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
// FIN ALGO
void AffStatusPanel(int iPanel, int iStatusPanel, int iLevel, char *sTitle, char *sMsg,
					int *ptiPanelStatDisplayed, int *ptiAffMsg)
{	
int iStatus;
	
	if(*ptiPanelStatDisplayed == 0){
		// On cache l'�cran principal
		SetPanelAttribute (iPanel, ATTR_VISIBLE, 0); 
		DisplayPanel(iStatusPanel);
		//Effacement de la zone de message de l'�cran de status
		ResetTextBox (iStatusPanel, PANEL_STAT_MESSAGES, sTitle);
		
		// Modification du 07/07/2011 par CB ------ DEBUT --------------
		switch (iLevel)	{
			case iLEVEL_WARNING:
				iStatus = SetCtrlAttribute (iStatusPanel, PANEL_STAT_MESSAGES, ATTR_TEXT_BOLD, 1);
				iStatus = SetCtrlAttribute (iStatusPanel, PANEL_STAT_MESSAGES, ATTR_TEXT_BGCOLOR, VAL_RED);
				iStatus = SetCtrlAttribute (iStatusPanel, PANEL_STAT_MESSAGES, ATTR_TEXT_COLOR,  VAL_WHITE);
			break;
			default:
			case iLEVEL_MSG:
				SetCtrlAttribute (iStatusPanel, PANEL_STAT_MESSAGES, ATTR_FRAME_COLOR, VAL_WHITE);			
				SetCtrlAttribute (iStatusPanel, PANEL_STAT_MESSAGES, ATTR_TEXT_BOLD, 0);
				SetCtrlAttribute (iStatusPanel, PANEL_STAT_MESSAGES, ATTR_TEXT_BGCOLOR, VAL_WHITE);
				SetCtrlAttribute (iStatusPanel, PANEL_STAT_MESSAGES, ATTR_TEXT_COLOR,  VAL_BLACK);
			break;
			
		}				
		// Modification du 07/07/2011 par CB ------ FIN --------------
		
		InsertTextBoxLine(iStatusPanel, PANEL_STAT_MESSAGES, -1, sMsg);
		*ptiPanelStatDisplayed = 1;
		*ptiAffMsg = 0;
	}
}

// DEBUT ALGO
//***************************************************************************
// void ModesAddMessageZM(char *sMsg)
//***************************************************************************
//  - sMsg: message
//
//  - Fonction ajoutant un message dans la Zone de Message
//
//  - Aucun 
//***************************************************************************
// FIN ALGO
void ModesAddMessageZM(char *sMsg)
{
 int iNbLignes;
 char *ptMgs;
 char *ptMgsCopie;
 char sCopieMsg[MAX_PATHNAME_LEN*2];
	
	strcpy(sCopieMsg,sMsg);
	ptMgsCopie=sCopieMsg;
	// Ajout du message dans la ZM
	while ((ptMgs=strstr (ptMgsCopie,"\\n"))!=NULL) {
		if(ptMgs != NULL)
			*ptMgs='\0';
		ptMgs++;
		if(ptMgs != NULL)
			*ptMgs='\0';
		ptMgs++;
		InsertTextBoxLine (GiPanel, PANEL_MODE_MESSAGES_MODE,-1,ptMgsCopie);  
		if(ptMgs != NULL)
			ptMgsCopie=ptMgs;
	}
	if (ptMgsCopie!=NULL) 
		InsertTextBoxLine (GiPanel,PANEL_MODE_MESSAGES_MODE,-1,ptMgsCopie);
	GetNumTextBoxLines (GiPanel, PANEL_MODE_MESSAGES_MODE, &iNbLignes);
	
	SetCtrlAttribute (GiPanel, PANEL_MODE_MESSAGES_MODE, ATTR_FIRST_VISIBLE_LINE, iNbLignes);
	// A chaque message ajout� on v�rifie s'il faut purger la ZM
	ZoneMessageSaturee(GiPanel,
					   PANEL_MODE_MESSAGES_MODE, 
					   sNOM_LIBRAIRIE, 
					   0);
}

// DEBUT ALGO
//****************************************************************************** 
//int SetLimSaisiesMan(int iPanel, int iIdVitesse, int iIdPress, int iIdTpsVitesse,
//						int iIdTpsPress, int iUnitVitesse, int iUnitPress, stConfig *ptStConfig)
//****************************************************************************** 
//	- int iPanel			: Handle du panel
//	  int iIdVitesse		: Num�ro de contr�le de la saisie de vitesse
//	  int iIdPress		 	: Num�ro de contr�le de la saisie de pression
//	  int iIdTpsVitesse		: Num�ro de contr�le de la saisie du temps pour la vitesse
//	  int iIdTpsPress		: Num�ro de contr�le de la saisie de temps pour la pression
//	  int iUnitVitesse		: Unit� de vitesse
//	  int iUnitPress		: Unit� de pression
//	  stConfig *ptStConfig	: Pointeur sur la structure des param�tres
//
//  - Fixe les limites des saisies dans le mode manuel
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
// FIN ALGO
int SetLimSaisiesMan(int iPanel, int iIdVitesse, int iIdPress, int iIdTpsVitesse,
						int iIdTpsPress, int iUnitVitesse, int iUnitPress, stConfig *ptStConfig)
{ 
	// Fixe les min/max du tableau des vitesses
	switch(iUnitVitesse){
		case iUNIT_KM_H:
			SetCtrlAttribute (iPanel, iIdVitesse, ATTR_MIN_VALUE, ptStConfig->dLimMinKmH);
			SetCtrlAttribute (iPanel, iIdVitesse, ATTR_MAX_VALUE, ptStConfig->dLimMaxKmH);
		break;
		case iUNIT_G:
			SetCtrlAttribute (iPanel, iIdVitesse, ATTR_MIN_VALUE, ptStConfig->dLimMinG);
			SetCtrlAttribute (iPanel, iIdVitesse, ATTR_MAX_VALUE, ptStConfig->dLimMaxG);
		break;
		case iUNIT_TRS_MIN:
			SetCtrlAttribute (iPanel, iIdVitesse, ATTR_MIN_VALUE, ptStConfig->dLimMinTrsMin);
			SetCtrlAttribute (iPanel, iIdVitesse, ATTR_MAX_VALUE, ptStConfig->dLimMaxTrsMin);
		break;
	}
	// Limites de la dur�e de vitesse
	SetCtrlAttribute (iPanel, iIdTpsVitesse, ATTR_MIN_VALUE, ptStConfig->dLimMinTpsSpeed);
	SetCtrlAttribute (iPanel, iIdTpsVitesse, ATTR_MAX_VALUE, ptStConfig->dLimMaxTpsSpeed);

	
	// Fixe les min/max du tableau des pressions
	switch(iUnitPress){
		case iUNIT_KPA:
			SetCtrlAttribute (iPanel, iIdPress, ATTR_MIN_VALUE, ptStConfig->dLimMinKpa);
			SetCtrlAttribute (iPanel, iIdPress, ATTR_MAX_VALUE, ptStConfig->dLimMaxKpa);
		break;
		case iUNIT_BAR:
			SetCtrlAttribute (iPanel, iIdPress, ATTR_MIN_VALUE, ptStConfig->dLimMinBar);
			SetCtrlAttribute (iPanel, iIdPress, ATTR_MAX_VALUE, ptStConfig->dLimMaxBar);
		break;
		case iUNIT_MBAR:
			SetCtrlAttribute (iPanel, iIdPress, ATTR_MIN_VALUE, ptStConfig->dLimMinMbar);
			SetCtrlAttribute (iPanel, iIdPress, ATTR_MAX_VALUE, ptStConfig->dLimMaxMbar);
		break;
		case iUNIT_PSI:
			SetCtrlAttribute (iPanel, iIdPress, ATTR_MIN_VALUE, ptStConfig->dLimMinPsi);
			SetCtrlAttribute (iPanel, iIdPress, ATTR_MAX_VALUE, ptStConfig->dLimMaxPsi);
		break;
	}
	// Limites de la dur�e de pression
	SetCtrlAttribute (iPanel, iIdTpsPress, ATTR_MIN_VALUE, ptStConfig->dLimMinTpsPress);
	SetCtrlAttribute (iPanel, iIdTpsPress, ATTR_MAX_VALUE, ptStConfig->dLimMaxTpsPress);

	return 0; // OK
}

// DEBUT ALGO
//***************************************************************************
// void ModeInitSafeVar(void)
//***************************************************************************
//  - Aucun  
//
//  - D�saloue la m�moire occup�e par les variables prot�g�es
//
//  - Aucun
//***************************************************************************
// FIN ALGO
void ModeUninitSafeVar(void)
{
	UninitializeGbEndCycleVitesse ();
	UninitializeGfVitesse (); 
	UninitializeGdPression (); 
	UninitializeGiErrUsb6008();
	UninitializeGiErrVaria();	
	UninitializeGiPanelStatusDisplayed();
	UninitializeGiIndexStepVitesse();
	UninitializeGiIndexCycleVitesse();
	UninitializeGiIndexStepPression();
	UninitializeGiIndexCyclePression();
	UninitializeGbRazTimeVit();
	UninitializeGbRazTimePress();
	UninitializeGiDisableMajGrapheVitesse();
	UninitializeGiDisableMajGraphePression();
	UninitializeGiStartCycleVitesse();
	UninitializeGiStartVitPress();
	UninitializeGiStartCyclePression();
	UninitializeGdPressionAProg();
	UninitializeGiTimeDepartEssaiPress();
	UninitializeGiSelectionHandleVitesse();
	UninitializeGdDurEcoulEssaiPress();
	UninitializeGbEndCyclePression();
	UninitializeGbGacheActive();
	UninitializeGdVitesseAProg();
	UninitializeGdDurEcoulEssaiSpeed();
	UninitializeGiTimeDepartEssaiSpeed();
	UninitializeGiHandleFileResult();
	UninitializeGiEtat();
	UninitializeGbQuitter();
	UninitializeGiSelectionHandlePression();	
	UninitializeGiSelectionHandle();
	UninitializeGiControlGrapheSelection();
	UninitializeGiMode();
	UninitializeGiUnitVitesse();
	UninitializeGiUnitPression(); 
	UninitializeGiAffMsg();
	UninitializeGptstConfig(); 
	UninitializeGiStartCycleRun();
	UninitializeGiStartCycleAnum();
}

// DEBUT ALGO
//***************************************************************************
// void ModeInitSafeVar(void)
//***************************************************************************
//  - Aucun  
//
//  - Initialisation des pointeurs vers les variables prot�g�es
//
//  - Aucun
//***************************************************************************
// FIN ALGO
void ModeInitSafeVar(void)
{
	InitializeGiUnitVitesse();
	InitializeGiUnitPression(); 
	InitializeGbEndCycleVitesse ();
	InitializeGfVitesse (); 
	InitializeGdPression ();
	InitializeGiErrUsb6008();
	InitializeGiErrVaria();
	InitializeGiPanelStatusDisplayed();
	InitializeGiIndexStepVitesse();
	InitializeGiIndexCycleVitesse();
	InitializeGiIndexStepPression();
	InitializeGiIndexCyclePression();
	InitializeGbRazTimeVit();
	InitializeGbRazTimePress();
	InitializeGiDisableMajGrapheVitesse();
	InitializeGiDisableMajGraphePression();
	InitializeGiStartCycleVitesse();
	InitializeGiStartVitPress();
	InitializeGiStartCyclePression();
	InitializeGdPressionAProg();
	InitializeGiTimeDepartEssaiPress();
	InitializeGiSelectionHandleVitesse();
	InitializeGdDurEcoulEssaiPress();
	InitializeGbEndCyclePression();
	InitializeGbGacheActive();
	InitializeGdVitesseAProg();
	InitializeGdDurEcoulEssaiSpeed();
	InitializeGiTimeDepartEssaiSpeed();
	InitializeGiHandleFileResult();
	InitializeGiEtat();
	InitializeGbQuitter();
	InitializeGiSelectionHandlePression();
	InitializeGiSelectionHandle();
	InitializeGiControlGrapheSelection();
	InitializeGiMode();
	InitializeGiAffMsg();
	InitializeGptstConfig();   
	InitializeGiStartCycleRun();
	InitializeGiStartCycleAnum();
	
	SetGiUnitVitesse(0);
	SetGiUnitPression(0);
	SetGiHandleFileResult(-1); 
}

// DEBUT ALGO
//***************************************************************************
//int ModesLoadPanel(void *FonctionRetourIhm,
//					char *sSousRepertoireEcran,
//					int iPanelPere,
//					int iUnitVitesse,
//					int iUnitPression)
//***************************************************************************
//    FonctionRetourIhm			: Fonction appel�e quand on quitte l'Ihm
//    sSousRepertoireEcran		: Sous r�pertoire des �crans
//    iPanelPere				: Handle du panel pere
//	  stConfig, *ptStConfig		: Pointeur vers les param�tres de configuration
//	  iUnitVitesse				: Unit� de vitesse choisie au lancment de l'application
//	  iUnitPression				: Unit� de pression choisie au lancment de l'application
//
//  - Chargement du panel
//
//  - 1 si probl�me d�tect�, 0 sinon
//***************************************************************************
// FIN ALGO
int ModesLoadPanel(	void *FonctionRetourIhm,
					char *sSousRepertoireEcran,
					int iPanelPere,
					stConfig *ptStConfig,
					int iUnitVitesse,
					int iUnitPression)
{
static char sFileNameEcran[MAX_PATHNAME_LEN];
static char sProjectDir[MAX_PATHNAME_LEN];
int iError;
Point cell;
	
	// Initialisations
	SetGbQuitter(0);

	//--------------------------
	//--------------------------
	
	strcpy(GsPathResult, "");
	strcpy(GsPathConfigFile, "");
	//DisplayCurrentCycle(GiPanel, GsPathConfigFile);
	
	
	// Copie du pointeur vers les param�tres de configuration
	SetGptstConfig(*ptStConfig);
	
	// Initialisation du nombre d'�l�ments du tableau des vitesses
	GstTabVitesse.iNbElmts 		= 1;
	GstTabVitesse.dVit[0] 		= 0.0;
	GstTabVitesse.dDuree[0]		= 1.0;
	// Initialisation du nombre d'�l�ments du tableau des pressions
	GstTabPression.iNbElmts		= 1;
	GstTabPression.dPress[0] 	= 0.0;
	GstTabPression.dDuree[0]	= 1.0;
	
	// Initialisation des variables globales
	GiPanelPere		= iPanelPere;
	SetGiUnitVitesse(iUnitVitesse);
	SetGiUnitPression(iUnitPression);
	
	// R�pertoire du projet
	GetProjectDir (sProjectDir); 
	
	// Formation du chemin vers 
	sprintf(sFileNameEcran,"%s\\%s\\%s", sProjectDir, sSousRepertoireEcran, sNOM_IHM_MODES);

	// Chargement du Panel principal
	GiPanel = LoadPanel (GiPanelPere, sFileNameEcran, PANEL_MODE);
	if (GiPanel<0) {
		MessagePopup(sFileNameEcran, GetUILErrorString (GiPanel));
		return(1);
	}
	
	// Chargement du panel d'ajout de lignes
	GiPopupAdd = LoadPanel (GiPanel, sFileNameEcran, POPUP_ADD);
	if (GiPopupAdd<0) {
		MessagePopup(sFileNameEcran, GetUILErrorString (GiPopupAdd));
		return(1);
	}	

	// Chargement du panel de d�tail des status
	GiStatusPanel = LoadPanel (0, sFileNameEcran, PANEL_STAT);
	if (GiStatusPanel<0) {
		MessagePopup(sFileNameEcran, GetUILErrorString (GiStatusPanel));
		return(1);
	}	
	

	// Chargement du popup menu (gestion des grilles de donn�es)
  	GiPopupMenuHandle = LoadMenuBar (0, sFileNameEcran, GST_TAB);

	// Traduction de l'IHM  	
	iError = GstFilesTraductIhmModes(GiPanel, GiPopupMenuHandle, GiStatusPanel, GetGiUnitVitesse(), GetGiUnitPression());
	
	// Fixe les limites des tableaux de vitesse et de pression
	iError = GstTablesSetLim(GiPanel, PANEL_MODE_TABLE_VITESSES, PANEL_MODE_TABLE_PRESSION, GetGiUnitVitesse(),
								GetGiUnitPression(), GetPointerToGptstConfig());
	ReleasePointerToGptstConfig();
	
	// Fixe les limites des saisies manuelles de vitesse et pression
	iError = SetLimSaisiesMan(GiPanel, PANEL_MODE_SAISIE_VITESSE_MANU, PANEL_MODE_SAISIE_PRESSION_MANU, PANEL_MODE_SAISIE_DUREE_VIT_MANU,
								PANEL_MODE_SAISIE_DUREE_PRES_MAN, GetGiUnitVitesse(), GetGiUnitPression(), GetPointerToGptstConfig());
	ReleasePointerToGptstConfig();
	
	// Supression des donn�es du tableau des vitesses
	DeleteTableRows (GiPanel, PANEL_MODE_TABLE_VITESSES, 1, 1);
	// Supression des donn�es du tableau des pressions
	DeleteTableRows (GiPanel, PANEL_MODE_TABLE_PRESSION, 1, 1);		
	// Ajout d'une ligne dans le tableau des vitesses
	InsertTableRows (GiPanel, PANEL_MODE_TABLE_VITESSES, 1, 1, VAL_USE_MASTER_CELL_TYPE);
	// Ajout d'une ligne dans le tableau des pressions
	InsertTableRows (GiPanel, PANEL_MODE_TABLE_PRESSION, 1, 1, VAL_USE_MASTER_CELL_TYPE);
	
	
	cell.x = 2;
	cell.y = 1;
	SetTableCellVal (GiPanel, PANEL_MODE_TABLE_VITESSES, cell, 1.0);
	SetTableCellVal (GiPanel, PANEL_MODE_TABLE_PRESSION, cell, 1.0);
	
	
    // M�morisation de la fonction de retour Ihm
    GFonctionRetourIhm=FonctionRetourIhm;
    
	return 0;
}

// DEBUT ALGO
//****************************************************************************** 
// int GstIhmCycles(int iPanel, int iEtatCyclesVitPres, int iEtatCycleVitesse, 
//					int iEtatCyclePression)
//****************************************************************************** 
//	- int iPanel 				: Handle du panel
//	  int iEtatCyclesVitPres	: Etat du cycle de vitesse/pression
//	  int iEtatCycleVitesse		: Etat du cycle de vitesse
//	  int iEtatCyclePression	: Etat du cycle de pression
//
//  - Configuration de l'IHM en fonction du d�roulement des cycles
//
//  - 0 si OK, sinon erreur
//****************************************************************************** 
// FIN ALGO
int GstIhmCycles(int iPanel, int iEtatCyclesVitPres, int iEtatCycleVitesse, int iEtatCyclePression)
{   
	if ((iEtatCycleVitesse == iEN_COURS) || (iEtatCyclePression == iEN_COURS)){
		SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_CONFIG, 			ATTR_DIMMED, 1);
		SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_MODE_AUTOMATIQUE, ATTR_DIMMED, 1);
		SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_MODE_MANUEL, 		ATTR_DIMMED, 1);
		SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_QUITTER, 			ATTR_DIMMED, 1);
		
		if (iEtatCyclesVitPres == iEN_COURS){
			SetCtrlAttribute (iPanel, PANEL_MODE_BUTT_START_VIT_PRESS, 	ATTR_DIMMED, 0);
			// Traduction du bouton de D�part cycle vitesses et pressions
			SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VIT_PRESS, ATTR_LABEL_TEXT, sBOUTON_STOP_VIT_PRES);
		}
		else{
				SetCtrlAttribute (iPanel, PANEL_MODE_BUTT_START_VIT_PRESS, 	ATTR_DIMMED, 1);
				// Traduction du bouton de D�part cycle vitesses et pressions
				if (GetGiMode() == iMODE_AUTOMATIQUE)    
					SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VIT_PRESS, ATTR_LABEL_TEXT, sBOUTON_DEP_VIT_PRES);
				else
					SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VIT_PRESS, ATTR_LABEL_TEXT, sBOUTON_VALID_VIT_PRES);
			}
	}
	else{
			SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_CONFIG, 			ATTR_DIMMED, 0);
			
			if (GetGiMode() == iMODE_AUTOMATIQUE) 
				SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_MODE_MANUEL, 		ATTR_DIMMED, 0);
			else
				SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_MODE_AUTOMATIQUE, ATTR_DIMMED, 0);
				
			SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_QUITTER, 			ATTR_DIMMED, 0);

			// Traduction du bouton de D�part cycle vitesses et pressions
			if (GetGiMode() == iMODE_AUTOMATIQUE)    
				SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VIT_PRESS, ATTR_LABEL_TEXT, sBOUTON_DEP_VIT_PRES);
			else
				SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VIT_PRESS, ATTR_LABEL_TEXT, sBOUTON_VALID_VIT_PRES);
		}


	if (iEtatCyclesVitPres == iEN_COURS){
		if ((iEtatCycleVitesse == iARRET) && (iEtatCyclePression == iARRET)){
			// Traduction du bouton de D�part cycle vitesses et pressions
			if (GetGiMode() == iMODE_AUTOMATIQUE)    
				SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VIT_PRESS, ATTR_LABEL_TEXT, sBOUTON_DEP_VIT_PRES);
			else
				SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VIT_PRESS, ATTR_LABEL_TEXT, sBOUTON_VALID_VIT_PRES);
			
			SetGiStartVitPress(0);
			SetCtrlAttribute (iPanel, PANEL_MODE_BUTT_START_VITESSE, 	ATTR_DIMMED, 0);
			SetCtrlAttribute (iPanel, PANEL_MODE_BUT_START_PRESSION, 	ATTR_DIMMED, 0);
		}
		else{
				if (iEtatCycleVitesse == iARRET)
					SetCtrlAttribute (iPanel, PANEL_MODE_BUTT_START_VITESSE, 	ATTR_DIMMED, 1);

				if (iEtatCyclePression == iARRET)
					SetCtrlAttribute (iPanel, PANEL_MODE_BUT_START_PRESSION, 	ATTR_DIMMED, 1);
			}
	}	
	
	//--------- VITESSE -----------------
	if (iEtatCycleVitesse == iEN_COURS){
		SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_VITESSES, 		ATTR_CTRL_MODE, VAL_INDICATOR);
		SetCtrlAttribute (iPanel, PANEL_MODE_NBE_CYCLES_VITESSE, 	ATTR_CTRL_MODE, VAL_INDICATOR);
		SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_PRESSION, 		ATTR_CTRL_MODE, VAL_INDICATOR);
		SetCtrlAttribute (iPanel, PANEL_MODE_NBE_CYCLES_PRESSION, 	ATTR_CTRL_MODE, VAL_INDICATOR);
		
		// Traduction du bouton de D�part cycle vitesses
		SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VITESSE, ATTR_LABEL_TEXT, sBOUTON_STOP_VIT);
	}
	else{
			if ((iEtatCycleVitesse != iEN_COURS) && (iEtatCyclePression != iEN_COURS)){
				SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_VITESSES, 		ATTR_CTRL_MODE, VAL_HOT);
				SetCtrlAttribute (iPanel, PANEL_MODE_NBE_CYCLES_VITESSE, 	ATTR_CTRL_MODE, VAL_HOT);
				SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_PRESSION, 		ATTR_CTRL_MODE, VAL_HOT);
				SetCtrlAttribute (iPanel, PANEL_MODE_NBE_CYCLES_PRESSION,	ATTR_CTRL_MODE, VAL_HOT);
			}			
			// Traduction du bouton de D�part cycle vitesses
			if (GetGiMode() == iMODE_AUTOMATIQUE)  
				SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VITESSE, ATTR_LABEL_TEXT, sBOUTON_DEP_VIT);
			else
				SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VITESSE, ATTR_LABEL_TEXT, sBOUTON_VALID_VIT);
		}	

	//--------- PRESSION -----------------
	if (iEtatCyclePression == iEN_COURS){
		SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_PRESSION, 		ATTR_CTRL_MODE, VAL_INDICATOR);
		SetCtrlAttribute (iPanel, PANEL_MODE_NBE_CYCLES_PRESSION, 	ATTR_CTRL_MODE, VAL_INDICATOR);
		SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_VITESSES, 		ATTR_CTRL_MODE, VAL_INDICATOR);
		SetCtrlAttribute (iPanel, PANEL_MODE_NBE_CYCLES_VITESSE, 	ATTR_CTRL_MODE, VAL_INDICATOR);
		
		// Traduction du bouton de D�part cycle pressions
		SetCtrlAttribute (GiPanel, PANEL_MODE_BUT_START_PRESSION, ATTR_LABEL_TEXT, sBOUTON_STOP_PRES);
	}
	else{
			if ((iEtatCycleVitesse != iEN_COURS) && (iEtatCyclePression != iEN_COURS)){
				SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_VITESSES, 		ATTR_CTRL_MODE, VAL_HOT);
				SetCtrlAttribute (iPanel, PANEL_MODE_NBE_CYCLES_VITESSE, 	ATTR_CTRL_MODE, VAL_HOT);
				SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_PRESSION, 		ATTR_CTRL_MODE, VAL_HOT);
				SetCtrlAttribute (iPanel, PANEL_MODE_NBE_CYCLES_PRESSION,	ATTR_CTRL_MODE, VAL_HOT);
			}
			// Traduction du bouton de D�part cycle pressions
			if (GetGiMode() == iMODE_AUTOMATIQUE)
				SetCtrlAttribute (GiPanel, PANEL_MODE_BUT_START_PRESSION, ATTR_LABEL_TEXT, sBOUTON_DEP_PRES);
			else
				SetCtrlAttribute (GiPanel, PANEL_MODE_BUT_START_PRESSION, ATTR_LABEL_TEXT, sBOUTON_VALID_PRES);
		}	
	
	return 0; //OK
}

//initialize the Anum Interface for automatic mode
void InitAnum(BOOL isRun)
{
	char sAnumPath[MAX_PATHNAME_LEN]; 
	/*
	if(isRun)
	{
		if(!GbAnumInit)
		{
			GetProjectDir (GsPathApplication);
			sprintf (sAnumPath, "%s\\%s", GsPathApplication, sANUM_DLL);
			ModesAddMessageZM("Init ANUM interface...");
	
			hDLL=LoadLibrary(sAnumPath);
			if (hDLL==NULL)
		    {
				ModesAddMessageZM("Failed to load ANUM API.dll!"); 
				GbAnumInit=0;
		        return;
		    }
		
		    // Get function
		    myFUnc=(TAPI)GetProcAddress(hDLL, "API");
		    if (myFUnc==NULL)
		    {
				ModesAddMessageZM("Failed to load function from API.dll!"); 
				GbAnumInit=0;
		        return;
		    }
			sprintf (sAnumPath, "%s\\%s\\%s", GsPathApplication,"Config", sANUM_CFG); 
			strcpy(aCommand, "LOAD");
	        strcpy(sAPILFRF.StringIn1, sAnumPath);
	        cAPI=myFUnc(aCommand, (void*)&sAPILFRF);
			
        	if (cAPI!=0)
			{
				ModesAddMessageZM("Failed to load ANUM cfg!"); 
				GbAnumInit=0;
            	return;
			}
			
		
			
			ModesAddMessageZM("ANUM interface OK!"); 
			GbAnumInit=1;
		}
	}
	else
	{
		if(GbAnumInit)
		{
			//FreeLibrary(hDLL);
			GbAnumInit=0;
		}
	}
	*/
}

// DEBUT ALGO
//****************************************************************************** 
// void DisplayMode(int iPanel, int iMode)
//****************************************************************************** 
//	- int iPanel: Handle du panel	
//	  int iMode : Mode manuel ou automatique
//
//  - Configuration de l'affichage de l'�cran en fonction du mode (automatique/manuel) 
//
//  - Aucun
//****************************************************************************** 
// FIN ALGO
void DisplayMode(int iPanel, int iMode)
{
#define iTOP_UNIT_VITESSE_MANUEL	176
#define iTOP_UNIT_PRESSION_MANUEL	444
#define iTOP_UNIT_VITESSE_AUTO		256
#define iTOP_UNIT_PRESSION_AUTO		520  
int iErr;
BOOL bDimmed;
BOOL bVisible;

	SetGbQuitter(0);

	// Effacement des graphiques
	DeleteGraphPlot (iPanel, PANEL_MODE_GRAPHE_VITESSE, -1, VAL_IMMEDIATE_DRAW);
	DeleteGraphPlot (iPanel, PANEL_MODE_GRAPHE_PRESSION,-1, VAL_IMMEDIATE_DRAW);

	switch (iMode){
		// Passage en mode manuel
		case iMODE_MANUEL:
			bDimmed 	= 1;
			bVisible 	= 0; 

			// Changement des libell�s des boutons de d�marrage des cycles
			iErr = SetCtrlAttribute (iPanel, PANEL_MODE_BUTT_START_VITESSE, ATTR_LABEL_TEXT, sBOUTON_VALID_VIT);
			// Traduction du bouton de D�part cycle pressions
			iErr = SetCtrlAttribute (iPanel, PANEL_MODE_BUT_START_PRESSION, ATTR_LABEL_TEXT, sBOUTON_VALID_PRES);
			// Traduction du bouton de D�part cycle vitesses et pressions
			iErr = SetCtrlAttribute (iPanel, PANEL_MODE_BUTT_START_VIT_PRESS, ATTR_LABEL_TEXT, sBOUTON_VALID_VIT_PRES);

			// D�placement du contr�le de choix d'unit�s
			iErr = SetCtrlAttribute (iPanel, PANEL_MODE_UNIT_VITESSE, 	 ATTR_TOP, 	iTOP_UNIT_VITESSE_MANUEL);
			iErr = SetCtrlAttribute (iPanel, PANEL_MODE_UNIT_PRESSION,	 ATTR_TOP, 	iTOP_UNIT_PRESSION_MANUEL);
			
			//Oprion cfg
			SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_CONFIG_CHARGER, 	ATTR_DIMMED, 	bDimmed);
			SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_CONFIG_ENREGISTRER, ATTR_DIMMED, 	bDimmed);
			SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_CONFIG_SEE_CURR_CYCLE, ATTR_DIMMED, 	bDimmed);
			SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_MODE_MANUEL, 		ATTR_DIMMED, 	bDimmed);
			SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_MODE_AUTOMATIQUE, ATTR_DIMMED,	!bDimmed);
			SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_MODE_RUN, ATTR_DIMMED,	0);
			SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_CONFIG_ITEM_LOAD_TCS, 	ATTR_DIMMED, 	1);
				
			SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_VITESSES, ATTR_VISIBLE, 			bVisible);
			SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_PRESSION, ATTR_VISIBLE, 			bVisible);			
	
			SetCtrlAttribute (iPanel, PANEL_MODE_NBE_CYCLES_PRESSION, ATTR_VISIBLE, 	bVisible);
			SetCtrlAttribute (iPanel, PANEL_MODE_NBE_CYCLES_VITESSE, ATTR_VISIBLE, 		bVisible);
			SetCtrlAttribute (iPanel, PANEL_MODE_NUM_CYCLE_VITESSE, 	ATTR_VISIBLE, 	bVisible);
			SetCtrlAttribute (iPanel, PANEL_MODE_NUM_CYCLE_PRESSION, ATTR_VISIBLE,		bVisible);			
	
			SetCtrlAttribute (iPanel, PANEL_MODE_SAISIE_PRESSION_MANU, ATTR_VISIBLE, 	!bVisible);
			SetCtrlAttribute (iPanel, PANEL_MODE_SAISIE_VITESSE_MANU, ATTR_VISIBLE,		!bVisible);
			SetCtrlAttribute (iPanel, PANEL_MODE_SAISIE_DUREE_VIT_MANU, ATTR_VISIBLE, 	!bVisible);
			SetCtrlAttribute (iPanel, PANEL_MODE_SAISIE_DUREE_PRES_MAN, ATTR_VISIBLE, 	!bVisible);	
			SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_SCRIPT, ATTR_VISIBLE, 	bVisible);
			
			SetCtrlAttribute (iPanel, PANEL_MODE_UNIT_PRESSION, ATTR_VISIBLE, 	1);
			SetCtrlAttribute (iPanel, PANEL_MODE_UNIT_VITESSE, ATTR_VISIBLE, 	1);
			SetCtrlAttribute (iPanel, PANEL_MODE_BUT_START_RUN, ATTR_VISIBLE, 	0); 
			SetCtrlAttribute (iPanel, PANEL_MODE_BUT_START_PRESSION, ATTR_VISIBLE, 	1);  
			SetCtrlAttribute (iPanel, PANEL_MODE_BUTT_START_VITESSE, ATTR_VISIBLE, 	1);
			
			//InitAnum(FALSE);
			
		break;
		// Passage en mode automatique
		case iMODE_AUTOMATIQUE: 
			bDimmed 	= 0;
			bVisible 	= 1;
			
			//------- Modif du 15/11/2010 par C.BERENGER ------ DEBUT ------------
			// Echelle des abscisses en mode automatique
			SetAxisScalingMode (GiPanel, PANEL_MODE_GRAPHE_VITESSE, VAL_BOTTOM_XAXIS, VAL_AUTOSCALE, 0.0, 100.0);
			SetAxisScalingMode (GiPanel, PANEL_MODE_GRAPHE_PRESSION, VAL_BOTTOM_XAXIS, VAL_AUTOSCALE, 0.0, 100.0);
			//------- Modif du 15/11/2010 par C.BERENGER ------ FIN ------------
				
			// Changement des libell�s des boutons de d�marrage des cycles
			iErr = SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VITESSE, ATTR_LABEL_TEXT, sBOUTON_DEP_VIT);
			// Traduction du bouton de D�part cycle pressions
			iErr = SetCtrlAttribute (GiPanel, PANEL_MODE_BUT_START_PRESSION, ATTR_LABEL_TEXT, sBOUTON_DEP_PRES);
			// Traduction du bouton de D�part cycle vitesses et pressions
			iErr = SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VIT_PRESS, ATTR_LABEL_TEXT, sBOUTON_DEP_VIT_PRES);

			// D�placement du contr�le de choix d'unit�s
			iErr = SetCtrlAttribute (GiPanel, PANEL_MODE_UNIT_VITESSE, 	ATTR_TOP, 	iTOP_UNIT_VITESSE_AUTO);
			iErr = SetCtrlAttribute (GiPanel, PANEL_MODE_UNIT_PRESSION, ATTR_TOP, 	iTOP_UNIT_PRESSION_AUTO);


			// Force le trac� des courbes sur les graphiques
			//GstGrapheMajGrapheVit(GiPanel, PANEL_MODE_TABLE_VITESSES, PANEL_MODE_GRAPHE_VITESSE, 1, GstTabVitesse.dDuree, GstTabVitesse.dVit, GstTabVitesse.iNbElmts, 1, iCOUL_CONS_VITESSE, 1);
			//GstGrapheMajGraphePres(GiPanel, PANEL_MODE_TABLE_PRESSION, PANEL_MODE_GRAPHE_PRESSION, 1, GstTabPression.dDuree, GstTabPression.dPress, GstTabPression.iNbElmts, 1, iCOUL_CONS_PRESSION, 1);
		
			//Oprion cfg
			SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_CONFIG_CHARGER, 	ATTR_DIMMED, 	bDimmed);
			SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_CONFIG_ENREGISTRER, ATTR_DIMMED, 	bDimmed);
			SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_CONFIG_SEE_CURR_CYCLE, ATTR_DIMMED, 	bDimmed);
			SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_MODE_MANUEL, 		ATTR_DIMMED, 	bDimmed);
			SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_MODE_AUTOMATIQUE, ATTR_DIMMED,	1);
			SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_MODE_RUN, ATTR_DIMMED,	0);
			SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_CONFIG_ITEM_LOAD_TCS, 	ATTR_DIMMED, 	1);    
				
			SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_VITESSES, ATTR_VISIBLE, 			bVisible);
			SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_PRESSION, ATTR_VISIBLE, 			bVisible);			
	
			SetCtrlAttribute (iPanel, PANEL_MODE_NBE_CYCLES_PRESSION, ATTR_VISIBLE, 	bVisible);
			SetCtrlAttribute (iPanel, PANEL_MODE_NBE_CYCLES_VITESSE, ATTR_VISIBLE, 		bVisible);
			SetCtrlAttribute (iPanel, PANEL_MODE_NUM_CYCLE_VITESSE, 	ATTR_VISIBLE, 	bVisible);
			SetCtrlAttribute (iPanel, PANEL_MODE_NUM_CYCLE_PRESSION, ATTR_VISIBLE,		bVisible);			
	
			SetCtrlAttribute (iPanel, PANEL_MODE_SAISIE_PRESSION_MANU, ATTR_VISIBLE, 	!bVisible);
			SetCtrlAttribute (iPanel, PANEL_MODE_SAISIE_VITESSE_MANU, ATTR_VISIBLE,		!bVisible);
			SetCtrlAttribute (iPanel, PANEL_MODE_SAISIE_DUREE_VIT_MANU, ATTR_VISIBLE, 	!bVisible);
			SetCtrlAttribute (iPanel, PANEL_MODE_SAISIE_DUREE_PRES_MAN, ATTR_VISIBLE, 	!bVisible);
			SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_SCRIPT, ATTR_VISIBLE, 	!bVisible);
			
			SetCtrlAttribute (iPanel, PANEL_MODE_UNIT_PRESSION, ATTR_VISIBLE, 	1);
			SetCtrlAttribute (iPanel, PANEL_MODE_UNIT_VITESSE, ATTR_VISIBLE, 	1);
			SetCtrlAttribute (iPanel, PANEL_MODE_BUT_START_RUN, ATTR_VISIBLE, 	0); 
			SetCtrlAttribute (iPanel, PANEL_MODE_BUT_START_PRESSION, ATTR_VISIBLE, 	1);  
			SetCtrlAttribute (iPanel, PANEL_MODE_BUTT_START_VITESSE, ATTR_VISIBLE, 	1);
			
			//InitAnum(FALSE);
			
		break;
			case iMODE_RUN: 
			bDimmed 	= 0;
			bVisible 	= 1;
			
			//------- Modif du 15/11/2010 par C.BERENGER ------ DEBUT ------------
			// Echelle des abscisses en mode automatique
			SetAxisScalingMode (GiPanel, PANEL_MODE_GRAPHE_VITESSE, VAL_BOTTOM_XAXIS, VAL_AUTOSCALE, 0.0, 100.0);
			SetAxisScalingMode (GiPanel, PANEL_MODE_GRAPHE_PRESSION, VAL_BOTTOM_XAXIS, VAL_AUTOSCALE, 0.0, 100.0);
			//------- Modif du 15/11/2010 par C.BERENGER ------ FIN ------------
				
			// Changement des libell�s des boutons de d�marrage des cycles
			iErr = SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VITESSE, ATTR_LABEL_TEXT, sBOUTON_DEP_VIT);
			// Traduction du bouton de D�part cycle pressions
			iErr = SetCtrlAttribute (GiPanel, PANEL_MODE_BUT_START_PRESSION, ATTR_LABEL_TEXT, sBOUTON_DEP_PRES);
			// Traduction du bouton de D�part cycle vitesses et pressions
			iErr = SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VIT_PRESS, ATTR_LABEL_TEXT, sBOUTON_DEP_VIT_PRES);

			// D�placement du contr�le de choix d'unit�s
			iErr = SetCtrlAttribute (GiPanel, PANEL_MODE_UNIT_VITESSE, 	ATTR_TOP, 	iTOP_UNIT_VITESSE_AUTO);
			iErr = SetCtrlAttribute (GiPanel, PANEL_MODE_UNIT_PRESSION, ATTR_TOP, 	iTOP_UNIT_PRESSION_AUTO);


			// Force le trac� des courbes sur les graphiques
			//GstGrapheMajGrapheVit(GiPanel, PANEL_MODE_TABLE_VITESSES, PANEL_MODE_GRAPHE_VITESSE, 1, GstTabVitesse.dDuree, GstTabVitesse.dVit, GstTabVitesse.iNbElmts, 1, iCOUL_CONS_VITESSE, 1);
			//GstGrapheMajGraphePres(GiPanel, PANEL_MODE_TABLE_PRESSION, PANEL_MODE_GRAPHE_PRESSION, 1, GstTabPression.dDuree, GstTabPression.dPress, GstTabPression.iNbElmts, 1, iCOUL_CONS_PRESSION, 1);
		
			//Oprion cfg
			SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_CONFIG_CHARGER, 	ATTR_DIMMED, 	!bDimmed);
			SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_CONFIG_ENREGISTRER, ATTR_DIMMED, 	!bDimmed);
			SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_CONFIG_SEE_CURR_CYCLE, ATTR_DIMMED, 	!bDimmed);
			SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_MODE_MANUEL, 		ATTR_DIMMED, 	bDimmed);
			SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_MODE_AUTOMATIQUE, ATTR_DIMMED,	bDimmed);
			SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_MODE_RUN, ATTR_DIMMED,	1);
			SetMenuBarAttribute (GetPanelMenuBar (iPanel), CONFIG_CONFIG_ITEM_LOAD_TCS, 	ATTR_DIMMED, 	0);    
				
			SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_VITESSES, ATTR_VISIBLE, 			!bVisible);
			SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_PRESSION, ATTR_VISIBLE, 			!bVisible);			
	
			SetCtrlAttribute (iPanel, PANEL_MODE_NBE_CYCLES_PRESSION, ATTR_VISIBLE, 	!bVisible);
			SetCtrlAttribute (iPanel, PANEL_MODE_NBE_CYCLES_VITESSE, ATTR_VISIBLE, 		!bVisible);
			SetCtrlAttribute (iPanel, PANEL_MODE_NUM_CYCLE_VITESSE, 	ATTR_VISIBLE, 	!bVisible);
			SetCtrlAttribute (iPanel, PANEL_MODE_NUM_CYCLE_PRESSION, ATTR_VISIBLE,		!bVisible);			
	
			SetCtrlAttribute (iPanel, PANEL_MODE_SAISIE_PRESSION_MANU, ATTR_VISIBLE, 	!bVisible);
			SetCtrlAttribute (iPanel, PANEL_MODE_SAISIE_VITESSE_MANU, ATTR_VISIBLE,		!bVisible);
			SetCtrlAttribute (iPanel, PANEL_MODE_SAISIE_DUREE_VIT_MANU, ATTR_VISIBLE, 	!bVisible);
			SetCtrlAttribute (iPanel, PANEL_MODE_SAISIE_DUREE_PRES_MAN, ATTR_VISIBLE, 	!bVisible);
			SetCtrlAttribute (iPanel, PANEL_MODE_TABLE_SCRIPT, ATTR_VISIBLE, 	bVisible);
			
			SetCtrlAttribute (iPanel, PANEL_MODE_UNIT_PRESSION, ATTR_VISIBLE, 	0);
			SetCtrlAttribute (iPanel, PANEL_MODE_UNIT_VITESSE, ATTR_VISIBLE, 	0);
			SetCtrlAttribute (iPanel, PANEL_MODE_BUT_START_RUN, ATTR_VISIBLE, 	1);   
			SetCtrlAttribute (iPanel, PANEL_MODE_BUT_START_PRESSION, ATTR_VISIBLE, 	0);  
			SetCtrlAttribute (iPanel, PANEL_MODE_BUTT_START_VITESSE, ATTR_VISIBLE, 	0);
			
			SetCtrlAttribute (GiPanel, PANEL_MODE_TABLE_SCRIPT,ATTR_WIDTH,225); 
			DeleteTableRows (GiPanel, PANEL_MODE_TABLE_SCRIPT, 1, -1);
			
			//InitAnum(TRUE);
			
		break;
	}
	

	
	// Mises � jour par rapport � l'unit� de vitesse
	iErr = SetUnitVitesse(iPanel, PANEL_MODE_UNIT_VITESSE);
	// Mises � jour par rapport � l'unit� de vitesse
	iErr = SetUnitPression(iPanel, PANEL_MODE_UNIT_PRESSION);
	
	// 
	SetCtrlAttribute (iPanel, PANEL_MODE_BUTT_OUV_GACHE, ATTR_LABEL_TEXT, "Open Electric Lock");
} 

// DEBUT ALGO
//****************************************************************************** 
//void CVICALLBACK ChgmentMode (int menuBar, int menuItem, void *callbackData,
//								int panel)
//****************************************************************************** 
//	- Param�tres CVI
//
//  - Changement de mode (automatique/manuel)
//
//  -  Aucun
//****************************************************************************** 
// FIN ALGO
void CVICALLBACK ChgmentMode (int menuBar, int menuItem, void *callbackData,
								int panel)
{
	switch(menuItem){
		case CONFIG_MODE_AUTOMATIQUE:
			SetGiMode(iMODE_AUTOMATIQUE);
			DisplayMode(panel, iMODE_AUTOMATIQUE);
		break;
		case CONFIG_MODE_MANUEL:
			SetGiMode(iMODE_MANUEL);
			DisplayMode(panel, iMODE_MANUEL);
		break;
		case CONFIG_MODE_RUN:
			SetGiMode(iMODE_RUN);
			DisplayMode(panel, iMODE_RUN);
		break;
	}
}

// DEBUT ALGO
//****************************************************************************** 
// void ModesDisplayPanel(int iMode)
//****************************************************************************** 
//	- int iMode : Mode automatique ou manuel
//
//  - Affichage de l'�cran du mode automatique ou manuel
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
// FIN ALGO
void ModesDisplayPanel(int iMode)
{
double dDelay=0.0;
int iStatus;
HANDLE threadHandle;
stConfig *ptstConfig;

	// Configuration de l'affichage de l'�cran en fonction du mode
	DisplayMode(GiPanel, iMode);
	// Affichage de l'�cran
	DisplayPanel (GiPanel);
	DisplayCurrentCycle(GiPanel, GsPathConfigFile);

	SetGbQuitter(0);  
	
	SetGiMode(iMode);
	SetGiEtat(iETAT_ATTENTE); 
	
	//-----------------------------
	//---- Valeurs par d�faut -----
	SetGbGacheActive(iGACHE_FERMEE);
	SetGiSelectionHandleVitesse(0);
	SetGiSelectionHandlePression(0);
	SetGiSelectionHandle(0);
	SetGiControlGrapheSelection(0);

	SetGiPanelStatusDisplayed(0);

	SetGiDisableMajGrapheVitesse(0);
	SetGiDisableMajGraphePression(0);

	SetGiStartCycleVitesse(0);
	SetGiStartCyclePression(0);
	SetGiStartVitPress(0);

	SetGbQuitter(0);

	SetGiHandleFileResult(-1);

	SetGbRazTimeVit(0);
	SetGbRazTimePress(0);

	SetGiErrUsb6008(0);
	SetGiErrVaria(0);
	SetGiIndexStepVitesse(1);
	SetGiIndexStepPression(1);

	SetGfVitesse(0.0);
	SetGdPression(0.0);
	SetGdPressionAProg(0.0);
	SetGdVitesseAProg(0.0);

	SetGiIndexCycleVitesse(1);
	SetGiTimeDepartEssaiSpeed(0);
	SetGiTimeDepartEssaiPress(0);

	SetGdDurEcoulEssaiSpeed(0.0);
	SetGdDurEcoulEssaiPress(0.0);
	SetGiIndexCyclePression(1);

	SetGbEndCycleVitesse(1);
	SetGbEndCyclePression(1);
	//----------------------------

	// Initialisation de la tache de gestion des cycles de vitesse
	//iStatus = CmtNewThreadPool (1, &GiThreadPoolHandleGestionVitesse);
	iStatus = CmtScheduleThreadPoolFunction (DEFAULT_THREAD_POOL_HANDLE , ThreadCycleVitesse, NULL, &GiThreadCycleVitesse);
	
	// Initialisation de la tache de gestion des cycles de pression
	//iStatus = CmtNewThreadPool (1, &GiThreadPoolHandleGestionPression);
	iStatus = CmtScheduleThreadPoolFunction (DEFAULT_THREAD_POOL_HANDLE, ThreadCyclePression, NULL, &GiThreadCyclePression);

	// Initialisation de la tache de gestion des s�curit�s
	//iStatus = CmtNewThreadPool (1, &GiThreadPoolHandleGestionSecurite);
	iStatus = CmtScheduleThreadPoolFunction (DEFAULT_THREAD_POOL_HANDLE, ThreadGestionSecurite, NULL, &GiThreadGestionSecurite);
	
	iStatus = CmtScheduleThreadPoolFunction (DEFAULT_THREAD_POOL_HANDLE, ThreadCycleRun, NULL, &GiThreadCycleRun); 
	
	iStatus = CmtScheduleThreadPoolFunction (DEFAULT_THREAD_POOL_HANDLE, ThreadCycleAnum, NULL, &GiThreadCycleAnum);    

	// Initialisation de la tache de gestion des acquisitions
	//iStatus = CmtNewThreadPool (1, &GiThreadPoolHandleAcquisitions);
	//iStatus = CmtScheduleThreadPoolFunction (GiThreadPoolHandleAcquisitions, ThreadAcquisitions, NULL, &GiThreadAcquisitions);

	ptstConfig = GetPointerToGptstConfig();
	dDelay = ((double)ptstConfig->iReadDelay) / 1000;   
	GiThreadAcquisitions = NewAsyncTimer (dDelay, -1, 0, ThreadAcquisitions, NULL);
	ReleasePointerToGptstConfig(); 

	GbThreadPoolActive = 1;	
}
 
// DEBUT ALGO
//****************************************************************************** 
// int ShowSelection(int iPanel, int iControlGrid, int iControlGraphe, int iColor)
//****************************************************************************** 
//	- int iPanel		: Handle du panel
//	  int iControlGrid	: Num�ro de contr�le de la grille de donn�es
//    int iControlGraphe: Num�ro de contr�le du graphique
//	  int iColor		: Couleur de la s�lection
//
//  - Montre sur le graphique la s�lection en cours dans la table de donn�es
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
// FIN ALGO
int ShowSelection(int iPanel, int iControlGrid, int iControlGraphe, int iColor)
{
Point pCell1;
Point pCell2;
double dValY;
double dDuree;
double dX1;
double dX2;
double dY1;
double dY2;
int iNumberOfRows;
int iSelectionHandle;
int iX;
int iY;
int iLeftButt;
int iRightButt;
int iLeft;
int iTop;
int i;
int iStatus;
int iValue;


	// D�termination du nombre de lignes du contr�le (data grid)
	GetNumTableRows (iPanel, iControlGrid, &iNumberOfRows);
	
	// Lecture de la position (en pixels) du curseur de la souris sur le graphique
	GetGlobalMouseState (&iPanel, &iX, &iY, &iLeftButt, &iRightButt, NULL);

	// Lecture de la position du panel (coordonn�es en haut � gauche)
	GetPanelAttribute (iPanel, ATTR_LEFT, &iLeft);
	GetPanelAttribute (iPanel, ATTR_TOP, &iTop);

	// Lecture de la valeur de la cellule par rapport � la position de la souris
	GetTableCellFromPoint (iPanel, iControlGrid, MakePoint (iX-iLeft, iY-iTop), &pCell1);

	// Si la veleur de la ligne dans la liste est correcte
	if ((pCell1.y <= iNumberOfRows)&&(pCell1.y > 0)&&(pCell1.x > 0)&&(pCell1.x < 3)){
		//---- Colonne des dur�es ------
		pCell2.x=2;
		dDuree = 0.0;
		// Ajout de toutes les dur�es
		for(i=1; i<=pCell1.y; i++){
			pCell2.y = i;
			GetTableCellVal (iPanel, iControlGrid, pCell2, &dValY);
			dDuree += dValY;
		}

		//---- Colonne des valeurs (vitesse ou pression) ------
		pCell1.x = 1;
		// Lecture de la valeur en Y de la cellule s�lectionn�e
		GetTableCellVal (iPanel, iControlGrid, pCell1, &dValY);

		// Effacement de la derni�re s�lection sur le graphique
		iSelectionHandle = GetGiSelectionHandle();
		iStatus = GetPlotAttribute (iPanel, GetGiControlGrapheSelection(), iSelectionHandle, ATTR_PLOT_THICKNESS, &iValue);
		
		if(iStatus == 0)
			if (iSelectionHandle != 0)
				DeleteGraphPlot (iPanel, GetGiControlGrapheSelection(), iSelectionHandle, VAL_IMMEDIATE_DRAW);
			
		dX2 = dDuree;
		dY2 = dValY; 

		pCell1.x = 2;
		// Lecture de la valeur en Y de la cellule s�lectionn�e
		GetTableCellVal (iPanel, iControlGrid, pCell1, &dValY);

		
		dX1 = dDuree - dValY;		

		// Colonne des donn�es (vitesse ou pression)
		pCell1.x = 1;
		
		// Si la valeur de la ligne est correcte
		if (pCell1.y > 1){
			pCell1.y -= 1;
			// Lecture de la valeur en Y de la cellule s�lectionn�e
			GetTableCellVal (iPanel, iControlGrid, pCell1, &dValY);
		}
		else{
				dX1 = 0.0;
				dValY = 0.0;//dY2; // Modif pour premier cycle
			}

		dY1 = dValY;					

		
		// S'il y a plus d'un pixel de diff�rence entre le point de d�part et le point d'arriv�e
		if ((abs(dX2 - dX1) >= 1.0) || (abs(dY2 - dY1)>= 1.0)){ 
			// Trac� d'une ligne
			SetGiSelectionHandle(PlotLine (GiPanel, iControlGraphe, dX1, dY1, dX2, dY2, iColor));
		
			// Sauvegarde du handle du graphique de la derni�re s�lection
			SetGiControlGrapheSelection(iControlGraphe);
		
			// Taille du segment de droite = 3 pixels
			SetPlotAttribute (GiPanel, iControlGraphe, GetGiSelectionHandle(), ATTR_PLOT_THICKNESS, 3);
			SetPlotAttribute (GiPanel, iControlGraphe, GetGiSelectionHandle(), ATTR_TRACE_COLOR, iColor);
		}
	}
	
	return 0;
}

// DEBUT ALGO
//****************************************************************************** 
//int CVICALLBACK GstTableVitesse (int panel, int control, int event,
//		void *callbackData, int eventData1, int eventData2)
//****************************************************************************** 
//	- Param�tres CVI
//
//  - Gestion des actions utilisateur sur la table de saisie des vitesses
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
// FIN ALGO
int CVICALLBACK GstTableVitesse (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
Point cell;
double dVal;
int iPanelStatusDisplayed;
int iAffMsg=0;

	iAffMsg=0; 
	iPanelStatusDisplayed = 0;
	
	switch (event){
		case EVENT_VAL_CHANGED:	
			if ((GetGiStartCycleVitesse() == 0) && (GetGiStartCyclePression() == 0)){
				// Oblige l'utilisateur � sauver la configuration avant de lancer un essai
				strcpy(GsPathConfigFile, "");
				DisplayCurrentCycle(GiPanel, GsPathConfigFile);
			
				cell.x = eventData2;
				cell.y = eventData1;
				GetTableCellVal (panel, control, cell, &dVal);

				if (eventData2 == 1){   
					// Valeur de vitesse
					//CHECK_TAB_INDEX("1", eventData1-1, 0, 5000)
					GstTabVitesse.dVit[eventData1-1] 	= dVal; 
				}
				else{
						// Dur�e
						//CHECK_TAB_INDEX("2", eventData1-1, 0, 5000)
						GstTabVitesse.dDuree[eventData1-1] 	= dVal;
					}
			
				/*
				if (!GetGiDisableMajGrapheVitesse()){
					// eventData1 = row of cell where event was generated; if 0, event affected multiple cells  
		            // eventData2 = column of cell where event was generated; if 0, event affected multiple cells  
					GstGrapheMajGrapheVit(	panel, PANEL_MODE_TABLE_VITESSES, PANEL_MODE_GRAPHE_VITESSE, 1,
										GstTabVitesse.dDuree, GstTabVitesse.dVit, GstTabVitesse.iNbElmts, 1, iCOUL_CONS_VITESSE, 1);
				}  */
			}
		break;
		case EVENT_RIGHT_CLICK:
			if((GetGiStartCycleVitesse() == 0) && (GetGiStartCyclePression() == 0)){
				GstDataGrid(panel, GiPopupMenuHandle, GiStatusPanel, GiPopupAdd, 
							control, iTYPE_VITESSE, iCOUL_CONS_VITESSE, iCOUL_CONS_PRESSION, GetPointerToGptstConfig(), 
							&GstTabVitesse, &GstTabPression, 
							&iPanelStatusDisplayed, &iAffMsg, GsPathConfigFile);
				ReleasePointerToGptstConfig();
				
				SetGiAffMsg(iAffMsg); 							
				SetGiPanelStatusDisplayed(iPanelStatusDisplayed);
			}
		break;
		case EVENT_LEFT_CLICK:
			if ((GetGiStartCycleVitesse() == 0) && (GetGiStartCyclePression() == 0)){
				// Montre sur le graphique la s�lection en cours dans la grille de donn�es
				ShowSelection(panel, control, PANEL_MODE_GRAPHE_VITESSE, iCOUL_CONS_VITESSE);
			}
		break;
	}
	
	
	return 0;
}

// DEBUT ALGO
//****************************************************************************** 
//int CVICALLBACK GstTablePression (int panel, int control, int event,
//		void *callbackData, int eventData1, int eventData2)
//****************************************************************************** 
//	- Param�tres CVI
//
//  - Gestion des actions utilisateur sur la table de saisie des pressions
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
// FIN ALGO
int CVICALLBACK GstTablePression (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
Point cell;
double dVal=0.0;
int iPanelStatusDisplayed=0;
int iAffMsg=0;

	iAffMsg=0;
	iPanelStatusDisplayed=0; 

	switch (event){
		case EVENT_VAL_CHANGED:	
			if((GetGiStartCycleVitesse() == 0) && (GetGiStartCyclePression() == 0)){
				// Oblige l'utilisateur � sauver la configuration avant de lancer un essai
				strcpy(GsPathConfigFile, "");
				DisplayCurrentCycle(GiPanel, GsPathConfigFile);
	
				cell.x = eventData2;
				cell.y = eventData1;
				GetTableCellVal (panel, control, cell, &dVal);
	
				if (eventData2 == 1){   
					// Valeur de pression
					//CHECK_TAB_INDEX("3", eventData1-1, 0, 5000)
					GstTabPression.dPress[eventData1-1] = dVal; 
				}
				else{
						// Dur�e
						//CHECK_TAB_INDEX("4", eventData1-1, 0, 5000)
						GstTabPression.dDuree[eventData1-1] 	= dVal;
					}			

				if (!GetGiDisableMajGraphePression()){	
					/* eventData1 = row of cell where event was generated; if 0, event affected multiple cells  */
		           	/* eventData2 = column of cell where event was generated; if 0, event affected multiple cells  */
					//GstGrapheMajGraphePres(panel, PANEL_MODE_TABLE_PRESSION, PANEL_MODE_GRAPHE_PRESSION, 1, GstTabPression.dDuree, GstTabPression.dPress, GstTabPression.iNbElmts, 1, iCOUL_CONS_PRESSION, 1);
				}
			}
		break;
		case EVENT_RIGHT_CLICK:
			if((GetGiStartCycleVitesse() == 0) && (GetGiStartCyclePression() == 0)){
				GstDataGrid(panel, GiPopupMenuHandle, GiStatusPanel, GiPopupAdd, 
							control, iTYPE_PRESSION, iCOUL_CONS_VITESSE, iCOUL_CONS_PRESSION, GetPointerToGptstConfig(), 
							&GstTabVitesse, &GstTabPression, 
							GetPointerToGiPanelStatusDisplayed(), &iAffMsg, GsPathConfigFile);
				ReleasePointerToGptstConfig();
				ReleasePointerToGiPanelStatusDisplayed();
				SetGiAffMsg(iAffMsg);
			}
		break;
		case EVENT_LEFT_CLICK:
			if((GetGiStartCycleVitesse() == 0) && (GetGiStartCyclePression() == 0)){
				// Montre sur le graphique la s�lection en cours dans la grille de donn�es
				ShowSelection(panel, control, PANEL_MODE_GRAPHE_PRESSION, iCOUL_CONS_PRESSION);
			}
		break;														   
	}
	

	return 0;
}

void LoadTest(char *sFileName,int panel)
{
	#define iTAILLE_MAX_ERR_MSG	5000
#define iBKG_ERROR_COLOR	0x00FFDDDD
char sTpsEcoule[50];
char sErrorMsg[iTAILLE_MAX_ERR_MSG];
char sComments[iMAX_CHAR_COMMENTS+2];
char sProjectDir[MAX_PATHNAME_LEN];

int iNbCyclesVit;
int iNbCyclesPres;
int iRet;
int iErr;
int i;
int iUnitVitesse;
int iUnitPression;
int iPanelStatusDisplayed;
int iAffMsg;
int iHeures;
int iMinutes;
int iSecondes;
Point cell;
Rect rect;
BOOL bSaveOneVit;
BOOL bSaveOnePres;
	  // On inactive l'�cran 
				SetPanelAttribute (panel, ATTR_DIMMED, 1); 
				
				// Recopie du chemin complet vers le fichier de configuration
				strcpy(GsPathConfigFile, sFileName);
				DisplayCurrentCycle(GiPanel, GsPathConfigFile);
				
				iErr = GstFilesLoadConfig (	GiPanel, PANEL_MODE_TABLE_VITESSES, PANEL_MODE_TABLE_PRESSION, PANEL_MODE_MESSAGES_MODE,
											GetPointerToGptstConfig(), &GstTabVitesse, &GstTabPression, 
											&iNbCyclesVit, &iNbCyclesPres,
											&iUnitVitesse, &iUnitPression, 
											sComments, &bSaveOneVit, &bSaveOnePres, sFileName,
											sErrorMsg, iTAILLE_MAX_ERR_MSG - 1);	
				ReleasePointerToGptstConfig();
				if(iErr != 0){
					strcpy(GsPathConfigFile, "");
				}

				if(iErr >= 0){
					SetGiUnitPression(iUnitPression);
					SetGiUnitVitesse(iUnitVitesse);					
				}
				
				DisplayCurrentCycle(GiPanel, GsPathConfigFile);
				
				// S'il y a eu une erreur (le fichier n'a pas pu �tre charg�)
				if(iErr < 0){
					// Mise � jour de la m�moire � partir des tableaux de donn�es
					GstTablesMajTableau(GiPanel, PANEL_MODE_TABLE_VITESSES, iTYPE_VITESSE, 
										&GstTabVitesse, &GstTabPression, sErrorMsg);
					GstTablesMajTableau(GiPanel, PANEL_MODE_TABLE_PRESSION, iTYPE_PRESSION, 
											&GstTabVitesse, &GstTabPression, sErrorMsg);					
				}
				
				if(iErr < 0){
					AffStatusPanel(GiPanel, GiStatusPanel, iLEVEL_MSG,sMSG_ERR_LOADING_FILE, 
									sErrorMsg, GetPointerToGiPanelStatusDisplayed(), &iAffMsg);
					ReleasePointerToGiPanelStatusDisplayed();

					SetGiAffMsg(iAffMsg);

					// On active l'�cran
					SetPanelAttribute (panel, ATTR_DIMMED, 0);					
					return;
				}
				
				if(iErr==2){
					AffStatusPanel(GiPanel, GiStatusPanel, iLEVEL_MSG,sMSG_ERR_READING_FILE, 
									sErrorMsg, GetPointerToGiPanelStatusDisplayed(), &iAffMsg);
					ReleasePointerToGiPanelStatusDisplayed(); 
					
					SetGiAffMsg(iAffMsg);
				}
				
				SetGiDisableMajGrapheVitesse(1);
				SetGiDisableMajGraphePression(1);
			
				// Supression des donn�es du tableau des vitesses
				DeleteTableRows (panel, PANEL_MODE_TABLE_VITESSES, 1, -1);
				// Supression des donn�es du tableau des pressions
				DeleteTableRows (panel, PANEL_MODE_TABLE_PRESSION, 1, -1);		

				// Fiwe les limites des tableaux de vitesse et de pression
				iErr = GstTablesSetLim(panel, PANEL_MODE_TABLE_VITESSES, PANEL_MODE_TABLE_PRESSION, GetGiUnitVitesse(),
											GetGiUnitPression(), GetPointerToGptstConfig());
				ReleasePointerToGptstConfig();
				
				//----- Modification du 15/11/2010 par C.BERENGER ---- DEBUT ----------
				// Fixe les limites des saisies manuelles de vitesse et pression
				iErr = SetLimSaisiesMan(GiPanel, PANEL_MODE_SAISIE_VITESSE_MANU, PANEL_MODE_SAISIE_PRESSION_MANU, PANEL_MODE_SAISIE_DUREE_VIT_MANU,
											PANEL_MODE_SAISIE_DUREE_PRES_MAN, GetGiUnitVitesse(), GetGiUnitPression(), GetPointerToGptstConfig());
				ReleasePointerToGptstConfig();
				//----- Modification du 15/11/2010 par C.BERENGER ---- FIN ----------

				
				// Insertion du nombre de lignes souhait� pour le tableau des vitesses
				InsertTableRows (panel, PANEL_MODE_TABLE_VITESSES, 1, GstTabVitesse.iNbElmts, VAL_CELL_NUMERIC);
				// Insertion du nombre de lignes souhait� pour le tableau des pressions
				InsertTableRows (panel, PANEL_MODE_TABLE_PRESSION, 1, GstTabPression.iNbElmts, VAL_CELL_NUMERIC);
				
				
			 	//----- Mise � jour de la table des vitesses -----
				rect.height = GstTabVitesse.iNbElmts;
				rect.left 	= 1;
				rect.top 	= 1;
				rect.width 	= 1;
				SetTableCellRangeVals (GiPanel, PANEL_MODE_TABLE_VITESSES, rect, GstTabVitesse.dVit, VAL_COLUMN_MAJOR);
			
				rect.height = GstTabVitesse.iNbElmts;
				rect.left 	= 2;
				rect.top 	= 1;
				rect.width 	= 1;
				SetTableCellRangeVals (GiPanel, PANEL_MODE_TABLE_VITESSES, rect, GstTabVitesse.dDuree, VAL_COLUMN_MAJOR);

				for(i=0; i<GstTabVitesse.iNbElmts; i++){ 
					//CHECK_TAB_INDEX("5", i, 0, 5000)
					if(GstTabVitesse.bWarningData[i]){
						// Coloration de la cellule en rouge
						cell.x = 1;
						cell.y = i+1;
						SetTableCellAttribute (GiPanel, PANEL_MODE_TABLE_VITESSES, cell, ATTR_TEXT_BGCOLOR, iBKG_ERROR_COLOR);
					}
					
					if(GstTabVitesse.bWarningDuree[i]){
						// Coloration de la cellule en rouge
						cell.x = 2;
						cell.y = i+1;
						SetTableCellAttribute (GiPanel, PANEL_MODE_TABLE_VITESSES, cell, ATTR_TEXT_BGCOLOR, iBKG_ERROR_COLOR);
					}
				}

				for(i=0; i<GstTabPression.iNbElmts; i++){ 
					//CHECK_TAB_INDEX("6", i, 0, 5000)
					if(GstTabPression.bWarningData[i]){
						// Coloration de la cellule en rouge
						cell.x = 1;
						cell.y = i+1;
						SetTableCellAttribute (GiPanel, PANEL_MODE_TABLE_PRESSION, cell, ATTR_TEXT_BGCOLOR, iBKG_ERROR_COLOR);
					}
					
					if(GstTabPression.bWarningDuree[i]){
						// Coloration de la cellule en rouge
						cell.x = 2;
						cell.y = i+1;
						SetTableCellAttribute (GiPanel, PANEL_MODE_TABLE_PRESSION, cell, ATTR_TEXT_BGCOLOR, iBKG_ERROR_COLOR);
					}
				}
				
				// Mise � jour du graphique des vitesses
				//GstGrapheMajGrapheVit(panel, PANEL_MODE_TABLE_VITESSES, PANEL_MODE_GRAPHE_VITESSE, 1, GstTabVitesse.dDuree, GstTabVitesse.dVit, GstTabVitesse.iNbElmts, 1, iCOUL_CONS_VITESSE, 1);


				//----- Mise � jour de la table des pressions ----
				rect.height = GstTabPression.iNbElmts;
				rect.left 	= 1;
				rect.top 	= 1;
				rect.width 	= 1;
				SetTableCellRangeVals (GiPanel, PANEL_MODE_TABLE_PRESSION, rect, GstTabPression.dPress, VAL_COLUMN_MAJOR);
			
				rect.height = GstTabPression.iNbElmts;
				rect.left 	= 2;
				rect.top 	= 1;
				rect.width 	= 1;
				SetTableCellRangeVals (GiPanel, PANEL_MODE_TABLE_PRESSION, rect, GstTabPression.dDuree, VAL_COLUMN_MAJOR);			
			
				// Mise � jour du graphique des pressions
				//GstGrapheMajGraphePres(panel, PANEL_MODE_TABLE_PRESSION, PANEL_MODE_GRAPHE_PRESSION, 1, GstTabPression.dDuree, GstTabPression.dPress, GstTabPression.iNbElmts, 1, iCOUL_CONS_PRESSION, 1);
		
				//------------------------------
				
				// Mise � jour du nombre de cycle de vitesse
				SetCtrlVal (GiPanel, PANEL_MODE_NBE_CYCLES_VITESSE, iNbCyclesVit);
		
				// Mise � jour du nombre de cycle de pression
				SetCtrlVal (GiPanel, PANEL_MODE_NBE_CYCLES_PRESSION, iNbCyclesPres);
		
				SetGiDisableMajGrapheVitesse(0);
				SetGiDisableMajGraphePression(0);
			
				// Mise � jour par rapport � l'unit� de vitesse
				iErr = SetUnitVitesse(panel, PANEL_MODE_UNIT_VITESSE);
				// Mise � jour par rapport � l'unit� de pression
				iErr = SetUnitPression(panel, PANEL_MODE_UNIT_PRESSION);
			
				// Mise � jour du cycle en cours
				SetCtrlVal (panel, PANEL_MODE_NUM_CYCLE_VITESSE, 	0);
				SetCtrlVal (panel, PANEL_MODE_NUM_CYCLE_PRESSION, 	0);
				
				// Mise � jour du temps d'essai �coul�
				sprintf(sTpsEcoule, sFORMAT_DUREE_ECOULEE, 0, 0, 0);
				SetCtrlVal (panel, PANEL_MODE_AFFICH_TPS_VIT, 		sTpsEcoule);
				SetCtrlVal (panel, PANEL_MODE_AFFICH_TPS_PRESS, 	sTpsEcoule);
				
				// On active l'�cran
				SetPanelAttribute (panel, ATTR_DIMMED, 0);
}

// DEBUT ALGO
//****************************************************************************** 
//void CVICALLBACK Configuration (int menuBar, int menuItem, void *callbackData,
//		int panel)
//****************************************************************************** 
//	- Param�tres CVI
//
//  - Gestion des fichiers de donn�es (vitesse et pression)
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
// FIN ALGO
void CVICALLBACK Configuration (int menuBar, int menuItem, void *callbackData,
								int panel)
{
#define iTAILLE_MAX_ERR_MSG	5000
#define iBKG_ERROR_COLOR	0x00FFDDDD
char sTpsEcoule[50];
char sErrorMsg[iTAILLE_MAX_ERR_MSG];
char sComments[iMAX_CHAR_COMMENTS+2];
char sProjectDir[MAX_PATHNAME_LEN];
char sFileName[MAX_PATHNAME_LEN];
int iNbCyclesVit;
int iNbCyclesPres;
int iRet;
int iErr;
int i;
int iUnitVitesse;
int iUnitPression;
int iPanelStatusDisplayed;
int iAffMsg;
int iHeures;
int iMinutes;
int iSecondes;
Point cell;
Rect rect;
BOOL bSaveOneVit;
BOOL bSaveOnePres;

char **fileList = NULL, **ppc = NULL;
int numFiles;

	// Formation du chemin vers le r�pertoire des configurations
	GetProjectDir(sProjectDir);
	strcat(sProjectDir, "\\"sREP_CONFIGURATIONS);

	switch (menuItem){
		case CONFIG_CONFIG_CHARGER:
			iRet = FileSelectPopup (sProjectDir, "*."sEXT_FICHIERS, "", "", VAL_SELECT_BUTTON, 0, 1, 1, 0, sFileName);
			
			if (iRet != VAL_NO_FILE_SELECTED)
			{ 
				   LoadTest(sFileName,panel);
			}
		break;
		case CONFIG_CONFIG_ENREGISTRER:
			// Modification du 01/02/2012 par C. BERENGER ---- DEBUT -----
			// La restriction au r�pertoire courant a �t� supprim�e � la demande du client
			iRet = FileSelectPopup (sProjectDir, "*."sEXT_FICHIERS, "", "", VAL_SAVE_BUTTON, 0, 1, 1, 0, sFileName);
			// Modification du 01/02/2012 par C. BERENGER ---- FIN -----
			
			if (iRet != VAL_NO_FILE_SELECTED){
				// On inactive l'�cran 
				SetPanelAttribute (panel, ATTR_DIMMED, 1); 

				GetCtrlVal (GiPanel, PANEL_MODE_NBE_CYCLES_VITESSE, 	&iNbCyclesVit);
				GetCtrlVal (GiPanel, PANEL_MODE_NBE_CYCLES_PRESSION, &iNbCyclesPres);
			
				iErr =  GstFilesSaveConfig (panel, &GstTabVitesse, &GstTabPression, 
											iNbCyclesVit, iNbCyclesPres,
											GetGiUnitVitesse(), GetGiUnitPression(), 
											bSAVE_ONE_VIT, bSAVE_ONE_PRES, 
											bSAVE_VIT, bSAVE_PRES, sFileName,
											sErrorMsg, iTAILLE_MAX_ERR_MSG - 1);
				
				if (iErr == 0){
					// Recopie du chemin complet vers le fichier de configuration
					strcpy(GsPathConfigFile, sFileName);
					DisplayCurrentCycle(GiPanel, GsPathConfigFile);
				}
				else{
						AffStatusPanel(GiPanel, GiStatusPanel, iLEVEL_MSG,sMSG_ERR_SAV_CYCLES, sErrorMsg, GetPointerToGiPanelStatusDisplayed(), &iAffMsg);
						ReleasePointerToGiPanelStatusDisplayed();
						
						SetGiAffMsg(iAffMsg);
					}
				
				// On active l'�cran
				SetPanelAttribute (panel, ATTR_DIMMED, 0);
			}
		break;
		case CONFIG_CONFIG_ITEM_LOAD_TCS:
			
		

			//iRet = FileSelectPopup (sProjectDir, "*."sEXT_FICHIERS, "", "", VAL_SELECT_BUTTON, 0, 1, 1, 0, sFileName);
			iRet = MultiFileSelectPopup(sProjectDir, "*.""xls", "", "", 1, 0, 1, &numFiles, &fileList);

			if (iRet != VAL_NO_FILE_SELECTED)
			{
				DeleteTableRows (panel, PANEL_MODE_TABLE_SCRIPT, 1, -1);
			
				if (fileList) 
				{
					InsertTableRows (panel, PANEL_MODE_TABLE_SCRIPT, 1, numFiles, VAL_CELL_STRING);    
			     /* Using for loop to iterate through selected files */
			     for (i=0; i<numFiles; ++i) 
				 {
			       	cell.y = i+1;
					cell.x = 3;
					SetTableCellVal (GiPanel, PANEL_MODE_TABLE_SCRIPT, cell, fileList [i]);
					SplitPath( fileList [i],NULL,NULL,sFileName);
					cell.x = 1;
					SetTableCellVal (GiPanel, PANEL_MODE_TABLE_SCRIPT, cell, sFileName);
			       free (fileList [i]);
			       fileList [i] = NULL;
			     }
			     free (fileList);
			     fileList = NULL;
			   }

			}
		break;
	}
}

// DEBUT ALGO
//****************************************************************************** 
//int CVICALLBACK QuitterModeAuto (int panel, int control, int event,
//		void *callbackData, int eventData1, int eventData2)
//****************************************************************************** 
//	- Param�tres CVI
//
//  - Quitte l'�cran d'essai
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
// FIN ALGO
void CVICALLBACK Quitter (int menuBar, int menuItem, void *callbackData,
		int panel)
{
int iStatus;

	SetGbQuitter(1);
	SetGiEtat(iETAT_ATTENTE_AFFICH_IHM); 
	
	// Inactivation de la g�che
	SetGiErrUsb6008(Usb6008CommandeOuvertureGache (iUSB6008_CMDE_OUVERTURE_GACHE_INACTIVE));

	// S'il n'y a pas d'erreur
	if(GetGiErrUsb6008() == 0){
		SetGbGacheActive(iGACHE_FERMEE);
		SetCtrlAttribute (panel, PANEL_MODE_BUTT_OUV_GACHE, ATTR_LABEL_TEXT, "Open Electric Lock");
	}
	
	// Arr�t de la ventilation moteur
	SetGiErrUsb6008(Usb6008CommandeVentilationMoteur (iUSB6008_CMDE_VENTILATION_MOTEUR_INACTIFS)); 

	if(GbThreadPoolActive){
		// Attente d'arr�t du Thread de gestion des cycles
		iStatus = CmtWaitForThreadPoolFunctionCompletion (DEFAULT_THREAD_POOL_HANDLE , GiThreadCycleVitesse,OPT_TP_PROCESS_EVENTS_WHILE_WAITING);
		iStatus = CmtReleaseThreadPoolFunctionID (DEFAULT_THREAD_POOL_HANDLE , GiThreadCycleVitesse);

		iStatus = CmtWaitForThreadPoolFunctionCompletion (DEFAULT_THREAD_POOL_HANDLE , GiThreadCyclePression, OPT_TP_PROCESS_EVENTS_WHILE_WAITING);
		iStatus = CmtReleaseThreadPoolFunctionID (DEFAULT_THREAD_POOL_HANDLE , GiThreadCyclePression);

		iStatus = CmtWaitForThreadPoolFunctionCompletion (DEFAULT_THREAD_POOL_HANDLE, GiThreadGestionSecurite, OPT_TP_PROCESS_EVENTS_WHILE_WAITING);
		iStatus = CmtReleaseThreadPoolFunctionID (DEFAULT_THREAD_POOL_HANDLE, GiThreadGestionSecurite);
		
		iStatus = CmtWaitForThreadPoolFunctionCompletion (DEFAULT_THREAD_POOL_HANDLE , GiThreadCycleRun,OPT_TP_PROCESS_EVENTS_WHILE_WAITING);
		iStatus = CmtReleaseThreadPoolFunctionID (DEFAULT_THREAD_POOL_HANDLE , GiThreadCycleRun);
		
		iStatus = CmtWaitForThreadPoolFunctionCompletion (DEFAULT_THREAD_POOL_HANDLE , GiThreadCycleAnum,OPT_TP_PROCESS_EVENTS_WHILE_WAITING);
		iStatus = CmtReleaseThreadPoolFunctionID (DEFAULT_THREAD_POOL_HANDLE , GiThreadCycleAnum);
		//iStatus = CmtWaitForThreadPoolFunctionCompletion (GiThreadPoolHandleAcquisitions, GiThreadAcquisitions, OPT_TP_PROCESS_EVENTS_WHILE_WAITING);
		//iStatus = CmtReleaseThreadPoolFunctionID (GiThreadPoolHandleAcquisitions, GiThreadAcquisitions);
		//iStatus = CmtDiscardThreadPool (GiThreadPoolHandleAcquisitions);		
		
		DiscardAsyncTimer (-1);
		GiThreadAcquisitions = 0;

		GbThreadPoolActive = 0;
		//----------------------------
		//----------------------------
	}
	
	InitAnum(FALSE);
	
	// Effacement de la zone de messages
	ZoneMessageSaturee(GiPanel, PANEL_MODE_MESSAGES_MODE, sNOM_LIBRAIRIE, 1);
	// Programmation du retour Ihm
	PostDeferredCall ((DeferredCallbackPtr) GFonctionRetourIhm, &GiEvtRetourIhm);		
	// Fermeture du panel
	HidePanel (GiPanel);
}

// DEBUT ALGO
//****************************************************************************** 
// int SetUnitVitesse(int iPanel, int iControl)
//****************************************************************************** 
//	- int iPanel	: Handle du panel
//	  int iControl	: Handle du contr�le
//
//  - Changement de l'unit� de vitesse
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
// FIN ALGO
int SetUnitVitesse(int iPanel, int iControl)
{
char sUnit[100];
char sAffich[100];
int iErr;
int iNbRows;
Rect rect;

	// Recopie des donn�es du tableau de donn�es vers la data grid
	GetNumTableRows (iPanel, PANEL_MODE_TABLE_VITESSES, &iNbRows);
	rect.height = iNbRows;
	rect.left 	= 1;
	rect.top 	= 1;
	rect.width 	= 1;

	switch(GetGiUnitVitesse()){
		case iUNIT_KM_H:
			strcpy(sUnit, sUNIT_VIT_KM_H);
			strcpy(sAffich, sAFFICH_VITESSE_KM_H);
		break;
		case iUNIT_G:
			strcpy(sUnit, sUNIT_VIT_G);
			strcpy(sAffich, sAFFICH_VITESSE_G);
		break;
		case iUNIT_TRS_MIN:
			strcpy(sUnit, sUNIT_VIT_TRS_MIN);
			strcpy(sAffich, sAFFICH_VITESSE_TRS_MIN);
		break;
	}

	// Mise � jour des libell�s
	iErr = SetTableColumnAttribute (iPanel, PANEL_MODE_TABLE_VITESSES, 	1,ATTR_LABEL_TEXT, 	sUnit);
	iErr = SetCtrlAttribute (iPanel, PANEL_MODE_AFFICH_VITESSE, 		ATTR_LABEL_TEXT, 	sAffich);
	iErr = SetCtrlAttribute (iPanel, PANEL_MODE_GRAPHE_VITESSE, 		ATTR_YNAME, 		sAffich);
	iErr = SetCtrlAttribute (iPanel, PANEL_MODE_SAISIE_VITESSE_MANU, 	ATTR_LABEL_TEXT, 	sAffich);
	iErr = SetCtrlAttribute (GiStatusPanel, PANEL_STAT_SPEED, 			ATTR_LABEL_TEXT, 	sAffich);
	iErr = SetCtrlVal 		(iPanel, PANEL_MODE_UNIT_VITESSE, 			sUnit);	

	// Recopie des donn�es du tableau de donn�es vers la data grid   
	SetTableCellRangeVals (iPanel, PANEL_MODE_TABLE_VITESSES, rect, GstTabVitesse.dVit, VAL_COLUMN_MAJOR);

	/*if (GetGiMode() == iMODE_AUTOMATIQUE){
		// Mise � jour du graphique (uniquement en mode automatique)
		GstGrapheMajGrapheVit(iPanel, PANEL_MODE_TABLE_VITESSES, PANEL_MODE_GRAPHE_VITESSE, 1, GstTabVitesse.dDuree, GstTabVitesse.dVit, GstTabVitesse.iNbElmts, 1, iCOUL_CONS_VITESSE, 1);
	}  */
	
	return 0;//OK
}

// DEBUT ALGO
//****************************************************************************** 
// int SetUnitPression(int iPanel, int iControl)
//****************************************************************************** 
//	- int iPanel	: Handle du panel
//	  int iControl	: Handle du contr�le
//
//  - Changment de l'unit� de pression
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
// FIN ALGO
int SetUnitPression(int iPanel, int iControl)
{
char sUnit[100];      
char sAffich[100];    
int iErr;
int iNbRows;
Rect rect;

	// Recopie des donn�es du tableau de donn�es vers la data grid
	GetNumTableRows (iPanel, PANEL_MODE_TABLE_PRESSION, &iNbRows);
	rect.height = iNbRows;
	rect.left 	= 1;
	rect.top 	= 1;
	rect.width 	= 1;
	
	switch(GetGiUnitPression()){
		case iUNIT_KPA:
			strcpy(sUnit, sUNIT_PRES_KPA);
			strcpy(sAffich, sAFFICH_PRES_KPA);
		break;
		case iUNIT_BAR:
			strcpy(sUnit, sUNIT_PRES_BAR);
			strcpy(sAffich, sAFFICH_PRES_BARS);
		break;
		case iUNIT_MBAR:
			strcpy(sUnit, sUNIT_PRES_MBAR);
			strcpy(sAffich, sAFFICH_PRES_MBAR);
		break;
		case iUNIT_PSI:
			strcpy(sUnit, sUNIT_PRES_PSI);
			strcpy(sAffich, sAFFICH_PRES_PSI);
		break;
	} 
	
	iErr = SetTableColumnAttribute (iPanel, PANEL_MODE_TABLE_PRESSION, 1,	ATTR_LABEL_TEXT, 	sUnit);
	iErr = SetCtrlAttribute (iPanel, PANEL_MODE_AFFICH_PRESS, 				ATTR_LABEL_TEXT, 	sAffich);
	iErr = SetCtrlAttribute (iPanel, PANEL_MODE_GRAPHE_PRESSION, 			ATTR_YNAME, 		sAffich);
	iErr = SetCtrlAttribute (iPanel, PANEL_MODE_SAISIE_PRESSION_MANU, 		ATTR_LABEL_TEXT, 	sAffich);
	iErr = SetCtrlAttribute (GiStatusPanel, PANEL_STAT_PRESSURE, 			ATTR_LABEL_TEXT, 	sAffich);
	iErr = SetCtrlVal (iPanel, PANEL_MODE_UNIT_PRESSION, 					sUnit);
	
	// Recopie des donn�es du tableau de donn�es vers la data grid
	SetTableCellRangeVals (iPanel, PANEL_MODE_TABLE_PRESSION, rect, GstTabPression.dPress, VAL_COLUMN_MAJOR);	
	
	return 0; // OK
}

// DEBUT ALGO
//****************************************************************************** 
// int CreateRepResultIfNeeded(void)
//****************************************************************************** 
//	- Aucun
//
//  - Cr�ation du r�pertoire r�sultats si n�cessaire
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
// FIN ALGO
int CreateRepResultIfNeeded(void)
{
char sDateHeure[100];
int iErr;

	if (GsPathResult[0] == 0x00){
		iErr = GetProjectDir(GsPathResult);
		GstFilesGetStringDateHeure(sDateHeure);
		
		strcat(GsPathResult, "\\");
		strcat(GsPathResult, sREP_RESSULTATS"\\");
		strcat(GsPathResult, sDateHeure);
		
		// Cr�ation du r�pertoire des r�sultats
		iErr= MakeDir (GsPathResult);
	}
	
	return 0; //OK
}

// DEBUT ALGO
//****************************************************************************** 
//int CVICALLBACK BoutonVitesse (int panel, int control, int event,
//		void *callbackData, int eventData1, int eventData2)
//****************************************************************************** 
//	- Param�tres CVI
//
//  - Gestion du bouton de d�part/arr�t cycle de vitesse
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
// FIN ALGO
int CVICALLBACK BoutonVitesse (int panel, int control, int event,
				void *callbackData, int eventData1, int eventData2)
{
char sTitle[200];
int iNumberOfRows;
int iErr;
int iYes;

	switch (event){
		case EVENT_COMMIT:
			// Si le cycle de vitesse est en cours
			if (GetGiStartCycleVitesse()	== 1)
				iYes = ConfirmPopup ("Warning", "Are you sure you want to stop Test?");
		
			if (GetGiStartCycleVitesse() == 1){
				if(iYes){
					// Arr�t de la t�che d'acquisition
					//SetAsyncTimerAttribute (GiThreadAcquisitions, ASYNC_ATTR_ENABLED, 0);
	
					iErr = GstIhmCycles(panel,0,  0, GetGiStartCyclePression());						
					SetGiStartCycleVitesse(0);
					// Remise � z�ro du handle de fichier r�sultats
					//SetGiHandleFileResult(-1);
				}
			}
			else{
					if (GetGiMode() == iMODE_AUTOMATIQUE){
						// D�termination du nombre de lignes du contr�le (data grid)
						iErr = GetNumTableRows (panel, PANEL_MODE_TABLE_VITESSES, &iNumberOfRows);

						if(strlen(GsPathConfigFile) == 0){
							iErr = -1;
							CHECK_ERROR(iErr, "Error", sMSG_SAVE_DATA_ON_FILE)  
							return 0;
						}
					}
					else
						iNumberOfRows = 2;
				
					if (iNumberOfRows >= 2){
						// Commande de la ventilation forc�e avant de lancer un cycle moteur
						SetGiErrUsb6008(Usb6008CommandeVentilationMoteur (iUSB6008_CMDE_VENTILATION_MOTEUR_ACTIFS));

						// Initialisations
						SetGdDurEcoulEssaiSpeed(0.0);
						SetGiIndexStepVitesse(1);
						SetGiIndexCycleVitesse(1);						
				
						// Lancement du cycle de vitesse
						SetGiStartCycleVitesse(1);
						
						// Lancement de la t�che d'acquisition
						SetAsyncTimerAttribute (GiThreadAcquisitions, ASYNC_ATTR_ENABLED, 1);
					}
					else{
							// On ne peut pas lancer le cycle de vitesse
							ModesAddMessageZM(sMSG_CANT_START_SPEED_CYCLE);
						}
				
					iErr = GstIhmCycles(panel,GetGiStartVitPress(),  GetGiStartCycleVitesse(), GetGiStartCyclePression());						
				}
				
		break;
	}
	return 0;
}

int CVICALLBACK BoutonExecution (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	char sTpsEcoule[50];
	int iErr;
	int rowNo=0;
	
		switch (event){
		case EVENT_COMMIT:
		
			GetNumTableRows(GiPanel, PANEL_MODE_TABLE_SCRIPT,&rowNo);
			if(rowNo<=0)
				return 0;
			//LoadTest(str,panel);
			GetCtrlAttribute (GiPanel, PANEL_MODE_BUT_START_RUN, ATTR_LABEL_TEXT, sTpsEcoule); 
			if(strcmp("Execute",sTpsEcoule)==0)
			{
				SetCtrlAttribute (GiPanel, PANEL_MODE_BUT_START_RUN, ATTR_LABEL_TEXT, "Stop");  
				SetGiStartCycleRun(1); 
			}
			else
			{
				SetCtrlAttribute (GiPanel, PANEL_MODE_BUT_START_RUN, ATTR_LABEL_TEXT, "Execute");
					SetGiStartCycleRun(0); 
			}
			return 0;  
				
		
			SetGiErrUsb6008(Usb6008CommandeVentilationMoteur (iUSB6008_CMDE_VENTILATION_MOTEUR_ACTIFS));

						// Initialisations
						SetGdDurEcoulEssaiSpeed(0.0);
						SetGiIndexStepVitesse(1);
						SetGiIndexCycleVitesse(1);						
				
						// Lancement du cycle de vitesse
						SetGiStartCycleVitesse(1);
						
				SetAsyncTimerAttribute (GiThreadAcquisitions, ASYNC_ATTR_ENABLED, 1);
				iErr = GstIhmCycles(panel,GetGiStartVitPress(),  GetGiStartCycleVitesse(), GetGiStartCyclePression());	
		break;
	  }

	return 0;
}
// DEBUT ALGO
//****************************************************************************** 
//int CVICALLBACK BoutonPression (int panel, int control, int event,
//		void *callbackData, int eventData1, int eventData2)
//****************************************************************************** 
//	- Param�tres CVI
//
//  - Gestion du bouton de d�part/arr�t cycle de pression
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
// FIN ALGO

int CVICALLBACK BoutonPression (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
char sTitle[200];
int iNumberOfRows;	
int iErr;
int iYes;

	switch (event){
		case EVENT_COMMIT: 
			// Si le cycle de pression est en cours
			if (GetGiStartCyclePression() == 1)
				iYes = ConfirmPopup ("Warning", "Are you sure you want to stop Test?");

			if (GetGiStartCyclePression() == 1){
				if(iYes){
					// Arr�t de la t�che d'acquisition
					//SetAsyncTimerAttribute (GiThreadAcquisitions, ASYNC_ATTR_ENABLED, 0);

					iErr = GstIhmCycles(panel,GetGiStartVitPress(),  GetGiStartCycleVitesse(), 0);						

					SetGiStartCyclePression(0);
				}
			}
			else{
					 	
						if (GetGiMode() == iMODE_AUTOMATIQUE){
							// D�termination du nombre de lignes du tableau des pressions
							iErr = GetNumTableRows (panel, PANEL_MODE_TABLE_PRESSION, &iNumberOfRows);
					
							if(strlen(GsPathConfigFile) == 0){
								iErr = -1;
								CHECK_ERROR(iErr, "Error", sMSG_SAVE_DATA_ON_FILE)
								return 0;
							}
						}
						else
							iNumberOfRows = 2;
					
						if (iNumberOfRows >= 2){
							// Lancement du cycle de pression
							SetGiStartCyclePression(1);
					
							// Initialisations
							SetGdPression(0.0);						
							SetGdDurEcoulEssaiPress(0.0);
							SetGiIndexStepPression(1);
							SetGiIndexCyclePression(1);						
							
							// Lancement de la t�che d'acquisition
							SetAsyncTimerAttribute (GiThreadAcquisitions, ASYNC_ATTR_ENABLED, 1);
						}
						else{
								// On ne peut pas lancer le cycle de pression
								ModesAddMessageZM(sMSG_CANT_START_PRESS_CYCLE);
							}
						iErr = GstIhmCycles(panel, GetGiStartVitPress(), GetGiStartCycleVitesse(), GetGiStartCyclePression());
				}
		break;
	}
	return 0;
}

// DEBUT ALGO
//****************************************************************************** 
//int CVICALLBACK BoutonCyclesVitessePress (int panel, int control, int event,
//		void *callbackData, int eventData1, int eventData2)
//****************************************************************************** 
//	- Param�tres CVI
//
//  - Gestion de l'appui sur le bouton des cycles de vitesse et pression
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
// FIN ALGO
int CVICALLBACK BoutonCyclesVitessePress (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
char sTitle[200];
int iNumberOfRowsPress;
int iNumberOfRowsSpeed;
int iErr;
int iYes;

	switch (event){
		case EVENT_COMMIT:
			// Si les cycles de vitesse et pression sont en cours
			if ((GetGiStartCycleVitesse() == 1) || (GetGiStartCyclePression() == 1) || (GetGiStartVitPress() == 1))
				iYes = ConfirmPopup ("Warning", "Are you sure you want to stop Test?");
		 
			if (GetGiStartVitPress() == 1){
				if(iYes){
					iErr = GstIhmCycles(panel,0,  0, 0);						

					// Arr�t de la t�che d'acquisition
					//SetAsyncTimerAttribute (GiThreadAcquisitions, ASYNC_ATTR_ENABLED, 0);
					
					SetGiStartCycleVitesse(0);
					SetGiStartCyclePression(0);
					SetGiStartVitPress(0);					
				}
			}
			else
				if ((GetGiStartCycleVitesse() == 0) && (GetGiStartCyclePression() == 0) && (GetGiStartVitPress() == 0)){
						if (GetGiMode() == iMODE_AUTOMATIQUE){
							if(strlen(GsPathConfigFile) == 0){
								iErr = -1;
								CHECK_ERROR(iErr, "Error", sMSG_SAVE_DATA_ON_FILE)  
								return 0;
							}
					
							// D�termination du nombre de lignes du tableau des pressions
							iErr = GetNumTableRows (panel, PANEL_MODE_TABLE_PRESSION, &iNumberOfRowsPress);
							// D�termination du nombre de lignes du tableau des vitesses
							iErr = GetNumTableRows (panel, PANEL_MODE_TABLE_VITESSES, &iNumberOfRowsSpeed); 
						}
						else{
								iNumberOfRowsPress = 2;
								iNumberOfRowsSpeed = 2;
							}
					
						// Si le nombre de lignes des deux tableaux est sup�rieur � deux
						if ((iNumberOfRowsPress >= 2) && (iNumberOfRowsSpeed >= 2)){
							// Commande de la ventilation forc�e avant de lancer un cycle moteur
							SetGiErrUsb6008(Usb6008CommandeVentilationMoteur (iUSB6008_CMDE_VENTILATION_MOTEUR_ACTIFS));

							// Initialisations
							SetGdDurEcoulEssaiSpeed(0.0);
							SetGdDurEcoulEssaiPress(0.0);
							SetGiIndexStepPression(1);
							SetGiIndexCyclePression(1);						
							SetGiIndexStepVitesse(1);
							SetGiIndexCycleVitesse(1);
					
							SetGiStartCycleVitesse(1);
							SetGiStartCyclePression(1);
							SetGiStartVitPress(1);
							
							// Lancement de la t�che d'acquisition
							SetAsyncTimerAttribute (GiThreadAcquisitions, ASYNC_ATTR_ENABLED, 1);
						}
						else{
								// On ne peut pas lancer le cycle de pression
								if (iNumberOfRowsPress < 2){
									ModesAddMessageZM(sMSG_CANT_START_PRESS_CYCLE);
								}
						
								// On ne peut pas lancer le cycle de vitesse
								if (iNumberOfRowsSpeed < 2){
									ModesAddMessageZM(sMSG_CANT_START_SPEED_CYCLE);							
								}
							}
						
						iErr = GstIhmCycles(panel, GetGiStartVitPress(), GetGiStartCycleVitesse(), GetGiStartCyclePression());
				}
		break;
	}
	return 0;
}


// DEBUT ALGO
//****************************************************************************** 
//int DisplaySegmentActifGraph(int iPanel, int iControlIdTable, int iControlIdGraphe, 
//							 int iStep, int iNbMaxSteps, int iNumCycle, int iColor, 
//							 int *ptiSelectionHandle)
//****************************************************************************** 
//	- int iPanel				: Handle du panel
//	  int iControlIdTable   	: Handle vers la table de donn�es utilis�e
//	  int iControlIdGraphe  	: Handle vers le graphique � utiliser
//	  int iStep				 	: Num�ro de step s�lectionn�
//	  int iNbMaxSteps			: Nombre maximal de steps
//	  int iNumCycle				: Num�ro de cycle en cours
//	  int iColor			 	: Couleur � appliquer au step s�lectionn�
//	  int *ptiSelectionHandle	: Handle de la s�lection (pour effacement futur)
//
//  - Affichage du segment actif sur le graphique
//
//  - 0 si OK, sinon code d'erreur
//****************************************************************************** 
// FIN ALGO
int DisplaySegmentActifGraph(int iPanel, int iControlIdTable, int iControlIdGraphe, 
							 int iStep, int iNbMaxSteps, int iNumCycle, int iColor, 
							 int *ptiSelectionHandle)
{
Point pCell1;
Point pCell2;
double dDuree;
double dValY;
double dX1;
double dY1;
double dX2;
double dY2;
int i;

	dDuree = 0.0;
	pCell1.x = 1;
	pCell1.y = iStep;
	pCell2.x = 2;	
	// Ajout de toutes les dur�es
	for(i=1; i<=pCell1.y; i++){
		pCell2.y = i;
		GetTableCellVal (iPanel, iControlIdTable, pCell2, &dValY);
		dDuree += dValY;
	}

	//---- Colonne des valeurs (vitesse ou pression) ------
	pCell1.x = 1;
	pCell1.y = iStep;
	// Lecture de la valeur en Y de la cellule s�lectionn�e
	GetTableCellVal (iPanel, iControlIdTable, pCell1, &dValY);

	// Effacement de la derni�re s�lection sur le graphique
	if (*ptiSelectionHandle != 0)
		DeleteGraphPlot (iPanel, iControlIdGraphe, *ptiSelectionHandle, VAL_IMMEDIATE_DRAW);
		
	dX2 = dDuree;
	dY2 = dValY; 

	pCell1.x = 2;
	// Lecture de la valeur en Y de la cellule s�lectionn�e
	GetTableCellVal (iPanel, iControlIdTable, pCell1, &dValY);

	
	dX1 = dDuree - dValY;		

	// Colonne des donn�es (vitesse ou pression)
	pCell1.x = 1;
	
	// Si la valeur de la ligne est correcte
	if (pCell1.y > 1){
		pCell1.y -= 1;
		//CHECK_TAB_INDEX("7", pCell1.y, 0, 5000)
		// Lecture de la valeur en Y de la cellule s�lectionn�e
		GetTableCellVal (iPanel, iControlIdTable, pCell1, &dValY);
	}
	else
		dValY = 0.0;

	dY1 = dValY;					
	
	if (iStep == 1){
		dX1	= 0;
		dY1	= dY2;
	}
	
	// S'il y a plus d'un pixel de diff�rence entre le point de d�part et le point d'arriv�e
	if ((abs(dX2 - dX1) >= 1.0) || (abs(dY2 - dY1)>= 1.0)){ 
		if(iStep == 1){
				// Traitement particulier pour le premier cycle
				if(iNumCycle == 1){
					dY1 = 0.0;
				}
				else{
						// Traitement particulier pour les autres cycles
						pCell1.x = 1;
						pCell1.y = iNbMaxSteps;
						// Lecture de la valeur en Y de la cellule s�lectionn�e
						GetTableCellVal (iPanel, iControlIdTable, pCell1, &dY1);						
					}
		}

		// Trac� d'une ligne
		*ptiSelectionHandle = PlotLine (iPanel, iControlIdGraphe, dX1, dY1, dX2, dY2, iColor);
	
		// Sauvegarde du handle du graphique de la derni�re s�lection
		SetGiControlGrapheSelection(iControlIdGraphe);
	
		// Taille du segment de droite = 3 pixels
		SetPlotAttribute (GiPanel, iControlIdGraphe, *ptiSelectionHandle, ATTR_PLOT_THICKNESS, 3);
		SetPlotAttribute (GiPanel, iControlIdGraphe, *ptiSelectionHandle, ATTR_TRACE_COLOR, iColor);
	}
	
	return 0; // OK
}

//--------------------------------------------


// DEBUT ALGO
//***************************************************************************
//int CalcParamVitesse(double dVitDep, double dVitFin, double dDuree, double *ptdProgVitDep, double *ptdProgVitFin, 
//					double *ptDureeProg, BOOL *ptbMarcheAvant, BOOL *ptbRampe, BOOL *ptbAttendreConsAtteinte)
//***************************************************************************
//  - double dVitDep				: Consigne Vitesse de d�part (en trs/min)
//	  double dVitFin				: Consigne Vitesse d'arriv�e (en trs/min)
//	  double *ptdProgVitDep			: Vitesse de d�part � programmer (en trs/min)
//	  double *ptdProgVitFin			: Vitesse d'arriv�e � programmer (en trs/min)
//	  double *ptDureeProg			: Dur�e du step (en secondes)
//	  BOOL *ptbMarcheAvant			: TRUE = Marche avant, sinon,marche arri�re
//	  BOOL *ptbRampe				: TRUE: Une rampe doit �tre g�n�r�e, sinon, 
//										simple programmation de la vitesse
//	  BOOL *ptbAttendreConsAtteinte : TRUE = attendre la lev�e du flag de consigne atteinte
//
//  - Calcul du param�trage du moteur pour un step
//
//  - 1 si probl�me d�tect�, 0 sinon
//***************************************************************************
// FIN ALGO
int CalcParamVitesse(double dVitDep, double dVitFin, double dDuree, double *ptdProgVitDep, double *ptdProgVitFin, 
					double *ptDureeProg, BOOL *ptbMarcheAvant, BOOL *ptbRampe, BOOL *ptbAttendreConsAtteinte)
{
double dPente;
double dCste;
char sMsg[800];
double dTimeElapsed;
	
	if (dVitDep != dVitFin)
		*ptbRampe = 1;
	else
		*ptbRampe = 0;
	
	// La dur�e ne doit pas �tre inf�rieure � z�ro
	if (dDuree < 0.0001)
		dDuree = 0.0001;
		
	//CHECK_VAL("1", dDuree, 0.0001, 1000.0)
			
	if (((dVitDep > 0.0) && (dVitFin < 0.0)) || ((dVitDep < 0.0) && (dVitFin > 0.0))){
		// Si les signes de vitesse sont diff�rents
		*ptdProgVitDep = dVitDep;
		*ptdProgVitFin = 0.0;
		
		dPente = (dVitFin - dVitDep) / dDuree;
		dCste = dVitDep;
	
		// Contr�le de la pente
		if(fabs(dPente) > 0.0001)
			*ptDureeProg = (- dCste) / dPente;
		else
			*ptDureeProg = dDuree;
		
		// Contr�le de la valeur de dur�e
		if(*ptDureeProg < 0.0001)
			*ptDureeProg = 0.0001;
		else
			if(*ptDureeProg > dDuree)
				*ptDureeProg = dDuree; 
		
		// Il faut attendre que le moteur soit arr�tt� avant de continuer
		*ptbAttendreConsAtteinte = 1;
	}
	else{
			*ptdProgVitDep 	= dVitDep;
			*ptdProgVitFin 	= dVitFin; 
			*ptDureeProg 	= dDuree;
			*ptbAttendreConsAtteinte = 0;
		}

	if ((*ptdProgVitDep >= 0.0) && (*ptdProgVitFin >= 0.0))
		*ptbMarcheAvant = 1;
	else
		*ptbMarcheAvant = 0;	
	
	//---- Modification du 04/04/2013 par CB -- DEBUT -----
	dTimeElapsed = (double)((clock() - GetGiTimeDepartEssaiPress())) / ((double)CLOCKS_PER_SEC);
	sprintf(sMsg, "dTimeElapsed = %.02f,  dVitDep=%.03f, dVitFin=%.03f, dDuree=%.03f,  ptdProgVitDep=%.03f,  ptdProgVitFin=%.03f,ptDureeProg=%.03f,  ptbMarcheAvant=%d,  ptbRampe=%d,  ptbAttendreConsAtteinte=%d", 
  					dTimeElapsed, dVitDep, dVitFin, dDuree, *ptdProgVitDep, *ptdProgVitFin, 
					*ptDureeProg, *ptbMarcheAvant, *ptbRampe, *ptbAttendreConsAtteinte);
					
	ModesAddMessageZM(sMsg);		
	
	//---- Modification du 04/04/2013 par CB -- FIN -----
	
	return 0; // OK
}

// DEBUT ALGO
//***************************************************************************
//int ProgRampeVariateur(BOOL bConvert, stConfig *ptstConfig, double dVitDep, double dVitFin, 
//						double dDuree, int iUnitVitesse)
//***************************************************************************
//  - Bool *ptwConsigneAtteinte: 1 = attendre atteinte consigne, sinon 0
//	  BOOL bConvert			 : 1 = Appliquer les coefficients de conversion
//	  stConfig *ptstConfig   : Pointeur vers les param�tres de configuration
//	  double dVitDep		 : Vitesse de d�part de la rampe
//	  double dVitFin		 : Vitesse de fin de la rampe
//	  double dDuree			 : Dur�e de la rampe
//	  int iUnitVitesse		 : Unit� de vitesse
//
//  - Programmation d'une rampe sur le variateur
//
//  - 1 si probl�me d�tect�, 0 sinon
//***************************************************************************
// FIN ALGO
int ProgRampeVariateur(BOOL bAttConsAtteinte, BOOL bConvert, stConfig *ptstConfig, double dVitDep, double dVitFin, 
						double dDuree, int iUnitVitesse)
{
double dProgVitDep;
double dProgVitFin;
int iErrVaria;
int iNbEssais;
char sMsg[1000];
double dTimeElapsed;

	if(bConvert){
		switch(iUnitVitesse){
			case iUNIT_KM_H:
				dProgVitDep = dVitDep * ptstConfig->dCoeffAKmH + ptstConfig->dCoeffBKmH;
				dProgVitFin = dVitFin * ptstConfig->dCoeffAKmH + ptstConfig->dCoeffBKmH;
			break;
			case iUNIT_G:	  
				dProgVitDep = (60 * sqrt(fabs(dVitDep) * ptstConfig->dCoeffAG * dGRAVITE)) / (2 * dPI * ptstConfig->dCoeffAG);
				dProgVitFin = (60 * sqrt(fabs(dVitFin) * ptstConfig->dCoeffAG * dGRAVITE)) / (2 * dPI * ptstConfig->dCoeffAG);
				
				if(dVitDep < 0.0) dProgVitDep *= -1;
				if(dVitFin < 0.0) dProgVitFin *= -1; 
			break;
			case iUNIT_TRS_MIN:
				dProgVitDep = dVitDep;
				dProgVitFin = dVitFin;
			break;
		}
	}
	else{
			dProgVitDep = dVitDep;
			dProgVitFin = dVitFin;	
		}
	
	
	iErrVaria = 0;
	
	//----- Modif du 01/02/2012 par CB ---- DEBUT -------
	if(dDuree < 0.4)
		dDuree = 0.4;	 
	//----- Modif du 01/02/2012 par CB ---- FIN -------

	iNbEssais = 0;
	do{
		if(iNbEssais > 0)
			Delay(0.05);
		iErrVaria = VariateurProgrammationRampe ((float)dProgVitDep, (float)dProgVitFin, dDuree);
		iNbEssais++;
	}while ((iErrVaria == 1) && (iNbEssais < iNB_REESSAIS_DIAL_VARIAT));

	//--------- Modification du 04/04/2013 par CB --- DEBUT ----
	dTimeElapsed = (double)((clock() - GetGiTimeDepartEssaiPress())) / ((double)CLOCKS_PER_SEC);
	sprintf(sMsg, "dTimeElapsed=%.02f, bAttConsAtteinte=%d, bConvert=%d Vit dep=%f, Vit Fin=%f, Dur�e=%f, dVitDep(G)=%f, dVitFin(G)=%f", 
					dTimeElapsed, bAttConsAtteinte, bConvert, dProgVitDep, dProgVitFin, dDuree, dVitDep, dVitFin);
	ModesAddMessageZM(sMsg);	
	//--------- Modification du 04/04/2013 par CB --- FIN ----
	
	return iErrVaria;
}

// DEBUT ALGO
//***************************************************************************
// int CmdeVitesseVariateur(stConfig *ptstConfig, double dVitesse, int iSens, int iUnitVitesse)
//***************************************************************************
//  - stConfig *ptstConfig	: Pointeur vers les param�tres de configuration
//	  double dVitesse		: Vitesse � programmer
//	  int iSens				: Sens de rotation du moteur
//	  int iUnitVitesse		: Unit� de vitesse utilis�e
//
//  - Conversion et programmation de la vitesse � atteindre
//
//  - 1 si probl�me d�tect�, 0 sinon
//***************************************************************************
// FIN ALGO
int CmdeVitesseVariateur(stConfig *ptstConfig, double dVitesse, int iSens, int iUnitVitesse)
{
char sMsg[500];
double dProgVit;
int iNbEssais;
int iErrVaria;

	switch(iUnitVitesse){
		case iUNIT_KM_H:
			dProgVit = dVitesse * ptstConfig->dCoeffAKmH + ptstConfig->dCoeffBKmH;
		break;
		case iUNIT_G:
			dProgVit = (60 * sqrt(fabs(dVitesse) * ptstConfig->dCoeffAG * dGRAVITE)) / (2 * dPI * ptstConfig->dCoeffAG);
			
			if(dVitesse < 0.0) 
				dProgVit *= -1;
		break;
		case iUNIT_TRS_MIN:
			dProgVit = dVitesse;
		break;	   
	}

	iNbEssais = 0;
	do{
		if(iNbEssais > 0)
			Delay(0.05);

		if (iSens == iVARIATEUR_MARCHE_AVANT)
			//  Emission consigne de vitesse et mise en route du variateur
			iErrVaria = VariateurCommandeVitesse ((float)dProgVit, iVARIATEUR_MARCHE_AVANT);
		else
			iErrVaria = VariateurCommandeVitesse ((float)dProgVit, iVARIATEUR_MARCHE_ARRIERE);
			iNbEssais++;
	}while ((iErrVaria == 1) && (iNbEssais < iNB_REESSAIS_DIAL_VARIAT));
	
	return iErrVaria; 
}

// DEBUT ALGO
//***************************************************************************
// int LectVitesse(stConfig *ptstConfig, float *ptfVitesse, int iUnitVitesse)
//***************************************************************************
//  - stConfig *ptstConfig	: Pointeur vers les param�tres de configuration
//	  float *ptfVitesse		: Vitesse lue (convertie � l'unit�e de vitesse de travail)
//	  int iUnitVitesse		: Unit� de vitesse utilis�e
//
//  - Lecture et conversion de la vitesse lue
//
//  - 1 si probl�me d�tect�, 0 sinon
//***************************************************************************
// FIN ALGO
int LectVitesse(stConfig *ptstConfig, float *ptfVitesse, int iUnitVitesse)
{
float fVitesseLue;
double dVitesseLue;
int iErrVaria;
int iNbEssais;
double dSigne=1.0;

	// Initialisation
	//*ptfVitesse = 0.0;

	iNbEssais = 0;
	do{
		if(iNbEssais > 0)
			Delay(0.05);

		// Lecture de la vitesse
		iErrVaria = VariateurMesureVitesse(&fVitesseLue);	
		iNbEssais++;
	}while ((iErrVaria == 1) && (iNbEssais < iNB_REESSAIS_DIAL_VARIAT));
	

	// Conversion de la vitesse
	switch(iUnitVitesse){
		case iUNIT_KM_H:
			dVitesseLue = (((double)(fVitesseLue)) - ptstConfig->dCoeffBKmH) / ptstConfig->dCoeffAKmH;
			// La valeur est en dehors des limites
			if ((dVitesseLue < ptstConfig->dLimMinKmH*2) || (dVitesseLue > ptstConfig->dLimMaxKmH*2))
				dVitesseLue = *ptfVitesse; 
		break;
		case iUNIT_G:
			if(fVitesseLue >= 0.0)
				dSigne = 1.0;
			else
				dSigne = -1.0;
				
			// Conversion trs/min en trs/secondes
			fVitesseLue = (fVitesseLue * 2 * dPI * ptstConfig->dCoeffAG) / 60.0;
			dVitesseLue = (fVitesseLue * fVitesseLue) / (ptstConfig->dCoeffAG * dGRAVITE);
			// La valeur est en dehors des limites
			if ((dVitesseLue < ptstConfig->dLimMinG*2) || (dVitesseLue > ptstConfig->dLimMaxG*2))
				dVitesseLue = *ptfVitesse; 
				
			dVitesseLue *= dSigne;
		break;
		case iUNIT_TRS_MIN:
			dVitesseLue = (double)fVitesseLue;
			// La valeur est en dehors des limites
			if ((dVitesseLue < ptstConfig->dLimMinTrsMin*2) || (dVitesseLue > ptstConfig->dLimMaxTrsMin*2))
				dVitesseLue = *ptfVitesse; 
		break;	   
	}

	// Mise � jour de la vitesse lue
	*ptfVitesse = (float)dVitesseLue;

	return iErrVaria; 
}

// DEBUT ALGO
//***************************************************************************
// int ProgPression(stConfig *ptstConfig, double dPression, int iUnitPression)
//***************************************************************************
//  - stConfig *ptstConfig   : Pointeur vers les param�tres de configuration
//	  double dPression		 : Pression � programmer
//	  int iUnitPression		 : Unit� de pression
//
//  - Conversion et programmation de la pression
//
//  - 1 si probl�me d�tect�, 0 sinon
//***************************************************************************
// FIN ALGO
int ProgPression(stConfig *ptstConfig, double dPression, int iUnitPression)
{
double dProgPression;

	switch(iUnitPression){
		case iUNIT_KPA:
			dProgPression = dPression * ptstConfig->dCoeffAKpa + ptstConfig->dCoeffBKpa;
		break;
		case iUNIT_BAR:
			dProgPression = dPression;
		break;
		case iUNIT_MBAR:
			dProgPression = dPression * ptstConfig->dCoeffAMbar + ptstConfig->dCoeffBMbar;
		break;
		case iUNIT_PSI:
			dProgPression = dPression * ptstConfig->dCoeffAPsi + ptstConfig->dCoeffBPsi;
		break;
	} 		

	SetGiErrUsb6008(Usb6008CommandePression (dProgPression));
	
	return GetGiErrUsb6008();
}

// DEBUT ALGO
//***************************************************************************
// int LectPression(stConfig *ptstConfig, double *ptdPression, int iUnitPression)
//***************************************************************************
//  - stConfig *ptstConfig   : Pointeur vers les param�tres de configuration
//	  double ptdPression	 : Pression lue (convertie � l'unit� de pression courante)
//	  int iUnitPression		 : Unit� de pression
//
//  - Lecture et conversion de la pression
//
//  - 1 si probl�me d�tect�, 0 sinon
//***************************************************************************
// FIN ALGO
int LectPression(stConfig *ptstConfig, double *ptdPression, int iUnitPression)
{
double dPressionConv;
double dPressionLue;	
	
	SetGiErrUsb6008(Usb6008MesurePression (&dPressionLue));
	
	switch(iUnitPression){
		case iUNIT_KPA:
			dPressionConv = (dPressionLue - ptstConfig->dCoeffBKpa) / ptstConfig->dCoeffAKpa;
			// La valeur est en dehors des limites
			if ((dPressionConv < ptstConfig->dLimMinKpa*2) || (dPressionConv > ptstConfig->dLimMaxKpa*2))
				dPressionConv = *ptdPression; 
		break;
		case iUNIT_BAR:
			dPressionConv = dPressionLue;
			// La valeur est en dehors des limites
			if ((dPressionConv < ptstConfig->dLimMinBar*2) || (dPressionConv > ptstConfig->dLimMaxBar*2))
				dPressionConv = *ptdPression; 
		break;
		case iUNIT_MBAR:
			dPressionConv = (dPressionLue - ptstConfig->dCoeffBMbar) / ptstConfig->dCoeffAMbar;
			// La valeur est en dehors des limites
			if ((dPressionConv < ptstConfig->dLimMinMbar*2) || (dPressionConv > ptstConfig->dLimMaxMbar*2))
				dPressionConv = *ptdPression; 
		break;
		case iUNIT_PSI:
			dPressionConv = (dPressionLue - ptstConfig->dCoeffBPsi) / ptstConfig->dCoeffAPsi;
			// La valeur est en dehors des limites
			if ((dPressionConv < ptstConfig->dLimMinPsi*2) || (dPressionConv > ptstConfig->dLimMaxPsi*2))
				dPressionConv = *ptdPression; 
		break;
	} 		
	
	*ptdPression = dPressionConv;

	return GetGiErrUsb6008();
}  

// DEBUT ALGO
//***************************************************************************
// int ConvLimPression(stConfig *ptstConfig, double *ptdPression, int iUnitPression)
//***************************************************************************
//	- double dPression	 	 : Pression lue
//	  int iUnitPression		 : Unit� de pression
//
//  - Conversion de lq pression li;ite
//
//  - Pression convertie
//***************************************************************************
// FIN ALGO
double ConvLimPression(double dPression, int iUnitPression)
{
double dPressionConv;

	switch(iUnitPression){
		case iUNIT_KPA:
			dPressionConv = (dPression - 0.0) / 0.01;
			// La valeur est en dehors des limites
			if ((dPressionConv < 0.0) || (dPressionConv > 2000*2.0))
				dPressionConv = dPression; 
		break;
		case iUNIT_BAR:
			dPressionConv = dPression;
			// La valeur est en dehors des limites
			if ((dPressionConv < 0) || (dPressionConv > 20*2.0))
				dPressionConv = dPression; 
		break;
		case iUNIT_MBAR:
			dPressionConv = (dPression - 0.0) / 0.001;
			// La valeur est en dehors des limites
			if ((dPressionConv < 0.0) || (dPressionConv > 20000*2.0))
				dPressionConv = dPression; 
		break;
		case iUNIT_PSI:
			dPressionConv = (dPression - 0.0) / 0.0689479236;
			// La valeur est en dehors des limites
			if ((dPressionConv < 0.0*2) || (dPressionConv > 225.02))
				dPressionConv = dPression; 
		break;
	} 		
	
	return dPressionConv;
}

// DEBUT ALGO
//***************************************************************************
//void LectEtAffichSpeedAndPress(BOOL bReadVit, BOOL bReadPress, int iPanel, int iStatusPanel, 
//								stConfig *ptstConfig, float *ptfVitesse, double *ptdPress, 
//								int iUnitVitesse, int iUnitPress, int *ptiErrorUsb, int *ptiErrVaria)
//***************************************************************************
//  - BOOL bReadVit   		: 1=Lecture de la vitesse, sinon 0
//	  BOOL bReadPress		: 1=Lecture de la pression, sinon 0
//	  int iPanel			: Handle du panel de d�roulement de l'essai
//	  int iStatusPanel		: Handle de status
//	  stConfig *ptstConfig  : Pointeur vers les donn�es de configuration
//	  float *ptfVitesse		: Vitesse lue
//	  double *ptdPress		: Pression lue
//	  int iUnitVitesse		: Unit� de vitesse
//	  int iUnitPress		: Unit� de pression
//	  int *ptiErrorUsb		: Code d'erreur USB6008
//	  int *ptiErrVaria		: Code d'erreur variateur
//
//  - Lecture de la vitesse et de la pression
//
//  - Aucun
//***************************************************************************
// FIN ALGO
void LectEtAffichSpeedAndPress(BOOL bReadVit, BOOL bReadPress, int iPanel, int iStatusPanel, 
								stConfig *ptstConfig, float *ptfVitesse, double *ptdPress, 
								int iUnitVitesse, int iUnitPress, int *ptiErrorUsb, int *ptiErrVaria)
{
	// Lecture de la vitesse
	if (bReadVit){
		*ptfVitesse = 0.0;

		// Lecture de la vitesse en temps r�el
		*ptiErrVaria = LectVitesse(ptstConfig, ptfVitesse, iUnitVitesse);
		#ifdef bSIMULATION		
			*ptfVitesse = GetGdVitesseAProg();// + ((double)(rand()*5)) / ((double)RAND_MAX);
		#endif
		if(*ptiErrVaria == 0){
			// Affichage de la vitesse sur le panel de status
			SetCtrlVal (iStatusPanel, PANEL_STAT_SPEED, *ptfVitesse);
			// Affichage de la vitesse sur le panel de d�roulement de l'essai
			SetCtrlVal (iPanel, PANEL_MODE_AFFICH_VITESSE, *ptfVitesse);
		}
	}
	
	// Lecture de la pression
	if (bReadPress){ 
		*ptdPress 	= 0.0;
		
		// Lecture de la pression en temps r�el
		*ptiErrorUsb = LectPression(ptstConfig, ptdPress, iUnitPress);
	
		#ifdef bSIMULATION		
			*ptdPress = GetGdPressionAProg();// + ((double)(rand()*0.2)) / ((double)RAND_MAX);
		#endif
		if(*ptiErrorUsb == 0){
			// Affichage de la pression sur le panel de status
			SetCtrlVal (iStatusPanel, PANEL_STAT_PRESSURE, *ptdPress);
			// Affichage de la pression sur le panel de d�roulement de l'essai
			SetCtrlVal (iPanel, PANEL_MODE_AFFICH_PRESS, *ptdPress);
		}
	}
}

// DEBUT ALGO
//***************************************************************************
//void PilotageMoteurModeAuto ()
//***************************************************************************
//  - 
//
//  - Pilotage du moteur en mode automatique
//
//  - 
//***************************************************************************
// FIN ALGO
void PilotageMoteurModeAuto (BOOL *ptbAttendreConsAtteinte, short *ptwConsigneAtteinte, BOOL *ptbReprogMoteur,
							double *ptdDureeRampe, int iTimeDepart, int iIndexStepVitesse, 
							double dDureePrevue, double dDureeStep, double dY1Config, double dY2Config, double *ptdProgVitDep, 
							double *ptdProgVitFin, double *ptdDureeProg, BOOL *ptbMarcheAvant, BOOL *ptbRampe)
{
int iErr;

	// S'il faut attendre d'atteindre la consigne
	if (*ptbAttendreConsAtteinte){
		//  - D�termination consigne vitesse atteinte
		SetGiErrVaria(VariateurConsigneVitesseAtteinte (ptwConsigneAtteinte));
		
		// Si la consigne est atteinte
		if (*ptwConsigneAtteinte){
			*ptdDureeRampe = dDureePrevue - ((double)((clock() - iTimeDepart)) / ((double)CLOCKS_PER_SEC));
			iErr = CalcParamVitesse(0.0, dY2Config, *ptdDureeRampe,
									ptdProgVitDep, ptdProgVitFin, ptdDureeProg,
									ptbMarcheAvant, ptbRampe, ptbAttendreConsAtteinte);	
			
			
			if (*ptbRampe)
				//  - Programmation d'une rampe de vitesse
				SetGiErrVaria(ProgRampeVariateur(*ptbAttendreConsAtteinte, 1, GetPointerToGptstConfig(), *ptdProgVitDep, *ptdProgVitFin, *ptdDureeProg, GetGiUnitVitesse()));
			else
				//  - Programmation d'une rampe de vitesse � la vitesse max
				SetGiErrVaria(ProgRampeVariateur(*ptbAttendreConsAtteinte, 0, GetPointerToGptstConfig(), (double)fVIT_DEB_ARRET, (double)fVIT_FIN_ARRET, dDUREE_ARRET, GetGiUnitVitesse()));
			ReleasePointerToGptstConfig(); 
			
			if (*ptbMarcheAvant)
				//  - Emission consigne de vitesse et mise en route du variateur
				SetGiErrVaria(CmdeVitesseVariateur(GetPointerToGptstConfig(), *ptdProgVitFin, iVARIATEUR_MARCHE_AVANT, GetGiUnitVitesse()));
			else							
				//  - Emission consigne de vitesse et mise en route du variateur
				SetGiErrVaria(CmdeVitesseVariateur(GetPointerToGptstConfig(), *ptdProgVitFin, iVARIATEUR_MARCHE_ARRIERE, GetGiUnitVitesse()));
			ReleasePointerToGptstConfig();
		}
	}
	else
		// S'il faut reprogrammer le moteur
		if (*ptbReprogMoteur){
			iErr = CalcParamVitesse(dY1Config, dY2Config, dDureeStep,
									ptdProgVitDep, ptdProgVitFin, ptdDureeProg,
									ptbMarcheAvant, ptbRampe, ptbAttendreConsAtteinte);

			#ifdef bSIMULATION
			if(*ptbRampe)
				SetCtrlAttribute (GetSimuHandle(), PANEL_SIMU_RAMPE_ACCELERATION, ATTR_DIMMED, 0);
			else
				SetCtrlAttribute (GetSimuHandle(), PANEL_SIMU_RAMPE_ACCELERATION, ATTR_DIMMED, 1);
			#endif
				
			if (*ptbRampe)
				//  - Programmation d'une rampe de vitesse
				SetGiErrVaria(ProgRampeVariateur(*ptbAttendreConsAtteinte, 1, GetPointerToGptstConfig(), *ptdProgVitDep, *ptdProgVitFin, *ptdDureeProg, GetGiUnitVitesse()));
			else
				//  - Programmation d'une rampe de vitesse � la vitesse max
				SetGiErrVaria(ProgRampeVariateur(*ptbAttendreConsAtteinte, 0, GetPointerToGptstConfig(), (double)fVIT_DEB_ARRET, (double)fVIT_FIN_ARRET, dDUREE_ARRET, GetGiUnitVitesse()));
			ReleasePointerToGptstConfig(); 
			
			if (*ptbMarcheAvant)
				//  - Emission consigne de vitesse et mise en route du variateur
				SetGiErrVaria(CmdeVitesseVariateur(GetPointerToGptstConfig(), *ptdProgVitFin, iVARIATEUR_MARCHE_AVANT, GetGiUnitVitesse()));
			else							
				//  - Emission consigne de vitesse et mise en route du variateur
				SetGiErrVaria(CmdeVitesseVariateur(GetPointerToGptstConfig(), *ptdProgVitFin, iVARIATEUR_MARCHE_ARRIERE, GetGiUnitVitesse()));
			ReleasePointerToGptstConfig();
			
			// Le moteur a �t� reprogramm�
			*ptbReprogMoteur = 0;
		}
}

void ExecuteAnumCmd(int cmd, char *strVal, int numVal, int param,TAPI myFUnc,struct TAPILFRF sAPILFRF)
{
	 unsigned char cAPI;
	 char aCommand[128];
	switch(cmd)
	{
		case 1:
			{
				strcpy(aCommand, "LFPWR");
		        sAPILFRF.ByteIn1=numVal;
		        //sAPILFRF.ByteIn1=2;
				cAPI=myFUnc(aCommand, (void*)&sAPILFRF);
				break;
			}
		case 2:
			{
				strcpy(aCommand, "SENDF");
		        sAPILFRF.ByteIn1=(unsigned char)numVal;;
				sAPILFRF.ByteIn2=(unsigned char)param;;
				strcpy(sAPILFRF.StringIn1, strVal);
		        cAPI=myFUnc(aCommand, (void*)&sAPILFRF);
				break;
			}
		case 3:
			{
				strcpy(aCommand, "STOPF");
        		cAPI=myFUnc(aCommand, (void*)&sAPILFRF);
				break;
			}
		case 4:
			{
				strcpy(aCommand, "RUN");
        		cAPI=myFUnc(aCommand, (void*)&sAPILFRF);
				if (cAPI!=0)
					cAPI=myFUnc(aCommand, (void*)&sAPILFRF);
				break;
			}
		case 5:
			{
				strcpy(aCommand, "STOP");
        		cAPI=myFUnc(aCommand, (void*)&sAPILFRF);
				break;
			}
	}
	
}

void ProcessAnumCmd(int index,TAPI myF,struct TAPILFRF stCmd)
{
	CDotNetHandle exception ; 
	
	int Command;
	int NumVal;
	char *StrVal;
	int Param;
	
	CheckLse_LFComand__Get__Command(TabAnumCmd[index],&Command,&exception); 
	CheckLse_LFComand__Get__StrVal(TabAnumCmd[index],&StrVal,&exception);
	CheckLse_LFComand__Get__NumVal(TabAnumCmd[index],&NumVal,&exception);
	CheckLse_LFComand__Get__Param(TabAnumCmd[index],&Param,&exception);
	
	ExecuteAnumCmd(Command,StrVal,NumVal,Param,myF,stCmd);
}

static int CVICALLBACK ThreadCycleAnum (void *functionData)
{
	#define dDELAY_THREAD_RUN 		0.2
	double dTimer;
	CDotNetHandle exception ;
	Point cell;
	int i=0;
	double  actTime=0;
	double  dStart=0; 
	char strToW[100];
	
	double Time;
	
	
	int nrItems=0;
	
	//INIT Anum
	char sAnumPath[MAX_PATHNAME_LEN];  
	  HINSTANCE hDLL=NULL;                // Instance of DLL
	  TAPI      myFUnc=0;                  // Pointeur on API function (described in API.h)
 	  struct    TAPILFRF sAPILFRF;
	  unsigned char cAPI;
	  char aCommand[128];
	  
	  	GetProjectDir (GsPathApplication);
			sprintf (sAnumPath, "%s\\%s", GsPathApplication, sANUM_DLL);
			ModesAddMessageZM("Init ANUM interface...");
	
			hDLL=LoadLibrary(sAnumPath);
			if (hDLL==NULL)
		    {
				ModesAddMessageZM("Failed to load ANUM API.dll!"); 
				GbAnumInit=0;
		    }
		
		    // Get function
		    myFUnc=(TAPI)GetProcAddress(hDLL, "API");
		    if (myFUnc==NULL)
		    {
				ModesAddMessageZM("Failed to load function from API.dll!"); 
				GbAnumInit=0;
		    }
			sprintf (sAnumPath, "%s\\%s\\%s", GsPathApplication,"Config", sANUM_CFG); 
			strcpy(aCommand, "LOAD");
	        strcpy(sAPILFRF.StringIn1, sAnumPath);
	        cAPI=myFUnc(aCommand, (void*)&sAPILFRF);
			
        	if (cAPI!=0)
			{
				ModesAddMessageZM("Failed to load ANUM cfg!"); 
				GbAnumInit=0;
			}
			
			ModesAddMessageZM("ANUM interface OK!"); 
			GbAnumInit=1;
	  
	  
	//
	
	while (!GetGbQuitter()) 
	{		
		if (GetGiMode() == iMODE_RUN)
		{ 
			if (GetGiStartCycleAnum())
			{
				ExecuteAnumCmd(dRUN,"",0,0,myFUnc,sAPILFRF);   
				nrItems=GetGiStartCycleAnum();
				if(TabAnumCmd!=NULL )
				{
					i=0;
					dStart=(double)(clock()) / ((double)CLOCKS_PER_SEC);
					while(i<nrItems)
					{
						actTime=  (double)(clock()) / ((double)CLOCKS_PER_SEC)- dStart;
						CheckLse_LFComand__Get__Time(TabAnumCmd[i],&Time,&exception);
						
						if(Time<actTime)
						 {
							  ProcessAnumCmd(i,myFUnc,sAPILFRF);
							 
							 cell.y = 1;
							 cell.x = 2;
							 sprintf(strToW,"%f",actTime);
							 SetTableCellVal (GiPanel, PANEL_MODE_TABLE_SCRIPT, cell, strToW);
							 i++;
						 }
				 
						dTimer = Timer();
					  	SyncWait(dTimer, dDELAY_THREAD_RUN); 
						ProcessSystemEvents();  
					}
				}
				SetGiStartCycleAnum(0); 
				ExecuteAnumCmd(dSTOP,"",0,0,myFUnc,sAPILFRF); 
			}
		}
		
		dTimer = Timer();
	  	SyncWait(dTimer, dDELAY_THREAD_RUN); 
		ProcessSystemEvents(); 
	}
	FreeLibrary(hDLL);
	 hDLL=NULL;
	return(0);  
}
//Thread for RUN mode
static int CVICALLBACK ThreadCycleRun (void *functionData)
{
	#define dDELAY_THREAD_RUN 		0.1
	double dTime;
	CDotNetHandle exception ;
	Point cell;
	int i=1;
	  
	char exeTestXls[255];
	char *exeTestCsv;
	int rowNo=0;
	
	int lfCmdNo=0;
	int fileSize;
	
	//CheckLse_LFComand__Create(,);
	
	while (!GetGbQuitter()) 
	{		
		if (GetGiMode() == iMODE_RUN)
		{ 
			if (GetGiStartCycleRun())
			{
				GetNumTableRows(GiPanel, PANEL_MODE_TABLE_SCRIPT,&rowNo);
				
				while(i<=rowNo)
				{
					cell.y = i;
					cell.x = 3;
					GetTableCellVal (GiPanel, PANEL_MODE_TABLE_SCRIPT, cell, exeTestXls); 
					//Load testcase
					CheckLse_LSE_LoadTcs(instanceLseNetModes,exeTestXls,&exeTestCsv,&TabAnumCmd,&lfCmdNo,&exception);
					//load vit+press
					//LoadTest(exeTestCsv,GiPanel);
					//start Anum
					//ExecuteAnumCmd(dRUN,"",0,0,);
					
					SetGiStartCycleAnum(lfCmdNo);
					while(GetGiStartCycleAnum())
					{
						dTime = Timer();
					  	SyncWait(dTime, dDELAY_THREAD_RUN); 
						ProcessSystemEvents();
					}
					//stop anum
					//ExecuteAnumCmd(dSTOP,"",0,0); 
					//evaluate result
					CheckLse_LSE_Evaluate(instanceLseNetModes,exeTestCsv,GsPathApplication,&exception);
					
					cell.y = i;
					cell.x = 2;
					SetTableCellVal (GiPanel, PANEL_MODE_TABLE_SCRIPT, cell, "Passed");
					i++;
				}
				SetGiStartCycleRun(0);
				i=1;
				SetCtrlAttribute (GiPanel, PANEL_MODE_BUT_START_RUN, ATTR_LABEL_TEXT, "Execute");
			}
		}
		dTime = Timer();
	  	SyncWait(dTime, dDELAY_THREAD_RUN); 
		ProcessSystemEvents(); 
	}
	return(0);  
}
// DEBUT ALGO
//***************************************************************************
//static int CVICALLBACK ThreadCycleVitesse (void *functionData)
//***************************************************************************
//  - functionData: pointeur sur des donn�es
//
//  - Thread de gestion des cycles de vitesse
//
//  - 1 si probl�me d�tect�, 0 sinon
//***************************************************************************
// FIN ALGO
static int CVICALLBACK ThreadCycleVitesse (void *functionData)
{
#define sFORMAT_TIME_VIT(iTempsSecondes, TpsEcoule)										\
{																						\
	iHeures = iTempsSecondes/3600;														\
	iMinutes = (iTempsSecondes/60) - (iHeures*60);										\
	iSecondes = iTempsSecondes%60;														\
	sprintf(TpsEcoule, sFORMAT_DUREE_ECOULEE, iHeures, iMinutes, iSecondes);			\
}

#define dDELAY_THREAD_VIT 		0.2
stConfig *ptstConfig;
char sMsg[500];
BOOL bDimmed1;
BOOL bDimmed2;
char sTpsEcoule[50];
int iHeures;
int iMinutes;
int iSecondes;
	
double dX1RelectCons = 0.0;
double dY1RelectCons = 0.0;
double dX2RelectCons = 0.0;
double dY2RelectCons = 0.0;

double dX1Relect = 0.0;
double dY1Relect = 0.0;
double dX2Relect = 0.0;
double dY2Relect = 0.0;

double dX1Config = 0.0;
double dY1Config = 0.0;
double dX2Config = 0.0;
double dY2Config = 0.0;

double dX1ConfigAccel = 0.0;
double dY1ConfigAccel = 0.0;
double dX2ConfigAccel = 0.0;
double dY2ConfigAccel = 0.0;

double dDureePrevue		=0.0;
double dDureeEcouleeCycle=0.0;
double dPente 			= 0.0;
double dCste 			= 0.0;
double dPenteAcc 		= 0.0;
double dCsteAcc 		= 0.0;
double dVitessePrevue 	= 0.0;
double dDureeEcouleeRampe = 0.0;
double dDureeEcouleeEssai = 0.0;

char sLabel[20];
int iErr 			= 0;
int iNbEssais 		= 0;
int iTimeDepart		= 0;
int iOldStep		= 0;
int iNumCycle 		= 0;
int iNbCyclesPrevus = 0;
int iIndexMeas 		= 0;
int iHandle 		= 0;
int iTimeDepartRampe = 0;
int iIndexStepVitesse = 1;
int iIndexCycleVitesse = 1;
int iTimeDepCmde;
int iSelectionHandleVitesse = 0;
int iErrUsb6008 	= 0;
int iErrVaria 		= 0;

int iTimeDepRampe=0;
int iAccelGCmdeDelay = 1.0;

double dProgVitDep  = 0.0;
double dProgVitFin  = 0.0;
double dDureeProg  	= 0.0;
double dDureeRampe  = 0.0;
double dLastDureeEcouleeEssai  = 0.0;
double dDureeEcouleeCmde  	= 0.0;
double dDureePrevueCmde		= 0.0;

double dLastVitessePrevue 	= 0.0;
double dLastDureePrevue		= 0.0;
double dDureeTotaleAcc		= 0.0;
double dDureePrevueVitesse	= 0.0;
double dLastVitesseProg		= 0.0;

double dPlageAffichManu		= 60.0;

double dMin  = 0.0;
double dMax  = 0.0;

double dTime;

BOOL bMarcheAvant=1;
BOOL bRampe=1;
BOOL bAttendreConsAtteinte=0;
BOOL bReprogMoteur=1;
BOOL bChgmentVitesse=0;
short wConsigneAtteinte=1;
float fVitesse;
double dPression;
double dTimeElapsed;

CDotNetHandle exception ;     


	while (!GetGbQuitter()) 
	{		
		if ((GetGiMode() == iMODE_AUTOMATIQUE)||(GetGiMode() == iMODE_RUN))
		{ 
			// Si le cycle de vitesse est lanc�
			if (GetGiStartCycleVitesse())
			{
				//GbEndCycleVitesse = 0;
			
				SetGbEndCycleVitesse (0);

				iIndexMeas 				= 0;
				bAttendreConsAtteinte 	= 0;
				bReprogMoteur			= 0;
				SetGfVitesse (0.0);
				SetGdDurEcoulEssaiSpeed(0.0);
				
				ptstConfig = GetPointerToGptstConfig();
				iAccelGCmdeDelay = ptstConfig->iAccelGCmdeDelay;
				ReleasePointerToGptstConfig();
				
				SetGiTimeDepartEssaiSpeed(clock());
				
				// Effacement et trac� du graphique
				//GstGrapheMajGrapheVit(GiPanel, PANEL_MODE_TABLE_VITESSES, PANEL_MODE_GRAPHE_VITESSE, 1, GstTabVitesse.dDuree, GstTabVitesse.dVit, GstTabVitesse.iNbElmts, 1, iCOUL_CONS_VITESSE, 1);

				// Initialisation du num�ro de cycle
				iNumCycle = 1;
				// Lecture du nombre de cycles pr�vus
				GetCtrlVal (GiPanel, PANEL_MODE_NBE_CYCLES_VITESSE, &iNbCyclesPrevus);
			
				// Affichage du num�ro de cycle en cours
				SetCtrlVal (GiPanel, PANEL_MODE_NUM_CYCLE_VITESSE, iNumCycle);
			
				//  - Programmation de la rampe par d�faut
				SetGiErrVaria(ProgRampeVariateur(0, 0, GetPointerToGptstConfig(), (double)fVIT_DEB_ARRET, (double)fVIT_FIN_ARRET, dDUREE_ARRET, GetGiUnitVitesse()));
				ReleasePointerToGptstConfig(); 

				//----- Modification du 15/11/2010 par C.BERENGER ----- DEBUT -----------
				dX1Relect		= 0.0;
				dY1Relect		= 0.0;
				dX2Relect		= 0.0;
				dY2Relect		= 0.0;

				iTimeDepCmde	= 0;
				//----- Modification du 15/11/2010 par C.BERENGER ----- FIN -----------
				
				do{
					// Initialisations pour chaque cycle
					if(iNumCycle == 1){
						// Le moteur est � l'arr�t au premier step
						dX1Config		= 0.0;
						dY1Config		= 0.0;   
						dX2Config		= GstTabVitesse.dDuree[0];
						dY2Config 		= GstTabVitesse. dVit[0];   
					}
					else{
							// Prise en compte du dernier step du cycle pr�c�dent
							dX1Config		= 0.0;
							//CHECK_TAB_INDEX("8", GstTabVitesse.iNbElmts-1, 0, 5000) 
							dY1Config		= GstTabVitesse. dVit[GstTabVitesse.iNbElmts-1];   
							dX2Config		= GstTabVitesse.dDuree[0];
							dY2Config 		= GstTabVitesse. dVit[0];   
						}
				
					
					dX1ConfigAccel	= 0.0;
					dY1ConfigAccel	= 0.0;   
					dX2ConfigAccel	= iAccelGCmdeDelay/1000.0;
					dY2ConfigAccel	= 0.0; 					

					//----- Modification du 15/11/2010 par C.BERENGER ----- DEBUT -----------
					dX2Relect		= 0.0;
					dDureePrevueCmde=0.0;
					//----- Modification du 15/11/2010 par C.BERENGER ----- FIN -----------
					
					dDureeEcouleeCycle 	= 0.0;
					SetGiIndexStepVitesse(1);
					iIndexStepVitesse = 1;
					bReprogMoteur	= 1;
					iOldStep 		= 1;
					iTimeDepart 	= clock();
					dDureePrevue	= GstTabVitesse.dDuree[0];     

					// Affichage du step en cours sur le graphique
					//iErr = DisplaySegmentActifGraph(GiPanel, PANEL_MODE_TABLE_VITESSES, PANEL_MODE_GRAPHE_VITESSE, 
					//			 					iIndexStepVitesse, GstTabVitesse.iNbElmts, iNumCycle, iCOUL_CONS_VITESSE, &iSelectionHandleVitesse);

					// Affichage du step en cours dans la table
					iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_VITESSES, iIndexStepVitesse, ATTR_USE_LABEL_TEXT, 1);
					sprintf(sLabel, ">%d>", GetGiIndexStepVitesse());
					iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_VITESSES, iIndexStepVitesse, ATTR_LABEL_POINT_SIZE, 15);				
					iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_VITESSES, iIndexStepVitesse, ATTR_LABEL_TEXT, sLabel);
					iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_VITESSES, iIndexStepVitesse, ATTR_LABEL_BOLD, 1);


					//-------- Modification du 15/11/2010 par C. BERENGER ----- DEBUT -------------
					//------------------------------------
					SetGiSelectionHandleVitesse(iSelectionHandleVitesse); 
					//------------------------------------
					// On met toujours dans le haut du tableau la ligne en cours
					SetCtrlAttribute (GiPanel, PANEL_MODE_TABLE_VITESSES, ATTR_FIRST_VISIBLE_ROW, iIndexStepVitesse);
					//-------- Modification du 15/11/2010 par C. BERENGER ----- FIN ------------- 
					 
					// On d�roule le cycle de vitesse
					do{
						//---- Modification du 04/04/2013 par CB --- DEBUT ---------
						dTimeElapsed = (double)((clock() - GetGiTimeDepartEssaiPress())) / ((double)CLOCKS_PER_SEC);
						sprintf(sMsg, " (1)dTimeElapsed =%.02f, ------- STEP EN COURS = %d/Cycle=%d -------------",  dTimeElapsed, iIndexStepVitesse, iNumCycle);
						ModesAddMessageZM(sMsg);
						//---- Modification du 04/04/2013 par CB --- FIN ---------

					
						// Calcul de la dur�e de l'essai
						dDureeEcouleeEssai = (double)((clock() - GetGiTimeDepartEssaiSpeed())) / ((double)CLOCKS_PER_SEC);
						sFORMAT_TIME_VIT((int)dDureeEcouleeEssai, sTpsEcoule)

						iErr = SetCtrlVal (GiPanel, PANEL_MODE_AFFICH_TPS_VIT, sTpsEcoule);

						// Affichage du temps �coul�
						dDureeEcouleeCycle = (double)((clock() - iTimeDepart)) / ((double)CLOCKS_PER_SEC);

						// Incr�mentation du num�ro de step
						if (dDureeEcouleeCycle > dDureePrevue){
							iIndexStepVitesse++;
						
							if (iIndexStepVitesse <= GstTabVitesse.iNbElmts){
								dDureePrevue += GstTabVitesse.dDuree[iIndexStepVitesse-1];

								dX1Config	= dX2Config;
								dY1Config	= dY2Config;
								dX2Config	+= GstTabVitesse.dDuree[iIndexStepVitesse-1];
								dY2Config 	= GstTabVitesse. dVit[iIndexStepVitesse-1];   

								//---- Modification du 04/04/2013 par CB --- DEBUT ---------
								dTimeElapsed = (double)((clock() - GetGiTimeDepartEssaiPress())) / ((double)CLOCKS_PER_SEC); 
								sprintf(sMsg, "(2) dTimeElapsed=%.02f, dDureePrevue=%.02f, dX1Config=%0.3f, dY1Config=%0.3f, dX2Config=%0.3f, dY2Config=%0.3f", 
												dTimeElapsed, dDureePrevue, dX1Config, dY1Config, dX2Config, dY2Config);
								ModesAddMessageZM(sMsg);
								//---- Modification du 04/04/2013 par CB --- FIN ---------


								// On met toujours dans le haut du tableau la ligne en cours
								SetCtrlAttribute (GiPanel, PANEL_MODE_TABLE_VITESSES, ATTR_FIRST_VISIBLE_ROW, iIndexStepVitesse);

								// S�lection du step en cours dans le tableau
								if (iOldStep != 0){
									iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_VITESSES, iOldStep, ATTR_USE_LABEL_TEXT, 1);
									sprintf(sLabel, "%d", iOldStep);
									iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_VITESSES, iOldStep, ATTR_LABEL_POINT_SIZE, 11);
									iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_VITESSES, iOldStep, ATTR_LABEL_TEXT, sLabel);
									iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_VITESSES, iOldStep, ATTR_LABEL_BOLD, 0);
								}
			
								iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_VITESSES, iIndexStepVitesse, ATTR_USE_LABEL_TEXT, 1);
								sprintf(sLabel, ">%d>", iIndexStepVitesse);
								iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_VITESSES, iIndexStepVitesse, ATTR_LABEL_POINT_SIZE, 15);				
								iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_VITESSES, iIndexStepVitesse, ATTR_LABEL_TEXT, sLabel);
								iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_VITESSES, iIndexStepVitesse, ATTR_LABEL_BOLD, 1);

								iOldStep = iIndexStepVitesse;
								
								bReprogMoteur = 1;
							}
						}

						//------ Programmation de la vitesse ------------
						if ((iIndexStepVitesse <= GstTabVitesse.iNbElmts) && ((GetGiUnitVitesse() != iUNIT_G) || (iAccelGCmdeDelay <= 0.0))){
							//CHECK_TAB_INDEX("10", iIndexStepVitesse-1, 0, 5000) 
							PilotageMoteurModeAuto (&bAttendreConsAtteinte, &wConsigneAtteinte, &bReprogMoteur,
													&dDureeRampe, iTimeDepart, iIndexStepVitesse, 
													dDureePrevue, GstTabVitesse.dDuree[iIndexStepVitesse-1], dY1Config, dY2Config, &dProgVitDep, 
													&dProgVitFin, &dDureeProg, &bMarcheAvant, &bRampe);
						}
						//------------------------------------------
						
						// Lecture et affichage de la vitesse et de la pression
						LectEtAffichSpeedAndPress(GetGiStartCycleVitesse(), GetGiStartCycleVitesse(), GiPanel, GiStatusPanel, 
													GetPointerToGptstConfig(), &fVitesse, &dPression, GetGiUnitVitesse(), GetGiUnitPression(), 
													&iErrUsb6008, &iErrVaria);
						ReleasePointerToGptstConfig();

						SetGiErrUsb6008(iErrUsb6008);
						SetGiErrVaria(iErrVaria);						

						if (iIndexStepVitesse <= GstTabVitesse.iNbElmts) {
							// Calcul de la vitesse � programmer
							if (((dX2Config - dX1Config) < -0.001) && ((dX2Config - dX1Config) > 0.001)){
								SetGdVitesseAProg(dY2Config);
								
								//---- Modification du 04/04/2013 par CB --- DEBUT ---------
								dTimeElapsed = (double)((clock() - GetGiTimeDepartEssaiPress())) / ((double)CLOCKS_PER_SEC); 
								sprintf(sMsg, "(2.1) dTimeElapsed=%.02f, VitProg dY2Config = %.02f", dY2Config);
								ModesAddMessageZM(sMsg);   
								//---- Modification du 04/04/2013 par CB --- FIN ---------
							}
							else{
									dPente = (dY2Config - dY1Config) / (dX2Config - dX1Config);
									dCste = dY1Config - (dPente * dX1Config);
							
									SetGdVitesseAProg(dPente * dDureeEcouleeCycle + dCste);
									
									//---- Modification du 04/04/2013 par CB --- DEBUT ---------
									dTimeElapsed = (double)((clock() - GetGiTimeDepartEssaiPress())) / ((double)CLOCKS_PER_SEC); 
									sprintf(sMsg, "(2.2) dTimeElapsed=%.02f, VitProg=%.02f, dPente=%.02f, dCste=%.02f, dX1Config=%.02f, dY1Config=%.02f,dX2Config=%.02f,dY2Config=%.02f", 
												dTimeElapsed, dPente * dDureeEcouleeCycle + dCste, dPente, dCste, dX1Config, dY1Config, dX2Config, dY2Config);
									ModesAddMessageZM(sMsg);   
									//---- Modification du 04/04/2013 par CB --- FIN ---------
								} 
			
							//------ Traitement sp�cifique au pilotage en acc�l�ration (g) ------
							if ((GetGiUnitVitesse() == iUNIT_G) && (iAccelGCmdeDelay > 0.0)){
								dDureeEcouleeCmde = (double)((clock() - iTimeDepCmde)) / ((double)CLOCKS_PER_SEC);
								   
								// La commande de l'acc�l�ration se fait seulement � la cadence d�finie dans le fichier de configuration
								if(dDureeEcouleeCmde > dDureePrevueCmde){
									if(GetGdVitesseAProg() != dY2ConfigAccel){ 
										dDureeEcouleeCycle = (double)((clock() - iTimeDepart)) / ((double)CLOCKS_PER_SEC); 
										
										if ((dDureeEcouleeCycle + dDureePrevueCmde) > dDureePrevue)
											dDureePrevueCmde = dDureePrevue - dDureeEcouleeCycle;
										else
											dDureePrevueCmde = iAccelGCmdeDelay / 1000.0;
										
										if (dDureePrevueCmde < 0.05)
											dDureePrevueCmde = 0.05;
										
										// Vitesse/acc�l�ration actuelle
										dX1ConfigAccel	= dDureeEcouleeCycle; // Dur�e actuelle
										dY1ConfigAccel	= fVitesse; // Relecture de vitesse actuelle //dY2ConfigAccel;
										// Vitesse/acc�l�ration � atteindre
										dX2ConfigAccel	= (dDureeEcouleeCycle + dDureePrevueCmde);
										dY2ConfigAccel 	= dPente * (dDureeEcouleeCycle + dDureePrevueCmde) + dCste;   




										//---- Modification du 04/04/2013 par CB --- DEBUT ---------
										dTimeElapsed = (double)((clock() - GetGiTimeDepartEssaiPress())) / ((double)CLOCKS_PER_SEC); 
										sprintf(sMsg, "(3)dTimeElapsed=%.02f, dDureePrevueCmde=%.02f, dX1ConfigAccel=%0.3f, dY1ConfigAccel=%0.3f, dX2ConfigAccel=%0.3f, dY2ConfigAccel=%0.3f, dPente=%.03f, dCste=%.03f", 
														dTimeElapsed, dDureePrevueCmde, dX1ConfigAccel, dY1ConfigAccel, dX2ConfigAccel, dY2ConfigAccel, dPente, dCste);
										ModesAddMessageZM(sMsg);
										//---- Modification du 04/04/2013 par CB --- FIN ---------





										// Modification du 06/12/2011 par CB -- DEBUT -------------
										if(dPente > 0.0){
											if(dY2ConfigAccel > dY2Config)
												dY2ConfigAccel = dY2Config;
										}
										else{
												if(dY2ConfigAccel < dY2Config)
													dY2ConfigAccel = dY2Config;
											}
										// Modification du 06/12/2011 par CB -- FIN -------------
										
											
										
										// Modification du 06/12/2011 par CB -- DEBUT -------------
										if (fabs(dY2ConfigAccel - dY1ConfigAccel) < 0.05)
											if(dPente < 0)
												dY2ConfigAccel = dY1ConfigAccel - 0.05;
											else
												dY2ConfigAccel = dY1ConfigAccel + 0.05;
										// Modification du 06/12/2011 par CB -- FIN -------------
										
										
										// Programmation de la vitesse
										bReprogMoteur = 1;
									}
								}							
							}
							
							if ((iIndexStepVitesse <= GstTabVitesse.iNbElmts) && (GetGiUnitVitesse() == iUNIT_G) && (iAccelGCmdeDelay > 0.0)){ 
								if(bReprogMoteur)
									iTimeDepCmde = clock();
							  
								PilotageMoteurModeAuto (&bAttendreConsAtteinte, &wConsigneAtteinte, &bReprogMoteur,
														&dDureeRampe, iTimeDepart, iIndexStepVitesse, 
														// Dure prevue
														dX2ConfigAccel, dDureePrevueCmde, dY1ConfigAccel, dY2ConfigAccel, &dProgVitDep, 
														&dProgVitFin, &dDureeProg, &bMarcheAvant, &bRampe);
							}
							
							//---------------------------------------------------------------------
							
							dX1Relect		= dX2Relect;
							dY1Relect		= dY2Relect;
							dX2Relect		= dDureeEcouleeCycle;
							dY2Relect		= (double)fVitesse;

							// Affichage de la vitesse sur le graphique
							iHandle = PlotLine (GiPanel, PANEL_MODE_GRAPHE_VITESSE, dX1Relect, dY1Relect, dX2Relect, dY2Relect, iCOUL_VITESSE);
							SetPlotAttribute (GiPanel, PANEL_MODE_GRAPHE_VITESSE, iHandle, ATTR_PLOT_THICKNESS, 2);
							iIndexMeas++;
							
							
							//---- Modification du 04/04/2013 par CB --- DEBUT ---------
							dTimeElapsed = (double)((clock() - GetGiTimeDepartEssaiPress())) / ((double)CLOCKS_PER_SEC); 
							sprintf(sMsg, "(4) dTimeElapsed=%.02f, dX1Relect=%0.3f, dY1Relect=%0.3f, dX2Relect=%0.3f, dY2Relect=%0.3f", 
											dTimeElapsed, dX1Relect, dY1Relect, dX2Relect, dY2Relect);
							ModesAddMessageZM(sMsg);
							//---- Modification du 04/04/2013 par CB --- FIN ---------
						}
				
						// Mise � jour des variables globales
						//-----------------------------------
						SetGfVitesse (fVitesse);
						SetGdPression(dPression); 
						SetGdDurEcoulEssaiSpeed(dDureeEcouleeEssai);

						if(iIndexStepVitesse <= GstTabVitesse.iNbElmts)
							SetGiIndexStepVitesse(iIndexStepVitesse);
							
						if(iNumCycle <= iNbCyclesPrevus)							
							SetGiIndexCycleVitesse(iNumCycle);
						//-----------------------------------
						
						ProcessSystemEvents(); 
					  	dTime = Timer();
					  	SyncWait(dTime, dDELAY_THREAD_VIT); 
					}while((GetGiStartCycleVitesse()) && (iIndexStepVitesse <= GstTabVitesse.iNbElmts));
			
					if (iOldStep != 0){ 
						iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_VITESSES, iOldStep, ATTR_USE_LABEL_TEXT, 1);
						sprintf(sLabel, "%d", iOldStep);
						iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_VITESSES, iOldStep, ATTR_LABEL_POINT_SIZE, 11);
						iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_VITESSES, iOldStep, ATTR_LABEL_TEXT, sLabel);
						iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_VITESSES, iOldStep, ATTR_LABEL_BOLD, 0);
					}
					
					// Raz du temps des vitesses
					SetGbRazTimeVit(1);
					
					if (GetGiStartCycleVitesse() == 1)
						// Incr�mentation du num�ro de cycle en cours
						iNumCycle++;
					
					if (iNumCycle <= iNbCyclesPrevus){
						// Affichage du num�ro de cycle en cours
						SetCtrlVal (GiPanel, PANEL_MODE_NUM_CYCLE_VITESSE, iNumCycle);

						if (GetGiStartCycleVitesse() == 1)
							// Effacement et trac� du graphique
							//GstGrapheMajGraphePres(GiPanel, PANEL_MODE_TABLE_VITESSES, PANEL_MODE_GRAPHE_VITESSE, 1, GstTabVitesse.dDuree, GstTabVitesse.dVit, GstTabVitesse.iNbElmts, iNumCycle, iCOUL_CONS_VITESSE, 1);
					}

					ProcessSystemEvents();  
				  	dTime = Timer();
				  	SyncWait(dTime, dDELAY_THREAD_VIT); 
				}while ((iNumCycle <= iNbCyclesPrevus) && (GetGiStartCycleVitesse() == 1));
				
				SetGiTimeDepartEssaiSpeed(0);
				
				//  - Arr�t du moteur
				SetGiErrVaria(ProgRampeVariateur(0, 0, GetPointerToGptstConfig(), (double)fVIT_DEB_ARRET, (float)fVIT_FIN_ARRET, dDUREE_ARRET, GetGiUnitVitesse()));
				ReleasePointerToGptstConfig();
				SetGiErrVaria(VariateurArret()); 

				GetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VITESSE, 	ATTR_DIMMED, &bDimmed1);
				GetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VIT_PRESS, ATTR_DIMMED, &bDimmed2);
				SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VITESSE, 	ATTR_DIMMED, 1);
				SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VIT_PRESS, ATTR_DIMMED, 1);				

				// Attente d'arr�t du moteur
				iNbEssais = 0;
				SetGdVitesseAProg(0.0); 
				do{
					iNbEssais++;
					// Lecture et affichage de la vitesse et de la pression
					LectEtAffichSpeedAndPress(1, 1, GiPanel, GiStatusPanel, 
											GetPointerToGptstConfig(), &fVitesse, &dPression, GetGiUnitVitesse(), GetGiUnitPression(), 
											&iErrUsb6008, &iErrVaria);
					ReleasePointerToGptstConfig();

					SetGiErrUsb6008(iErrUsb6008);
					SetGiErrVaria(iErrVaria); 					
					SetGfVitesse (fVitesse);
					SetGdPression(dPression); 					

					ProcessSystemEvents();
				  	dTime = Timer();
				  	SyncWait(dTime, dDELAY_THREAD_VIT); 
				}while (((fabs(fVitesse) > dVIT_ABS_START_TEST) && (iNbEssais < 30)) && (!GetGbQuitter()));

				SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VITESSE, ATTR_DIMMED,   bDimmed1);
				SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VIT_PRESS, ATTR_DIMMED, bDimmed2);

			  	dTime = Timer();
			  	SyncWait(dTime, 0.5); 

				// Arr�t de la ventilation moteur
				SetGiErrUsb6008(Usb6008CommandeVentilationMoteur (iUSB6008_CMDE_VENTILATION_MOTEUR_INACTIFS));

				SetGiStartCycleVitesse(0);
				// Fin du cycle
				iErr = GstIhmCycles(GiPanel,GetGiStartVitPress(),  GetGiStartCycleVitesse(), GetGiStartCyclePression());				

				SetGbEndCycleVitesse (1);
				
				CheckLse_LSE_Evaluate(instanceLseNetModes,"Stop ThreadCycleVitesse","Dad",&exception);
			}
		}  
		else{
				//--------- MODE MANUEL --------
				dX1Config 		= 0.0;
				dY1Config 		= 0.0;
				dX2Config 		= 0.0;
				dY2Config 		= 0.0;

				//------- Modif du 15/11/2010 par C.BERENGER ------ DEBUT ------------
				dX1ConfigAccel	= 0.0;
				dY1ConfigAccel	= 0.0;   
				ptstConfig 		= GetPointerToGptstConfig();
				iAccelGCmdeDelay = ptstConfig->iAccelGCmdeDelay;
				dPlageAffichManu =  ptstConfig->dPlageAffichManu;
				ReleasePointerToGptstConfig();
				
				dX2ConfigAccel	= iAccelGCmdeDelay/1000.0;
				dY2ConfigAccel	= 0.0; 	
				iTimeDepCmde	= 0;
				//------- Modif du 15/11/2010 par C.BERENGER ------ FIN ------------
				
				dX1Relect		= 0.0;
				dY1Relect		= 0.0;
				dX2Relect		= 0.0;
				dY2Relect		= 0.0;				

				dX1RelectCons	= 0.0;
				dY1RelectCons	= 0.0;
				dX2RelectCons	= 0.0;
				dY2RelectCons	= 0.0;				
				
				dPente 			= 0.0;
				dCste			= 0.0;
				
				dMin			= 0.0;
				dMax			= 0.0;
				
				dLastDureeEcouleeEssai = 0.0;

				SetGdVitesseAProg(-1.0);
				bAttendreConsAtteinte = 0;
				
				dLastVitessePrevue 	= 0.0;
				dDureeEcouleeRampe 	= 0.0;
				dDureeTotaleAcc		= 0.0;
				iTimeDepRampe		= 0;
				
				SetGdVitesseAProg(0.0);
				SetGiIndexStepVitesse(0);
				SetGiIndexCycleVitesse(0);
				
				if (GetGiStartCycleVitesse()){
					SetGbEndCycleVitesse (0);

					//------- Modif du 15/11/2010 par C.BERENGER ------ DEBUT ------------
					SetAxisScalingMode (GiPanel, PANEL_MODE_GRAPHE_VITESSE, VAL_BOTTOM_XAXIS, VAL_AUTOSCALE, 0.0, 100.0);					
					//------- Modif du 15/11/2010 par C.BERENGER ------ FIN ------------
				
					// Reset du graphique 
					DeleteGraphPlot (GiPanel, PANEL_MODE_GRAPHE_VITESSE, -1, VAL_IMMEDIATE_DRAW);

					// Temps de d�part
					SetGiTimeDepartEssaiSpeed(clock()); 
					iTimeDepartRampe = clock();
					iTimeDepart 	 = clock(); 
					
					//  - Programmation de la rampe par d�faut
					SetGiErrVaria(ProgRampeVariateur(0, 0, GetPointerToGptstConfig(), (double)fVIT_DEB_ARRET, (double)fVIT_FIN_ARRET, dDUREE_ARRET, GetGiUnitVitesse()));
					ReleasePointerToGptstConfig();

					// Si le cycle de vitesse est lanc�
					do{
						// Lecture de la valeur de vitesse � programmer
						GetCtrlVal (GiPanel, PANEL_MODE_SAISIE_VITESSE_MANU, &dVitessePrevue);

						// Si la vitesse a �t� modifi�e
						if ((dY2Config != dVitessePrevue) || (bAttendreConsAtteinte)){
							// S'il faut attendre la consigne
							if ((bAttendreConsAtteinte) && (dY2Config == dVitessePrevue)){
								//  - D�termination consigne vitesse atteinte
								SetGiErrVaria(VariateurConsigneVitesseAtteinte (&wConsigneAtteinte));

								// Si la consigne est atteinte
								if (wConsigneAtteinte){
									dDureeRampe = dDureePrevue - ((double)((clock() - iTimeDepartRampe)) / ((double)CLOCKS_PER_SEC));
									iErr = CalcParamVitesse(0.0, dY2Config, dDureeRampe,
															&dProgVitDep, &dProgVitFin, &dDureeProg,
															&bMarcheAvant, &bRampe, &bAttendreConsAtteinte);	
									
									if (bRampe)
										//  - Programmation d'une rampe de vitesse
										SetGiErrVaria(ProgRampeVariateur(0, 1, GetPointerToGptstConfig(), dProgVitDep, dProgVitFin, dDureeProg, GetGiUnitVitesse()));
									else
										//  - Programmation d'une rampe de vitesse � la vitesse max
										SetGiErrVaria(ProgRampeVariateur(0, 0, GetPointerToGptstConfig(), (double)fVIT_DEB_ARRET, (double)fVIT_FIN_ARRET, dDUREE_ARRET, GetGiUnitVitesse()));
									ReleasePointerToGptstConfig(); 

									if (bMarcheAvant)
										//  - Emission consigne de vitesse et mise en route du variateur
										SetGiErrVaria(CmdeVitesseVariateur(GetPointerToGptstConfig(), dProgVitFin, iVARIATEUR_MARCHE_AVANT, GetGiUnitVitesse()));
									else							
										//  - Emission consigne de vitesse et mise en route du variateur
										SetGiErrVaria(CmdeVitesseVariateur(GetPointerToGptstConfig(), dProgVitFin, iVARIATEUR_MARCHE_ARRIERE, GetGiUnitVitesse()));
									ReleasePointerToGptstConfig();
								}
							}
							else{
									GetCtrlVal (GiPanel, PANEL_MODE_SAISIE_DUREE_VIT_MANU, &dDureePrevue);

									dX1Config = 0.0;
									dX2Config = dDureePrevue;
									dY1Config = dY2RelectCons; //dY2Config;
									dY2Config = dVitessePrevue;
						
									// Calcul de la vitesse � programmer
									if (((dX2Config - dX1Config) > -0.001) && ((dX2Config - dX1Config) < 0.001)){
										dPente 	= 0.0;
										dCste 	= 0.0;
										SetGdVitesseAProg(dY2Config);
									}
									else{
											dPente = (dY2Config - dY1Config) / (dX2Config - dX1Config);
											dCste = dY1Config - (dPente * dX1Config);
										}						
								
									// Mise � z�ro de la dur�e �coul�e
									dDureeEcouleeCycle = 0.0;
									// Temps de d�part
									iTimeDepartRampe = clock(); 
							
									// Calcul des param�tres de programmation du moteur
									iErr = CalcParamVitesse(dY1Config, dY2Config, dDureePrevue,
															&dProgVitDep, &dProgVitFin, &dDureeProg,
															&bMarcheAvant, &bRampe, &bAttendreConsAtteinte);

									#ifdef bSIMULATION
									if(bRampe)
										SetCtrlAttribute (GetSimuHandle(), PANEL_SIMU_RAMPE_ACCELERATION, ATTR_DIMMED, 0);
									else
										SetCtrlAttribute (GetSimuHandle(), PANEL_SIMU_RAMPE_ACCELERATION, ATTR_DIMMED, 1);
									#endif   

									if (bRampe)
										//  - Programmation d'une rampe de vitesse
										SetGiErrVaria(ProgRampeVariateur(0, 1, GetPointerToGptstConfig(), dProgVitDep, dProgVitFin, dDureeProg, GetGiUnitVitesse()));
									else
										//  - Programmation d'une rampe de vitesse � la vitesse max
										SetGiErrVaria(ProgRampeVariateur(0, 0, GetPointerToGptstConfig(), (double)fVIT_DEB_ARRET, (double)fVIT_FIN_ARRET, dDUREE_ARRET, GetGiUnitVitesse()));
									ReleasePointerToGptstConfig(); 

										if (bMarcheAvant)
											//  - Emission consigne de vitesse et mise en route du variateur
											SetGiErrVaria(CmdeVitesseVariateur(GetPointerToGptstConfig(), dProgVitFin, iVARIATEUR_MARCHE_AVANT, GetGiUnitVitesse()));
										else							
											//  - Emission consigne de vitesse et mise en route du variateur
											SetGiErrVaria(CmdeVitesseVariateur(GetPointerToGptstConfig(), dProgVitFin, iVARIATEUR_MARCHE_ARRIERE, GetGiUnitVitesse()));
										ReleasePointerToGptstConfig();
								}
						}

						dDureeEcouleeRampe = (double)((clock() - iTimeDepartRampe)) / ((double)CLOCKS_PER_SEC);
						
						// Rampe
						if (dDureeEcouleeRampe <= dDureePrevue){
							// Calcul de la pression � programmer
							SetGdVitesseAProg(dPente * dDureeEcouleeRampe + dCste);					
						}
						else
							// Palier
							SetGdVitesseAProg(dVitessePrevue);
						
					
						// Calcul de la dur�e de l'essai
						dDureeEcouleeEssai = (double)((clock() - GetGiTimeDepartEssaiSpeed())) / ((double)CLOCKS_PER_SEC);
						//Affichage de la dur�e de l'essai � l'�cran
						sFORMAT_TIME_VIT((int)dDureeEcouleeEssai, sTpsEcoule)
						
						SetCtrlVal (GiPanel, PANEL_MODE_AFFICH_TPS_VIT, sTpsEcoule);
				
						// Lecture et affichage de la vitesse et de la pression
						LectEtAffichSpeedAndPress(GetGiStartCycleVitesse(), GetGiStartCycleVitesse(), GiPanel, GiStatusPanel, 
													GetPointerToGptstConfig(), &fVitesse, &dPression, GetGiUnitVitesse(), GetGiUnitPression(), 
													&iErrUsb6008, &iErrVaria);	
						ReleasePointerToGptstConfig();

						SetGiErrUsb6008(iErrUsb6008);
						SetGiErrVaria(iErrVaria); 						


						// Calcul de la consigne de vitesse sur le graphique
						dX1RelectCons	= dX2RelectCons;
						dY1RelectCons	= dY2RelectCons;
						dX2RelectCons	= dDureeEcouleeEssai;
						dY2RelectCons	= GetGdVitesseAProg();
	
						// Affichage de la consigne de vitesse sur le graphique
						iHandle = PlotLine (GiPanel, PANEL_MODE_GRAPHE_VITESSE, dX1RelectCons, dY1RelectCons, dX2RelectCons, dY2RelectCons, iCOUL_CONS_VITESSE);
						SetPlotAttribute (GiPanel, PANEL_MODE_GRAPHE_VITESSE, iHandle, ATTR_PLOT_THICKNESS, 1);

						// Mise � jour des variables globales
						//-----------------------------------
						SetGfVitesse (fVitesse);
						SetGdPression(dPression);
						SetGdDurEcoulEssaiSpeed(dDureeEcouleeEssai);
						//-----------------------------------
						
						
						// Calcul de la relecture de vitesse sur le graphique
						dX1Relect	= dX2Relect;
						dY1Relect	= dY2Relect;
						dX2Relect	= dDureeEcouleeEssai;
						dY2Relect	= GetGfVitesse ();
							 
						//------- Modif du 15/11/2010 par C.BERENGER ------ DEBUT ------------
						if(dY2RelectCons < dMin) dMin = dY2RelectCons;
						if(dY2RelectCons > dMax) dMax = dY2RelectCons;
						if(dY2Relect < dMin) dMin = dY2Relect;
						if(dY2Relect > dMax) dMax = dY2Relect;
						
						if(dDureeEcouleeEssai > dPlageAffichManu)
							if(dDureeEcouleeEssai - dLastDureeEcouleeEssai > dPlageAffichManu){
									// Reset du graphique 
									DeleteGraphPlot (GiPanel, PANEL_MODE_GRAPHE_VITESSE, -1, VAL_IMMEDIATE_DRAW);
									SetAxisScalingMode (GiPanel, PANEL_MODE_GRAPHE_VITESSE, VAL_BOTTOM_XAXIS, VAL_MANUAL, dDureeEcouleeEssai, dDureeEcouleeEssai + dPlageAffichManu);
									// Points pour garder l'�chelle pr�c�dente car autoscale vertical
									PlotPoint (GiPanel, PANEL_MODE_GRAPHE_VITESSE, dDureeEcouleeEssai, dMax, VAL_NO_POINT, VAL_TRANSPARENT);
									PlotPoint (GiPanel, PANEL_MODE_GRAPHE_VITESSE, dDureeEcouleeEssai, dMin, VAL_NO_POINT, VAL_TRANSPARENT);

								dLastDureeEcouleeEssai =  dDureeEcouleeEssai;
							} 
						//------- Modif du 15/11/2010 par C.BERENGER ------ FIN ------------

						// Affichage de la relecture de vitesse sur le graphique
						iHandle = PlotLine (GiPanel, PANEL_MODE_GRAPHE_VITESSE, dX1Relect, dY1Relect, dX2Relect, dY2Relect, iCOUL_VITESSE);
						SetPlotAttribute (GiPanel, PANEL_MODE_GRAPHE_VITESSE, iHandle, ATTR_PLOT_THICKNESS, 2);

						ProcessSystemEvents();
					  	dTime = Timer();
					  	SyncWait(dTime, dDELAY_THREAD_VIT); 

						if(GetGiStartCycleVitesse() == 0){
							SetGiTimeDepartEssaiSpeed(0);
							//  - Mise � z�ro de la vitesse moteur
								SetGiErrVaria(ProgRampeVariateur(0, 0, GetPointerToGptstConfig(), (double)fVIT_DEB_ARRET, (double)fVIT_FIN_ARRET, dDUREE_ARRET, GetGiUnitVitesse()));
								ReleasePointerToGptstConfig();
								SetGiErrVaria(VariateurArret());
							
								GetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VITESSE, 	ATTR_DIMMED, &bDimmed1);
								GetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VIT_PRESS, ATTR_DIMMED, &bDimmed2);
								SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VITESSE, 	ATTR_DIMMED, 1);
								SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VIT_PRESS, ATTR_DIMMED, 1);							
							
							// Attente d'arr�t du moteur
							iNbEssais = 0;
							SetGdVitesseAProg(0.0);
							
							do{
								//GiErrVaria = VariateurConsigneVitesseAtteinte (&wConsigneAtteinte);
								iNbEssais++;
										// Lecture et affichage de la vitesse et de la pression
										LectEtAffichSpeedAndPress(1, 1, GiPanel, GiStatusPanel, 
																GetPointerToGptstConfig(), &fVitesse, &dPression, GetGiUnitVitesse(), GetGiUnitPression(), 
																&iErrUsb6008, &iErrVaria);
										ReleasePointerToGptstConfig();
								
								SetGiErrUsb6008(iErrUsb6008);
								SetGiErrVaria(iErrVaria);
								SetGfVitesse (fVitesse);
								SetGdPression(dPression); 					

							  	dTime = Timer();
							  	SyncWait(dTime, dDELAY_THREAD_VIT); 
								ProcessSystemEvents();
							}while (((fabs(fVitesse) > dVIT_ABS_START_TEST) && (iNbEssais < 30)) && (!GetGbQuitter()));

							// Arr�t de la ventilation
								SetGiErrUsb6008(Usb6008CommandeVentilationMoteur (iUSB6008_CMDE_VENTILATION_MOTEUR_INACTIFS));							
							
								SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VITESSE, ATTR_DIMMED,   bDimmed1);
								SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VIT_PRESS, ATTR_DIMMED, bDimmed2);
						}
					}while(GetGiStartCycleVitesse());

					SetGbEndCycleVitesse (1);
				}
			}   
	  	dTime = Timer();
	  	SyncWait(dTime, dDELAY_THREAD_VIT); 
		ProcessSystemEvents();    
	}
    
    return(0);
}

// DEBUT ALGO
//***************************************************************************
//static int CVICALLBACK ThreadCyclePression (void *functionData)
//***************************************************************************
//  - functionData: pointeur sur des donn�es
//
//  - Thread de gestion des cycles de pression
//
//  - 0 si OK, sinon 1
//***************************************************************************
// FIN ALGO
static int CVICALLBACK ThreadCyclePression (void *functionData)
{   
#define sFORMAT_TIME_PRESS(iTempsSecondes, TpsEcoule)									\
{																						\
	iHeures = iTempsSecondes/3600;														\
	iMinutes = (iTempsSecondes/60) - (iHeures*60);										\
	iSecondes = iTempsSecondes%60;														\
	sprintf(TpsEcoule, sFORMAT_DUREE_ECOULEE, iHeures, iMinutes, iSecondes);			\
}

#define dDELAY_THREAD_PRESS 0.2
BOOL bDimmed1;
BOOL bDimmed2;
char sTpsEcoule[50];
int iHeures;
int iMinutes;
int iSecondes;
float fVitesse=0.0;
double dPression=0.0;
double dX1RelectCons;
double dY1RelectCons;
double dX2RelectCons;
double dY2RelectCons;

double dX1Relect;
double dY1Relect;
double dX2Relect;
double dY2Relect;

double dX1Config;
double dY1Config;
double dX2Config;
double dY2Config;
double dDureePrevue=0.0;
double dDureeEcouleeCycle=0.0;
double dDureeEcouleeRampe=0.0;
double dDureeEcouleeEssai=0.0;
double dDureeEcouleeCmde=0.0;

double dPente;
double dCste;
double dPressionPrevue;
double dDelayCmdPress;
double dLastDureeEcouleeEssai;
double dMin;
double dMax;

double dTime;

double dPlageAffichManu = 60.0;
char sLabel[20];
int iErr;
int iTimeDepCmde; 
int iTimeDepart;
int iTimeDepartRampe;
int iOldStep=0;
int iNumCycle=1;
int iNbCyclesPrevus=1;
int iIndexStepPression=1;
int iIndexMeas=1;
int iHandle=0;
int iNbEssais=1;
int iSelectionHandlePression=0;
int iErrUsb6008=0;
int iErrVaria=0;
stConfig *ptstConfig;

	ptstConfig = GetPointerToGptstConfig();
	dDelayCmdPress = ((double)ptstConfig->iPressCommandDelay) / 1000;
	dPlageAffichManu = ptstConfig->dPlageAffichManu;
	ReleasePointerToGptstConfig();
	
	iTimeDepCmde = 0;
	
	while (!GetGbQuitter()) {
		//--------- MODE AUTOMATIQUE --------
		if (GetGiMode() == iMODE_AUTOMATIQUE){ 
			// Si le cycle de pression est lanc�
			if (GetGiStartCyclePression()){ 
				SetGbEndCyclePression(0);

					// Effacement et trac� du graphique
					//GstGrapheMajGraphePres(GiPanel, PANEL_MODE_TABLE_PRESSION, PANEL_MODE_GRAPHE_PRESSION, 1, GstTabPression.dDuree, GstTabPression.dPress, GstTabPression.iNbElmts, 1, iCOUL_CONS_PRESSION, 1);
				
				iIndexMeas = 0;
				SetGiTimeDepartEssaiPress(clock());

				// Initialisation du num�ro de cycle
				iNumCycle = 1;
				
					// Lecture du nombre de cycles pr�vus
					GetCtrlVal (GiPanel, PANEL_MODE_NBE_CYCLES_PRESSION, &iNbCyclesPrevus);
				
					// Affichage du num�ro de cycle en cours
					SetCtrlVal (GiPanel, PANEL_MODE_NUM_CYCLE_PRESSION, iNumCycle);
				 
				//----- Modification du 15/11/2010 par C.BERENGER ----- DEBUT -----------
				dX1Relect		= 0.0;
				dY1Relect		= 0.0;
				dX2Relect		= 0.0;
				dY2Relect		= 0.0;
				//----- Modification du 15/11/2010 par C.BERENGER ----- FIN -----------
				
				
				do{
					// Initialisations pour chaque cycle
					if(iNumCycle == 1){ 
						dX1Config		= 0.0;
						dY1Config		= 0.0;   
						dX2Config		= GstTabPression.dDuree[0];
						dY2Config 		= GstTabPression.dPress[0];   
					}else{
							dX1Config		= 0.0;
							dY1Config		= GstTabPression.dPress[GstTabPression.iNbElmts-1];   
							dX2Config		= GstTabPression.dDuree[0];
							dY2Config 		= GstTabPression.dPress[0];   
						}
					
					//----- Modification du 15/11/2010 par C.BERENGER ----- DEBUT -----------
					dX2Relect		= 0.0;
					//----- Modification du 15/11/2010 par C.BERENGER ----- FIN -----------					
					
					dDureeEcouleeCycle= 0.0;
					SetGiIndexStepPression(1);
					iIndexStepPression	= 1;
					iOldStep		= 1;
					iTimeDepart 	= clock();
					dDureePrevue 	= GstTabPression.dDuree[0];
			
						// Affichage du step en cours sur le graphique
						//iErr = DisplaySegmentActifGraph(GiPanel, PANEL_MODE_TABLE_PRESSION, PANEL_MODE_GRAPHE_PRESSION, 
						//						 		iIndexStepPression, GstTabPression.iNbElmts, iNumCycle, iCOUL_CONS_PRESSION, &iSelectionHandlePression);
			
						iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_PRESSION, iIndexStepPression, ATTR_USE_LABEL_TEXT, 1);
						sprintf(sLabel, ">%d>", iIndexStepPression);
						iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_PRESSION, iIndexStepPression, ATTR_LABEL_POINT_SIZE, 15);				
						iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_PRESSION, iIndexStepPression, ATTR_LABEL_TEXT, sLabel);
						iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_PRESSION, iIndexStepPression, ATTR_LABEL_BOLD, 1);
						//-------- Modification du 15/11/2010 par C. BERENGER ----- DEBUT -------------
						// On met toujours dans le haut du tableau la ligne en cours
						SetCtrlAttribute (GiPanel, PANEL_MODE_TABLE_PRESSION, ATTR_FIRST_VISIBLE_ROW, iIndexStepPression);
					//-------- Modification du 15/11/2010 par C. BERENGER ----- FIN ------------- 

					// On d�roule le cycle de pression
					do{
						// Calcul de la dur�e de l'essai
						dDureeEcouleeEssai = (double)((clock() - GetGiTimeDepartEssaiPress())) / ((double)CLOCKS_PER_SEC);
						//Affichage de la dur�e de l'essai � l'�cran
						sFORMAT_TIME_PRESS((int)dDureeEcouleeEssai, sTpsEcoule)
						
							SetCtrlVal (GiPanel, PANEL_MODE_AFFICH_TPS_PRESS, sTpsEcoule);
						
						// Affichage du temps �coul�
						dDureeEcouleeCycle = (double)((clock() - iTimeDepart)) / ((double)CLOCKS_PER_SEC);

						// Incr�mentation du num�ro de step
						if (dDureeEcouleeCycle > dDureePrevue){
							iIndexStepPression++;
						
							if (iIndexStepPression <= GstTabPression.iNbElmts){
								dDureePrevue += GstTabPression.dDuree[iIndexStepPression-1];
								
								dX1Config	= dX2Config;
								dY1Config	= dY2Config;
								dX2Config	+= GstTabPression.dDuree[iIndexStepPression-1];
								dY2Config 	= GstTabPression.dPress[iIndexStepPression-1];   
	
									// Affichage du step en cours sur le graphique
									//iErr = DisplaySegmentActifGraph(GiPanel, PANEL_MODE_TABLE_PRESSION, PANEL_MODE_GRAPHE_PRESSION, 
									//						 		iIndexStepPression, GstTabPression.iNbElmts, iNumCycle,iCOUL_CONS_PRESSION, &iSelectionHandlePression);
								
									// On met toujours dans le haut du tableau la ligne en cours
									SetCtrlAttribute (GiPanel, PANEL_MODE_TABLE_PRESSION, ATTR_FIRST_VISIBLE_ROW, iIndexStepPression);
				
									// S�lection du step en cours dans le tableau
									if (iOldStep != 0){
										iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_PRESSION, iOldStep, ATTR_USE_LABEL_TEXT, 1);
										sprintf(sLabel, "%d", iOldStep);
										iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_PRESSION, iOldStep, ATTR_LABEL_POINT_SIZE, 11);
										iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_PRESSION, iOldStep, ATTR_LABEL_TEXT, sLabel);
										iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_PRESSION, iOldStep, ATTR_LABEL_BOLD, 0);
									}
				
									iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_PRESSION, iIndexStepPression, ATTR_USE_LABEL_TEXT, 1);
									sprintf(sLabel, ">%d>", iIndexStepPression);
									iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_PRESSION, iIndexStepPression, ATTR_LABEL_POINT_SIZE, 15);				
									iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_PRESSION, iIndexStepPression, ATTR_LABEL_TEXT, sLabel);
									iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_PRESSION, iIndexStepPression, ATTR_LABEL_BOLD, 1);
								
								iOldStep = iIndexStepPression;
							}
						}

						if (iIndexStepPression <= GstTabPression.iNbElmts) {
							// Calcul de la pression � programmer
							if (((dX2Config - dX1Config) > -0.001) && ((dX2Config - dX1Config) < 0.001)){
								SetGdPressionAProg(dY2Config);
							}
							else{
									dPente = (dY2Config - dY1Config) / (dX2Config - dX1Config);
									dCste = dY1Config - (dPente * dX1Config);
							
									SetGdPressionAProg(dPente * dDureeEcouleeCycle + dCste);
								}
							
							dDureeEcouleeCmde = (double)((clock() - iTimeDepCmde)) / ((double)CLOCKS_PER_SEC);
							
							// La commande de la pression se fait seulement � la vitesse d�finie dans le fichier de configuration
							if(dDureeEcouleeCmde > dDelayCmdPress){
								// Programmation de la pression
									iErr = ProgPression(GetPointerToGptstConfig(), GetGdPressionAProg(), GetGiUnitPression());
									ReleasePointerToGptstConfig();
								
								iTimeDepCmde = clock();
							}
								
							dX1Relect		= dX2Relect;
							dY1Relect		= dY2Relect;
							dX2Relect		= dDureeEcouleeCycle;
							dY2Relect		= GetGdPression();
			
								// Affichage de la pression sur le graphique
								iHandle = PlotLine (GiPanel, PANEL_MODE_GRAPHE_PRESSION, dX1Relect, dY1Relect, dX2Relect, dY2Relect, iCOUL_PRESSION);
								SetPlotAttribute (GiPanel, PANEL_MODE_GRAPHE_PRESSION, iHandle, ATTR_PLOT_THICKNESS, 2);
							
							iIndexMeas++;
						}
						
						// Lecture de la pression
						if((!GetGiStartCycleVitesse()) && GetGbEndCycleVitesse ()){
								LectEtAffichSpeedAndPress((!GetGiStartCycleVitesse()) && GetGbEndCycleVitesse (), (!GetGiStartCycleVitesse()) && GetGbEndCycleVitesse (), GiPanel, GiStatusPanel, 
															GetPointerToGptstConfig(), &fVitesse, &dPression, GetGiUnitVitesse(), GetGiUnitPression(), 
															&iErrUsb6008, &iErrVaria);
								ReleasePointerToGptstConfig();
							
							SetGiErrUsb6008(iErrUsb6008);
							SetGiErrVaria(iErrVaria);							
						}
						
						// Mise � jour des variables globales
						//-------------------------------------
						if((!GetGiStartCycleVitesse()) && GetGbEndCycleVitesse ()) 
							SetGdPression(dPression);
						
						SetGiSelectionHandlePression(iSelectionHandlePression);
						SetGdDurEcoulEssaiPress(dDureeEcouleeEssai);
						
						if(iIndexStepPression <= GstTabPression.iNbElmts)
							SetGiIndexStepPression(iIndexStepPression);
							
						if(iNumCycle <= iNbCyclesPrevus)
							SetGiIndexCyclePression(iNumCycle);	
						//------------------------------------
						
						ProcessSystemEvents();  
					  	dTime = Timer();
					  	SyncWait(dTime, dDELAY_THREAD_PRESS); 
					}while((GetGiStartCyclePression()) && (iIndexStepPression <= GstTabPression.iNbElmts));
			
					if (iOldStep != 0){ 
							iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_PRESSION, iOldStep, ATTR_USE_LABEL_TEXT, 1);
							sprintf(sLabel, "%d", iOldStep);
							iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_PRESSION, iOldStep, ATTR_LABEL_POINT_SIZE, 11);
							iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_PRESSION, iOldStep, ATTR_LABEL_TEXT, sLabel);
							iErr = SetTableRowAttribute (GiPanel, PANEL_MODE_TABLE_PRESSION, iOldStep, ATTR_LABEL_BOLD, 0);
					}
					 
					// Remise � z�ro du temps des pressions
					SetGbRazTimePress(1);
					
					if (GetGiStartCyclePression() == 1)
						// Incr�mentation du num�ro de cycle en cours
						iNumCycle++;
					
					if (iNumCycle <= iNbCyclesPrevus){
							// Affichage du num�ro de cycle en cours
							SetCtrlVal (GiPanel, PANEL_MODE_NUM_CYCLE_PRESSION, iNumCycle);
	
							if (GetGiStartCyclePression() == 1)
								// Effacement et trac� du graphique
								//GstGrapheMajGraphePres(GiPanel, PANEL_MODE_TABLE_PRESSION, PANEL_MODE_GRAPHE_PRESSION, 1, GstTabPression.dDuree, GstTabPression.dPress, GstTabPression.iNbElmts, iNumCycle, iCOUL_CONS_PRESSION, 1);
					}
					
					ProcessSystemEvents();  
				  	dTime = Timer();
				  	SyncWait(dTime, dDELAY_THREAD_PRESS); 					
				}while((iNumCycle <= iNbCyclesPrevus) && (GetGiStartCyclePression() == 1));
	
				SetGiTimeDepartEssaiPress(0);

				// Remise � z�ro de la pression en fin de cycle
				SetGdPressionAProg(0.0);
					SetGiErrUsb6008(ProgPression(GetPointerToGptstConfig(), GetGdPressionAProg(), GetGiUnitPression()));
					ReleasePointerToGptstConfig();
				
					GetCtrlAttribute (GiPanel, PANEL_MODE_BUT_START_PRESSION, 	ATTR_DIMMED, 	&bDimmed1);
					GetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VIT_PRESS, ATTR_DIMMED, 	&bDimmed2);
					SetCtrlAttribute (GiPanel, PANEL_MODE_BUT_START_PRESSION, 	ATTR_DIMMED,  	1);
					SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VIT_PRESS, ATTR_DIMMED, 	1);				
				
				// Attente de remise � z�ro de la pression
				iNbEssais = 0;
				do{
					// Lecture de la pression
					if((!GetGiStartCycleVitesse()) && GetGbEndCycleVitesse ()){
							LectEtAffichSpeedAndPress((!GetGiStartCycleVitesse()) && GetGbEndCycleVitesse (), (!GetGiStartCycleVitesse()) && GetGbEndCycleVitesse (), GiPanel, GiStatusPanel, 
														GetPointerToGptstConfig(), &fVitesse, &dPression, GetGiUnitVitesse(), GetGiUnitPression(), 
														&iErrUsb6008, &iErrVaria);
							ReleasePointerToGptstConfig();
						SetGiErrUsb6008(iErrUsb6008);
						SetGiErrVaria(iErrVaria);					   	
					}
					
					if((!GetGiStartCycleVitesse()) && GetGbEndCycleVitesse ()) 
						SetGdPression(dPression);
						
					iNbEssais++;
				  	dTime = Timer();
				  	SyncWait(dTime, dDELAY_THREAD_PRESS);					
					ProcessSystemEvents();  
				}while (((GetGdPression() > ConvLimPression(dMAX_PRESS_START_TEST, GetGiUnitPression())) && (iNbEssais < 30)) && (!GetGbQuitter()));
				
					SetCtrlAttribute (GiPanel, PANEL_MODE_BUT_START_PRESSION, ATTR_DIMMED,  	bDimmed1);
					SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VIT_PRESS, ATTR_DIMMED, 	bDimmed2);
				
					SetGiStartCyclePression(0);
					// Fin du cycle
					iErr = GstIhmCycles(GiPanel, GetGiStartVitPress(), GetGiStartCycleVitesse(), GetGiStartCyclePression());				
				
				SetGbEndCyclePression(1);
			}
		}  
		else{
				//--------- MODE MANUEL --------
				dX1Config 		= 0.0;
				dY1Config 		= 0.0;
				dX2Config 		= 0.0;
				dY2Config 		= 0.0;
				
				dX1Relect		= 0.0;
				dY1Relect		= 0.0;
				dX2Relect		= 0.0;
				dY2Relect		= 0.0;				

				dX1RelectCons	= 0.0;
				dY1RelectCons	= 0.0;
				dX2RelectCons	= 0.0;
				dY2RelectCons	= 0.0;				
				
				dPente 			= 0.0;
				dCste			= 0.0;
				
				dMin			= 0.0;
				dMax			= 0.0;
				
				dLastDureeEcouleeEssai = 0.0;
				
				iTimeDepCmde	= 0;

				SetGdPressionAProg(0.0);
				SetGiIndexStepPression(0);
				SetGiIndexCyclePression(0);	

				if (GetGiStartCyclePression()){
					SetGbEndCyclePression(0); 
					//------- Modif du 15/11/2010 par C.BERENGER ------ DEBUT ------------
						SetAxisScalingMode (GiPanel, PANEL_MODE_GRAPHE_PRESSION, VAL_BOTTOM_XAXIS, VAL_AUTOSCALE, 0.0, 100.0);					
					//------- Modif du 15/11/2010 par C.BERENGER ------ FIN ------------
					
					SetGiIndexStepPression(0);
					SetGiIndexCyclePression(0);				
					
					// Reset du graphique 
						DeleteGraphPlot (GiPanel, PANEL_MODE_GRAPHE_PRESSION, -1, VAL_IMMEDIATE_DRAW);
					
					// Temps de d�part
					SetGiTimeDepartEssaiPress(clock()); 
					iTimeDepartRampe = clock(); 
					
					// Si le cycle de pression est lanc�
					do{
						// Lecture de la valeur de pression � programmer
							GetCtrlVal (GiPanel, PANEL_MODE_SAISIE_PRESSION_MANU, &dPressionPrevue);
					   	
						if (dY2Config != dPressionPrevue){
								GetCtrlVal (GiPanel, PANEL_MODE_SAISIE_DUREE_PRES_MAN, &dDureePrevue);
							
							dX1Config = 0.0;
							dX2Config = dDureePrevue;
							dY1Config = dY2RelectCons;//dY2Config;
							dY2Config = dPressionPrevue;
						
							// Calcul de la pression � programmer
							if (((dX2Config - dX1Config) > -0.001) && ((dX2Config - dX1Config) < 0.001)){
								dPente = 0.0;
								dCste = 0.0;
								SetGdPressionAProg(dY2Config);
							}
							else{
									dPente = (dY2Config - dY1Config) / (dX2Config - dX1Config);
									dCste = dY1Config - (dPente * dX1Config);
								}						
								
							// Mise � z�ro de la dur�e �coul�e
							dDureeEcouleeCycle = 0.0;
							// Temps de d�part
							iTimeDepartRampe = clock(); 
						}

						dDureeEcouleeRampe = (double)((clock() - iTimeDepartRampe)) / ((double)CLOCKS_PER_SEC);
						
						// Rampe
						if (dDureeEcouleeRampe <= dDureePrevue){
							// Calcul de la pression � programmer
							SetGdPressionAProg(dPente * dDureeEcouleeRampe + dCste);					
						}
						else
							// Palier
							SetGdPressionAProg(dPressionPrevue);
						
						
						dDureeEcouleeCmde = (double)((clock() - iTimeDepCmde)) / ((double)CLOCKS_PER_SEC);
						
						// La commande de la pression se fait seulement � la vitesse d�finie dans le fichier de configuration
						if(dDureeEcouleeCmde > dDelayCmdPress){
							// Programmation de la pression
								iErr = ProgPression(GetPointerToGptstConfig(), GetGdPressionAProg(), GetGiUnitPression());
								ReleasePointerToGptstConfig();
							iTimeDepCmde = clock();
						}
					
						// Calcul de la dur�e de l'essai
						dDureeEcouleeEssai = (double)((clock() - GetGiTimeDepartEssaiPress())) / ((double)CLOCKS_PER_SEC);
						//Affichage de la dur�e de l'essai � l'�cran
						sFORMAT_TIME_PRESS((int)dDureeEcouleeEssai, sTpsEcoule) 
						
							SetCtrlVal (GiPanel, PANEL_MODE_AFFICH_TPS_PRESS, sTpsEcoule);
					   	
						// Lecture de la pression
						if((!GetGiStartCycleVitesse()) && GetGbEndCycleVitesse ()){
								LectEtAffichSpeedAndPress((!GetGiStartCycleVitesse()) && GetGbEndCycleVitesse (), (!GetGiStartCycleVitesse()) && GetGbEndCycleVitesse (), GiPanel, GiStatusPanel, 
															GetPointerToGptstConfig(), &fVitesse, &dPression, GetGiUnitVitesse(), GetGiUnitPression(), 
															&iErrUsb6008, &iErrVaria);
								ReleasePointerToGptstConfig();
							SetGiErrUsb6008(iErrUsb6008);
							SetGiErrVaria(iErrVaria);							
						}
						
						// Mise � jour des variables globales
						//-------------------------------------
						if((!GetGiStartCycleVitesse()) && GetGbEndCycleVitesse ()) 
							SetGdPression(dPression);
							
						SetGdDurEcoulEssaiPress(dDureeEcouleeEssai);
						//------------------------------------


						// Calcul de la consigne de pression sur le graphique
						dX1RelectCons	= dX2RelectCons;
						dY1RelectCons	= dY2RelectCons;
						dX2RelectCons	= dDureeEcouleeEssai;
						dY2RelectCons	= GetGdPressionAProg();

							// Affichage de la consigne de pression sur le graphique
							iHandle = PlotLine (GiPanel, PANEL_MODE_GRAPHE_PRESSION, dX1RelectCons, dY1RelectCons, dX2RelectCons, dY2RelectCons, iCOUL_CONS_PRESSION);
							SetPlotAttribute (GiPanel, PANEL_MODE_GRAPHE_PRESSION, iHandle, ATTR_PLOT_THICKNESS, 1);
						
						// Calcul de la relecture de pression sur le graphique
						dX1Relect	= dX2Relect;
						dY1Relect	= dY2Relect;
						dX2Relect	= dDureeEcouleeEssai;
						dY2Relect	= GetGdPression();

							// Affichage de la relecture de pression sur le graphique
							iHandle = PlotLine (GiPanel, PANEL_MODE_GRAPHE_PRESSION, dX1Relect, dY1Relect, dX2Relect, dY2Relect, iCOUL_PRESSION);
							SetPlotAttribute (GiPanel, PANEL_MODE_GRAPHE_PRESSION, iHandle, ATTR_PLOT_THICKNESS, 2);
						
						//------- Modif du 15/11/2010 par C.BERENGER ------ DEBUT ------------
						if(dY2RelectCons < dMin) dMin = dY2RelectCons;
						if(dY2RelectCons > dMax) dMax = dY2RelectCons;
						if(dY2Relect < dMin) dMin = dY2Relect;
						if(dY2Relect > dMax) dMax = dY2Relect;

						if(dDureeEcouleeEssai > dPlageAffichManu)
							if(dDureeEcouleeEssai - dLastDureeEcouleeEssai > dPlageAffichManu){
									// Reset du graphique 
									DeleteGraphPlot (GiPanel, PANEL_MODE_GRAPHE_PRESSION, -1, VAL_IMMEDIATE_DRAW);
									SetAxisScalingMode (GiPanel, PANEL_MODE_GRAPHE_PRESSION, VAL_BOTTOM_XAXIS, VAL_MANUAL, dDureeEcouleeEssai, dDureeEcouleeEssai + dPlageAffichManu);
									// Points pour garder l'�chelle pr�c�dente car autoscale vertical
									PlotPoint (GiPanel, PANEL_MODE_GRAPHE_PRESSION, dDureeEcouleeEssai, dMax, VAL_NO_POINT, VAL_TRANSPARENT);
									PlotPoint (GiPanel, PANEL_MODE_GRAPHE_PRESSION, dDureeEcouleeEssai, dMin, VAL_NO_POINT, VAL_TRANSPARENT);
									dLastDureeEcouleeEssai =  dDureeEcouleeEssai;
							}
						//------- Modif du 15/11/2010 par C.BERENGER ------ FIN ------------
						 
						if(GetGiStartCyclePression() == 0){
							SetGiTimeDepartEssaiPress(0);
							// Reset de la pression
								SetGiErrUsb6008(ProgPression(GetPointerToGptstConfig(), 0.0, GetGiUnitPression()));
								ReleasePointerToGptstConfig();
						}

					  	dTime = Timer();
					  	SyncWait(dTime, dDELAY_THREAD_PRESS);						
						ProcessSystemEvents();  
					}while(GetGiStartCyclePression());
					
					// Remise � z�ro de la pression en fin de cycle
					SetGdPressionAProg(0.0);
						SetGiErrUsb6008(ProgPression(GetPointerToGptstConfig(), GetGdPressionAProg(), GetGiUnitPression()));
						ReleasePointerToGptstConfig();

						GetCtrlAttribute (GiPanel, PANEL_MODE_BUT_START_PRESSION, 	ATTR_DIMMED,   	&bDimmed1);
						GetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VIT_PRESS, ATTR_DIMMED, 	&bDimmed2);
						SetCtrlAttribute (GiPanel, PANEL_MODE_BUT_START_PRESSION,  	ATTR_DIMMED,   	1);
						SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VIT_PRESS, ATTR_DIMMED, 	1);				
					
					// Attente de remise � z�ro de la pression
					iNbEssais = 0;
					do{
						// Lecture de la pression
						if((!GetGiStartCycleVitesse()) && GetGbEndCycleVitesse ()){
								LectEtAffichSpeedAndPress((!GetGiStartCycleVitesse()) && GetGbEndCycleVitesse (), (!GetGiStartCycleVitesse()) && GetGbEndCycleVitesse (), GiPanel, GiStatusPanel, 
															GetPointerToGptstConfig(), &fVitesse, &dPression, GetGiUnitVitesse(), GetGiUnitPression(), 
															&iErrUsb6008, &iErrVaria);
								ReleasePointerToGptstConfig();
							SetGiErrUsb6008(iErrUsb6008);
							SetGiErrVaria(iErrVaria);							
						}
						
						if((!GetGiStartCycleVitesse()) && GetGbEndCycleVitesse ()) 
							SetGdPression(dPression);

						iNbEssais++;
						
					  	dTime = Timer();
					  	SyncWait(dTime, dDELAY_THREAD_PRESS);						
						ProcessSystemEvents();  
					}while (((GetGdPression() > ConvLimPression(dMAX_PRESS_START_TEST, GetGiUnitPression())) && (iNbEssais < 30)) && (!GetGbQuitter()));
				
						SetCtrlAttribute (GiPanel, PANEL_MODE_BUT_START_PRESSION, ATTR_DIMMED,   bDimmed1);
						SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VIT_PRESS, ATTR_DIMMED, bDimmed2);				

					SetGbEndCyclePression(1); 
				}
			}
		
		dTime = Timer();
		SyncWait(dTime, dDELAY_THREAD_PRESS);
		ProcessSystemEvents();    
	}

	return(0);
}

// DEBUT ALGO
//***************************************************************************
// void ConvertPointToVirg(char *sMsgToConvert)
//***************************************************************************
//  - char *sMsgToConvert	: Cha�ne de caract�res � traiter
//
//  - Remplacement des points par des virgules dans la cha�ne de caract�res
//
//  - Aucun 
//***************************************************************************
// FIN ALGO
void ConvertPointToVirg(char *sMsgToConvert)
{
char *ptChar;

	ptChar = strchr(sMsgToConvert, '.');
	while(ptChar!=NULL){
		*ptChar = ',';
		ptChar = strchr(sMsgToConvert, '.');
	}
}

// DEBUT ALGO
//***************************************************************************
//static int CVICALLBACK ThreadAcquisitions (void *functionData)
//***************************************************************************
//  - functionData: pointeur sur des donn�es
//
//  - Thread d'acquisition de la vitesse moteur et de la pression
//
//  - 0 si OK, sinon 1
//***************************************************************************
// FIN ALGO
//static int CVICALLBACK ThreadAcquisitions (void *functionData)
int CVICALLBACK ThreadAcquisitions (int reserved, int theTimerId, int event,
                                 void *callbackData, int eventData1,
                                 int eventData2)
{   
#define iMAX_DATA_CLOSE_FILE	50
#define dDELAY_THREAD_ACQUIS 	0.2
char sTitle[500]="";	  
float fVitesse;	
double dPression;
double dTime;
static char sMsg[2000];
double dTimeElapsed;
double dDelay;
double dDureeEcouleeRecord;
char sDateHeure[50];
char sResult[5000];
char sValSpeed[100];
char sValPress[100];
char sFileName[200];
int iIndexMeasSpeed	= 1;
int iIndexMeasPress	= 1;
int iErr;
int iTimeDepRecord;
int iIndexCycle;
int iLastStatusVaria= -1;
int iLastStatusUsb 	= -1;
int iErrUsb6008 	= 0;
int iErrVaria		= 0;
int iHandleFileResult;
int iIndexCloseFile = 0;
int iSaveData=1;
BOOL bClose;
stConfig *ptstConfig;
stTabFile stLocalTabFile[1];



	SetGiAffMsg(0);
	
	ptstConfig = GetPointerToGptstConfig();
	iSaveData = ptstConfig->iSaveResults;
	ReleasePointerToGptstConfig();
	
	
	if (event == EVENT_TIMER_TICK){
	//while (!GetGbQuitter()) {		
		// Mise � jour du status de la communication avec le variateur
		// Lecture et affichage de la vitesse et de la pression
		if ((!GetGiStartCycleVitesse()) && (!GetGiStartCyclePression()) && (GetGbEndCycleVitesse ()) && (GetGbEndCyclePression())){
				LectEtAffichSpeedAndPress((!GetGiStartCycleVitesse()) && GetGbEndCycleVitesse (), (!GetGiStartCyclePression()) && GetGbEndCyclePression(), GiPanel, GiStatusPanel, 
										GetPointerToGptstConfig(), &fVitesse, &dPression, GetGiUnitVitesse(), GetGiUnitPression(), 
										&iErrUsb6008, &iErrVaria);
				ReleasePointerToGptstConfig();
			//----------------------------
			SetGiErrUsb6008(iErrUsb6008);
			SetGiErrVaria(iErrVaria);
			SetGfVitesse (fVitesse);
			SetGdPression(dPression);
			//----------------------------
		}
		
		iErr = 0;

		// Enregistrement des r�sultats si au moins un cycle (vitesse ou pression) est lanc�
		if ((GetGiStartCycleVitesse() || GetGiStartCyclePression()) && (iSaveData==1)){
			// Si le fichier n'a pas �t� cr��
			//-------------------------------
			if (GetGiHandleFileResult() < 0){
					if(iErr == 0){ 
						// Cr�ation du r�pertoire r�sultats
						iErr = CreateRepResultIfNeeded();
						CHECK_ERROR(iErr, "Error", sMSG_ERR_CREAT_RES_DIR)
					}
				
					if(iErr == 0){
						GstFilesGetStringDateHeure(sDateHeure);
				
						if (GetGiMode() == iMODE_AUTOMATIQUE){
							sprintf(sFileName, "%s_Auto_", sDateHeure);
							// Cr�ation du fichier r�sultats et copie du fichier de configuration
							iErr = GstFilesCreateResultFiles(1, GsPathConfigFile, &stLocalTabFile[0], GsPathResult, sFileName, sEXT_FICHIERS, &iHandleFileResult, sMsg);   
				
							//---------------------------------------
							SetGiHandleFileResult(iHandleFileResult);
							//---------------------------------------
						}else{
								sprintf(sFileName, "%s_Man_", sDateHeure);
								// Cr�ation du fichier r�sultats et copie du fichier de configuration
								// Init Dll
								iErr = GstFilesCreateResultFiles(0, GsPathConfigFile, &stLocalTabFile[0], GsPathResult, sFileName, sEXT_FICHIERS, &iHandleFileResult, sMsg);   

								//---------------------------------------
								SetGiHandleFileResult(iHandleFileResult);
								//---------------------------------------
							}
						CHECK_ERROR(iErr,"Error creating result files", sMsg)					
					}

					sprintf(sResult, sMSG_ENT_MEAS_SPEED); 
			
					switch(GetGiUnitVitesse()){
						case iUNIT_KM_H:
							strcat(sResult, sAFFICH_VITESSE_KM_H);
						break;
						case iUNIT_G:
							strcat(sResult, sAFFICH_VITESSE_G);
						break;
						case iUNIT_TRS_MIN:
							strcat(sResult, sAFFICH_VITESSE_TRS_MIN);
						break;
					}
			
					strcat(sResult, sMSG_ENT_MEAS_PRESS);

					switch(GetGiUnitPression()){
						case iUNIT_KPA:
							strcat(sResult, sAFFICH_PRES_KPA);
						break;
						case iUNIT_BAR:
							strcat(sResult, sAFFICH_PRES_BARS);	
						break;
						case iUNIT_MBAR:
							strcat(sResult, sAFFICH_PRES_MBAR);
						break;
						case iUNIT_PSI:
							strcat(sResult, sAFFICH_PRES_PSI);
						break;
					}
					strcat(sResult, ";");

					if(iErr == 0){
						// Ajout d'une ligne dans le fichier r�sultats
						iErr = GstFilesAddResultFiles(&stLocalTabFile[0], iHandleFileResult, sResult, 1, sMsg);
						//---- Modification du 04/04/2013 par CB --- DEBUT ----------
						iErr = 0;
						//---- Modification du 04/04/2013 par CB --- FIN ----------
						CHECK_ERROR(iErr, sMSG_ERR_ADD_RES_LINE, sMsg)
					}
			}
			//--------------------------------------------
			
			
			//---------- Resultats -----------------------
			//dDureeEcouleeRecord = (double)((clock() - iTimeDepRecord)) / ((double)CLOCKS_PER_SEC);
			dDureeEcouleeRecord = *((double*)eventData1);
			
			// Si l'on doit r�aliser l'enregistrement d'une mesure
			//if(dDureeEcouleeRecord > dDelay){
				// R�init du temps entre deux enregistrements
				iTimeDepRecord = clock();
				strcpy(sResult, "");
			
				// Enregistrement des donn�es seulement apr�s la deuxi�me mesure
				if ((iIndexMeasSpeed > 0) || (iIndexMeasPress > 0)){ 
					// Ajout de la mesure de vitesse si n�cessaire
					if(GetGiStartCycleVitesse()){
						if (iIndexMeasSpeed > 0){
							sprintf(sValSpeed, iFORMAT_SPEED_RESULT, iIndexMeasSpeed,  GetGdDurEcoulEssaiSpeed(), GetGiIndexCycleVitesse(), GetGiIndexStepVitesse(), GetGdVitesseAProg() , GetGfVitesse ());
							strcat(sResult, sValSpeed);
						}
					}
					else
						strcat(sResult, ";;;;;;");

					// Ajout de la mesure de pression si n�cessaire
					if(GetGiStartCyclePression()){
						if (iIndexMeasPress > 0){
							if(GetGiStartCycleVitesse())
								dTimeElapsed = GetGdDurEcoulEssaiSpeed();
							else
								dTimeElapsed = (double)((clock() - GetGiTimeDepartEssaiPress())) / ((double)CLOCKS_PER_SEC);
							sprintf(sValPress, iFORMAT_PRESS_RESULT, iIndexMeasPress,  dTimeElapsed, GetGiIndexCyclePression(), GetGiIndexStepPression(), (float)GetGdPressionAProg(), (float)GetGdPression());
							strcat(sResult, sValPress);
						}
					}
					else
						strcat(sResult, "<->;;;;;;");

					if(iErr == 0){
						// Conversion des points en virgules pour traitement sous Excel
						ConvertPointToVirg(sResult);								   
			
						/*if(iIndexCloseFile > iMAX_DATA_CLOSE_FILE ){
							bClose = 1;
							iIndexCloseFile = 0;
						}
						else
							bClose = 0;
						*/
						bClose = 1; 
						
						// Ajout d'une ligne dans le fichier r�sultats
						iErr = GstFilesAddResultFiles(&stLocalTabFile[0], iHandleFileResult, sResult, bClose, sMsg);
						//---- Modification du 04/04/2013 par CB --- DEBUT ----------
						iErr = 0;
						//---- Modification du 04/04/2013 par CB --- FIN ----------
						// Incr�mentation du nombre d'�critures fichier
						iIndexCloseFile++;
							CHECK_ERROR(iErr, sMSG_ERR_ADD_RES_LINE, sMsg)
					}	
				}

				//----- VITESSE -----
				if(GetGiStartCycleVitesse()){
					// Incr�mentation du num�ro d'index des mesures
					iIndexMeasSpeed++;
				}

				//----- PRESSION -----
				if(GetGiStartCyclePression()){
					// Incr�mentation du num�ro d'index des mesures
					iIndexMeasPress++;
				} 
			//}
		}
		else{
				// Remise � z�ro de l'index de chaque mesure
				iIndexMeasSpeed 	= 0;
				iIndexMeasPress 	= 0;
				
				// Fermeture du fichier r�sultats si n�cessaire
				//if ((GetGiHandleFileResult() >= 0) && (iSaveData==1))
				//	GstFilesCloseResultFile(&stLocalTabFile[0], GetGiHandleFileResult(), sMsg); 
				
				GstFilesResetAll(&stLocalTabFile[0]);
				
				// Remise � z�ro du handle de fichier r�sultats
				SetGiHandleFileResult(-1);
				// Arr�t de la t�che d'acquisition
				SetAsyncTimerAttribute (GiThreadAcquisitions, ASYNC_ATTR_ENABLED, 0);
			} 
		
		//ProcessSystemEvents();
	  	//dTime = Timer();
	  	//SyncWait(dTime, dDELAY_THREAD_ACQUIS);		
	}
	//else	
	/* We will get an EVENT_DISCARD when the timer is destroyed. */
    //	if (event == EVENT_DISCARD) 
      //  	g_timerId = 0;

	return(0);
}

// DEBUT ALGO
//***************************************************************************
// int RetourEtatAttente(int *ptiPorte1Ouverte, int *ptiPorte2Ouverte, int *ptiCapotOuvert, 
//						int *ptiBoucleSecOuv, int *ptiMoteurArret, int *pt&iArretUrgence)
//***************************************************************************
//  - int *ptiPorte1Ouverte		: Etat de la porte 1 
//	  int *ptiPorte2Ouverte		: Etat de la porte 2
//	  int *ptiCapotOuvert 		: Etat du capot de protection
//	  int *ptiBoucleSecOuv		: Etat de la boucle de s�curit�
//	  int *ptiMoteurArret		: Etat du moteur
//	  int *pt&iArretUrgence		: Etat du bouton d'arr�t d'urgence
//
//  - Fonction v�rifiant si les conditions pour revenir � l'�tat d'attente 
//	  sont remplies
//
//  - 1 s'il faut revenir � l'�tat d'attente, sinon 0
//***************************************************************************
// FIN ALGO
int RetourEtatAttente(int *ptiPorte1Ouverte, int *ptiPorte2Ouverte, int *ptiCapotOuvert, 
						int *ptiBoucleSecOuv, int *ptiMoteurArret, int *ptiArretUrgence,
						int *ptiEtatCaptVib)
{

	// Initialisations
	*ptiPorte1Ouverte 	= iUSB6008_ETAT_PORTE_1_OUVERTE;
	*ptiPorte2Ouverte 	= iUSB6008_ETAT_PORTE_2_OUVERTE;
	*ptiCapotOuvert 	= iUSB6008_ETAT_CAPOT_SECURITE_OUVERT;
	*ptiBoucleSecOuv	= iUSB6008_ETAT_BOUCLE_SECURITE_OUVERTE;
	*ptiMoteurArret 	= !iUSB6008_ETAT_MOTEUR_ARRETE;
	*ptiArretUrgence 	= iUSB6008_ETAT_ARRET_URGENCE_ACTIF;
	*ptiEtatCaptVib 	= iUSB6008_ETAT_VIBRATIONS_DETECT_ACTIF;


	// Lecture des valeurs logiques
	SetGiErrUsb6008(Usb6008AcquisitionEtats (ptiPorte1Ouverte, ptiPorte2Ouverte, ptiCapotOuvert, 
											ptiBoucleSecOuv, ptiMoteurArret, ptiArretUrgence,
											ptiEtatCaptVib));	
	
	if (GetGiErrUsb6008()){
		return 1; // Une erreur s'est produite
	}
	
	// Mise � jour de l'�cran de status si besoin
	if (GetGiPanelStatusDisplayed()){
		SetCtrlVal (GiStatusPanel, PANEL_STAT_DOOR_1, 			(*ptiPorte1Ouverte));
		SetCtrlVal (GiStatusPanel, PANEL_STAT_DOOR_2, 			(*ptiPorte2Ouverte));
		SetCtrlVal (GiStatusPanel, PANEL_STAT_SECURITY_HOOD, 	(*ptiCapotOuvert));
		SetCtrlVal (GiStatusPanel, PANEL_STAT_SECURITY_LOOP, 	(*ptiBoucleSecOuv));
		SetCtrlVal (GiStatusPanel, PANEL_STAT_ENGINE_RUNNING, 	!(*ptiMoteurArret));
		SetCtrlVal (GiStatusPanel, PANEL_STAT_EMERGENCY_STOP, 	(*ptiArretUrgence));
	}

	// D�termine s'il faut revenir � l'�tat de d�part
	if(	(*ptiPorte1Ouverte 	== iUSB6008_ETAT_PORTE_1_OUVERTE) 			||
		(*ptiPorte2Ouverte 	== iUSB6008_ETAT_PORTE_2_OUVERTE) 			||
		(*ptiCapotOuvert 	== iUSB6008_ETAT_CAPOT_SECURITE_OUVERT) 	||
		(*ptiBoucleSecOuv 	== iUSB6008_ETAT_BOUCLE_SECURITE_OUVERTE)	||
		(*ptiMoteurArret 	!= iUSB6008_ETAT_MOTEUR_ARRETE) 			||
		(*ptiArretUrgence 	== iUSB6008_ETAT_ARRET_URGENCE_ACTIF)		||
		(*ptiEtatCaptVib 	== iUSB6008_ETAT_VIBRATIONS_DETECT_ACTIF))
		return  1;
	else{ 
			// Si l'�cran de status n'est pas affich�, alors affichage de celui-ci.
			return 0;
		}
}

// DEBUT ALGO
//***************************************************************************
// static int CVICALLBACK ThreadGestionSecurite (void *functionData)
//***************************************************************************
//  - functionData: pointeur sur des donn�es
//
//  - Thread de gestion de la s�curit� de l'op�rateur    
//
//  - 1 si probl�me d�tect�, 0 sinon
//***************************************************************************
// FIN ALGO
static int CVICALLBACK ThreadGestionSecurite (void *functionData)
{   
#define dDELAY_SECURITY_PROCESS 0.5
char sMsg[500];
int iPorte1Ouverte 	= iUSB6008_ETAT_PORTE_1_OUVERTE;
int iPorte2Ouverte 	= iUSB6008_ETAT_PORTE_2_OUVERTE;
int iCapotOuvert 	= iUSB6008_ETAT_CAPOT_SECURITE_OUVERT;
int iBoucleSecOuv	= iUSB6008_ETAT_BOUCLE_SECURITE_OUVERTE;
int iMoteurArret 	= iUSB6008_ETAT_MOTEUR_ARRETE;
int iArretUrgence 	= iUSB6008_ETAT_ARRET_URGENCE_ACTIF;
int iEtatCaptVib	= iUSB6008_ETAT_VIBRATIONS_DETECT_ACTIF;
int iNbPannesSucc 	= 0;
int iAffMsg		  	= 0;
int iPanelStatusDisplayed=0;
BOOL bAffichMsgAttente		= 1;
BOOL bAffichMsgAttElectLock	= 0;
BOOL bAffichMsgAttBoucle	= 0;
BOOL bAffichMsgAttDepEssai	= 0;
BOOL bAffichMsgEssEnCours	= 0;
float fVitesse;
double dTime;
int iLastStatusUsb = -1;
int iLastStatusVaria= -1;


	while (!GetGbQuitter()) {
			//-----------------------------------------------------------------------------------------------			
			if (GetGiErrVaria() == 0){
				if (iLastStatusVaria != GetGiErrVaria()){ 
						SetCtrlVal (GiStatusPanel, PANEL_STAT_VARIATOR_COMM, 1); //OK
						SetCtrlAttribute (GiStatusPanel, PANEL_STAT_SPEED, 			ATTR_DIMMED, 0);
						SetCtrlAttribute (GiStatusPanel, PANEL_STAT_ENGINE_RUNNING,	ATTR_DIMMED, 0);
						iLastStatusVaria = GetGiErrVaria();
				}
			}
			else{
					if (iLastStatusVaria != GetGiErrVaria()){ 
							SetCtrlVal (GiStatusPanel, PANEL_STAT_VARIATOR_COMM, 0); // ERREUR
							SetCtrlAttribute (GiStatusPanel, PANEL_STAT_SPEED, 			ATTR_DIMMED, 1);
							SetCtrlAttribute (GiStatusPanel, PANEL_STAT_ENGINE_RUNNING,	ATTR_DIMMED, 1);
							iLastStatusVaria = GetGiErrVaria();
					}
				} 
		
			// Mise � jour du status avec le module USB
			if (GetGiErrUsb6008() == 0){ 
				if (iLastStatusUsb != GetGiErrUsb6008()){
						SetCtrlVal (GiStatusPanel, PANEL_STAT_USB6008_COMM, 1); //OK
				
						SetCtrlAttribute (GiStatusPanel, PANEL_STAT_DOOR_1, 		ATTR_DIMMED, 0);
						SetCtrlAttribute (GiStatusPanel, PANEL_STAT_DOOR_2, 		ATTR_DIMMED, 0);
						SetCtrlAttribute (GiStatusPanel, PANEL_STAT_SECURITY_HOOD, 	ATTR_DIMMED, 0);
						SetCtrlAttribute (GiStatusPanel, PANEL_STAT_SECURITY_LOOP, 	ATTR_DIMMED, 0);
						SetCtrlAttribute (GiStatusPanel, PANEL_STAT_EMERGENCY_STOP, ATTR_DIMMED, 0);
						SetCtrlAttribute (GiStatusPanel, PANEL_STAT_PRESSURE, 		ATTR_DIMMED, 0);
				
						iLastStatusUsb = GetGiErrUsb6008(); 
				}
			}	
			else{
					if (iLastStatusUsb != GetGiErrUsb6008()){
							SetCtrlVal (GiStatusPanel, PANEL_STAT_USB6008_COMM, 0); // ERREUR
				
							SetCtrlAttribute (GiStatusPanel, PANEL_STAT_DOOR_1, 		ATTR_DIMMED, 1);
							SetCtrlAttribute (GiStatusPanel, PANEL_STAT_DOOR_2, 		ATTR_DIMMED, 1);
							SetCtrlAttribute (GiStatusPanel, PANEL_STAT_SECURITY_HOOD, 	ATTR_DIMMED, 1);
							SetCtrlAttribute (GiStatusPanel, PANEL_STAT_SECURITY_LOOP, 	ATTR_DIMMED, 1);
							SetCtrlAttribute (GiStatusPanel, PANEL_STAT_EMERGENCY_STOP, ATTR_DIMMED, 1);
							SetCtrlAttribute (GiStatusPanel, PANEL_STAT_PRESSURE, 		ATTR_DIMMED, 1);
					
							iLastStatusUsb = GetGiErrUsb6008();
					}
				} 
			//-----------------------------------------------------------------------------------------------
			
			
			if(GetGiEtat() == iETAT_ATTENTE_AFFICH_IHM){
			 ;
			}
			
			// Etat d'attente
			if(GetGiEtat() ==  iETAT_ATTENTE){
				if(bAffichMsgAttente){ 
						SetGiErrUsb6008(Usb6008CommandeVentilationMoteur (iUSB6008_CMDE_VENTILATION_MOTEUR_INACTIFS));
					fVitesse = GetGfVitesse();
					
					// Reset du chemnin vers le r�pertoire des r�sultats
					strcpy(GsPathResult, "");
					
					// Demande d'appui sur le bouton de la boucle de s�curit�
						// Reset du chemnin vers le r�pertoire des r�sultats
						strcpy(GsPathResult, "");
						ModesAddMessageZM(sMSG_SECURE_BENCH);
					
						bAffichMsgAttente = 0;

						// Mise � jour du voyant d'autorisation de d�part Essai
						SetCtrlVal (GiPanel, PANEL_MODE_START_ENABLE, 0);
				
						// Arr�t des cycles en cours
						SetGiStartCycleVitesse(0);
						SetGiStartCyclePression(0);
						SetGiStartVitPress(0);
						GstIhmCycles(GiPanel, GetGiStartVitPress(),  GetGiStartCycleVitesse(), GetGiStartCyclePression()); 

						// On interdit l'appui sur les boutons de d�part essai
						SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VITESSE, ATTR_DIMMED, 	1);
						SetCtrlAttribute (GiPanel, PANEL_MODE_BUT_START_PRESSION, ATTR_DIMMED, 	1);
						SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VIT_PRESS, ATTR_DIMMED, 1);
						
						// Arr�t de la t�che d'acquisition
						//SetAsyncTimerAttribute (GiThreadAcquisitions, ASYNC_ATTR_ENABLED, 0);
				}				

				fVitesse = GetGfVitesse();
				
				// Autorisation de l'ouverture g�che si le moteur ne tourne pas et si la pression est assez basse
				if ((fabs(fVitesse) < dVIT_ABS_START_TEST) && (GetGdPression() < ConvLimPression(dMAX_PRESS_START_TEST, GetGiUnitPression()))){
					SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_OUV_GACHE, ATTR_DIMMED, 0);
				}else{
						// Si la g�che �tait acive, alors inactivation
						if (GetGbGacheActive()){
								SetGiErrUsb6008(Usb6008CommandeOuvertureGache (iUSB6008_CMDE_OUVERTURE_GACHE_INACTIVE));

							// S'il n'y a pas d'erreur
							if(GetGiErrUsb6008() == 0){
								SetGbGacheActive(iGACHE_FERMEE);
								SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_OUV_GACHE, ATTR_LABEL_TEXT, "Open Electric Lock");
							}
						}
						
						SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_OUV_GACHE, ATTR_DIMMED, 1);  
					 }
			
				// Lecture des valeurs logiques
				RetourEtatAttente(&iPorte1Ouverte, &iPorte2Ouverte, &iCapotOuvert, 
								  &iBoucleSecOuv, &iMoteurArret, &iArretUrgence, &iEtatCaptVib);

				if(	(iPorte1Ouverte != iUSB6008_ETAT_PORTE_1_OUVERTE) 			&&
					(iPorte2Ouverte != iUSB6008_ETAT_PORTE_2_OUVERTE) 			&&
					(iCapotOuvert 	!= iUSB6008_ETAT_CAPOT_SECURITE_OUVERT) 	&&
					(iMoteurArret 	== iUSB6008_ETAT_MOTEUR_ARRETE) 			&&
					(GetGdPression() 	< ConvLimPression(dMAX_PRESS_START_TEST, GetGiUnitPression()))				&&
					(GetGiErrVaria() 	== 0)									&&
					(GetGiErrUsb6008() 	== 0)									&&
					(iArretUrgence 	!= iUSB6008_ETAT_ARRET_URGENCE_ACTIF)		&&
					(iEtatCaptVib 	!=iUSB6008_ETAT_VIBRATIONS_DETECT_ACTIF)){
					
					if(GetGbGacheActive() != iGACHE_FERMEE){
						// La gache doit �tre ferm�e pour lancer l'essai
						SetGiEtat(iETAT_DEM_CLOSE_ELECTRIC_LOCK);
						bAffichMsgAttElectLock = 1;
					}
					else{
							// Attente d'appui sur le bouton bleu
							SetGiEtat(iETAT_DEM_APP_BOUCLE_SECUR);
							bAffichMsgAttBoucle = 1;
						}
				}
			}
			
			
			// On demande l'appui sur le bouton de la boucle de s�curit�
			if(GetGiEtat() == iETAT_DEM_CLOSE_ELECTRIC_LOCK){
				// Autorisation de l'ouverture g�che si le moteur ne tourne pas et si la pression est assez basse
				fVitesse = GetGfVitesse();
				if ((fabs(fVitesse) < dVIT_ABS_START_TEST) && (GetGdPression() < ConvLimPression(dMAX_PRESS_START_TEST, GetGiUnitPression())))
					SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_OUV_GACHE, ATTR_DIMMED, 0);
				else
					SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_OUV_GACHE, ATTR_DIMMED, 1); 			
			
				// Lecture des valeurs logiques
				RetourEtatAttente(&iPorte1Ouverte, &iPorte2Ouverte, &iCapotOuvert, 
									 &iBoucleSecOuv, &iMoteurArret, &iArretUrgence, &iEtatCaptVib);

				if(	(iPorte1Ouverte == iUSB6008_ETAT_PORTE_1_OUVERTE) 			||
					(iPorte2Ouverte == iUSB6008_ETAT_PORTE_2_OUVERTE) 			||
					(iCapotOuvert 	== iUSB6008_ETAT_CAPOT_SECURITE_OUVERT) 	||
					(iMoteurArret 	!= iUSB6008_ETAT_MOTEUR_ARRETE) 			||
					(GetGdPression() > ConvLimPression(dMAX_PRESS_START_TEST, GetGiUnitPression())) 					||
					(GetGiErrVaria() 	!= 0)									||
					(GetGiErrUsb6008() 	!= 0)									||
					(iArretUrgence 	== iUSB6008_ETAT_ARRET_URGENCE_ACTIF)		||
					(iEtatCaptVib 	==iUSB6008_ETAT_VIBRATIONS_DETECT_ACTIF)){
					
					// On cache le message d'attente d'appui sur le bouton de la boucle de s�curit�
					SetCtrlAttribute (GiPanel, PANEL_MODE_MessageIndicateur, ATTR_VISIBLE, 0);
					bAffichMsgAttente = 1;
					SetGiEtat(iETAT_ATTENTE);
				}else{
						if(bAffichMsgAttElectLock){
							// Demande d'appui sur le bouton de fermeture de la g�che (sur l'IHM)
								ModesAddMessageZM(sMSG_CLOSE_ELECTRIC_LOCK);
							
								ResetTextBox (GiPanel, PANEL_MODE_MessageIndicateur, sMSG_CLOSE_ELECTRIC_LOCK);
							
								// Passage au premier plan du message
								SetCtrlAttribute (GiPanel, PANEL_MODE_MessageIndicateur, ATTR_VISIBLE, 1);
								SetCtrlAttribute (GiPanel, PANEL_MODE_MessageIndicateur, ATTR_ZPLANE_POSITION, 0);

							bAffichMsgAttElectLock = 0;
						}

						if (GetGbGacheActive() == iGACHE_FERMEE){
							bAffichMsgAttBoucle = 1;
							// On cache le message d'attente d'appui sur le bouton de la boucle de s�curit�
							SetCtrlAttribute (GiPanel, PANEL_MODE_MessageIndicateur, ATTR_VISIBLE, 0);
							SetGiEtat(iETAT_DEM_APP_BOUCLE_SECUR);
						}
					}
			}
			
			
			// On demande l'appui sur le bouton de la boucle de s�curit�
			if(GetGiEtat() ==  iETAT_DEM_APP_BOUCLE_SECUR){
				// Autorisation de l'ouverture g�che si le moteur ne tourne pas et si la pression est assez basse
				fVitesse = GetGfVitesse();
				if ((fabs(fVitesse) < dVIT_ABS_START_TEST) && (GetGdPression() < ConvLimPression(dMAX_PRESS_START_TEST, GetGiUnitPression())))
					SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_OUV_GACHE, ATTR_DIMMED, 0);
				else
					SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_OUV_GACHE, ATTR_DIMMED, 1); 			
			
				// Lecture des valeurs logiques
				RetourEtatAttente(&iPorte1Ouverte, &iPorte2Ouverte, &iCapotOuvert, 
									 &iBoucleSecOuv, &iMoteurArret, &iArretUrgence, &iEtatCaptVib);

				if(	(iPorte1Ouverte == iUSB6008_ETAT_PORTE_1_OUVERTE) 			||
					(iPorte2Ouverte == iUSB6008_ETAT_PORTE_2_OUVERTE) 			||
					(iCapotOuvert 	== iUSB6008_ETAT_CAPOT_SECURITE_OUVERT) 	||
					(iMoteurArret 	!= iUSB6008_ETAT_MOTEUR_ARRETE) 			||
					(GetGdPression() > ConvLimPression(dMAX_PRESS_START_TEST, GetGiUnitPression())) 					||
					(GetGiErrVaria() 	!= 0)									||
					(GetGiErrUsb6008() 	!= 0)									||
					(iArretUrgence 	== iUSB6008_ETAT_ARRET_URGENCE_ACTIF)		||
					(iEtatCaptVib 	==iUSB6008_ETAT_VIBRATIONS_DETECT_ACTIF)){
					// On cache le message d'attente d'appui sur le bouton de la boucle de s�curit�
					SetCtrlAttribute (GiPanel, PANEL_MODE_MessageIndicateur, ATTR_VISIBLE, 0);
					bAffichMsgAttente = 1;
					SetGiEtat(iETAT_ATTENTE);
				}else{
						if(bAffichMsgAttBoucle){
							// Demande d'appui sur le bouton de la boucle de s�curit�
								SetGiErrUsb6008(Usb6008CommandeVentilationMoteur (iUSB6008_CMDE_VENTILATION_MOTEUR_INACTIFS)); 
							
								ModesAddMessageZM(sMSG_PUSH_SEC_LOOP_BUTT);
								ResetTextBox (GiPanel, PANEL_MODE_MessageIndicateur, sMSG_PUSH_SEC_LOOP_BUTT);
							
								// On affiche le message d'attente d'appui sur le bouton de la boucle de s�curit�
								SetCtrlAttribute (GiPanel, PANEL_MODE_MessageIndicateur, ATTR_VISIBLE, 1);
								SetCtrlAttribute (GiPanel, PANEL_MODE_MessageIndicateur, ATTR_ZPLANE_POSITION, 0);

							bAffichMsgAttBoucle = 0;
						}

						// Si la g�che est ouverte
						if (GetGbGacheActive() == iGACHE_OUVERTE){
							// La gache doit �tre ferm�e pour lancer l'essai
							SetGiEtat(iETAT_DEM_CLOSE_ELECTRIC_LOCK);
							bAffichMsgAttElectLock = 1;
						}

						// Si la boucle de s�curit� est ferm�e
						if (iBoucleSecOuv != iUSB6008_ETAT_BOUCLE_SECURITE_OUVERTE){
							bAffichMsgAttBoucle   = 1; 
							bAffichMsgAttDepEssai = 1;
							// On cache le message d'attente d'appui sur le bouton de la boucle de s�curit�
							SetCtrlAttribute (GiPanel, PANEL_MODE_MessageIndicateur, ATTR_VISIBLE, 0);
							SetGiEtat(iETAT_ATT_DEP_ESSAI);
						}
					}
			}
			
			if(GetGiEtat() == iETAT_ATT_DEP_ESSAI){
				// Autorisation de l'ouverture g�che si le moteur ne tourne pas et si la pression est assez basse
				fVitesse = GetGfVitesse();
				if ((fabs(fVitesse) < dVIT_ABS_START_TEST)&& (GetGdPression() < ConvLimPression(dMAX_PRESS_START_TEST, GetGiUnitPression())))
					SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_OUV_GACHE, ATTR_DIMMED, 0);
				else
					SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_OUV_GACHE, ATTR_DIMMED, 1); 
					
				RetourEtatAttente(&iPorte1Ouverte, &iPorte2Ouverte, &iCapotOuvert, 
									 &iBoucleSecOuv, &iMoteurArret, &iArretUrgence, &iEtatCaptVib);

				if(	(iPorte1Ouverte == iUSB6008_ETAT_PORTE_1_OUVERTE) 			||
					(iPorte2Ouverte == iUSB6008_ETAT_PORTE_2_OUVERTE) 			||
					(iCapotOuvert 	== iUSB6008_ETAT_CAPOT_SECURITE_OUVERT) 	||
					((iMoteurArret 	!= iUSB6008_ETAT_MOTEUR_ARRETE) && (!GetGiStartCycleVitesse())) 			||
					(iBoucleSecOuv  == iUSB6008_ETAT_BOUCLE_SECURITE_OUVERTE)	||
					((GetGdPression() > ConvLimPression(dMAX_PRESS_START_TEST, GetGiUnitPression())) && (!GetGiStartCyclePression())) 						||
					(GetGiErrVaria() 	!= 0)										||
					(GetGiErrUsb6008() 	!= 0)										||
					(iArretUrgence 	== iUSB6008_ETAT_ARRET_URGENCE_ACTIF)		||
					(iEtatCaptVib 	==iUSB6008_ETAT_VIBRATIONS_DETECT_ACTIF)){
				
					bAffichMsgAttente = 1;									 
					SetGiEtat(iETAT_ATTENTE);
				}else{
						if(bAffichMsgAttDepEssai){
								SetGiErrUsb6008(Usb6008CommandeVentilationMoteur (iUSB6008_CMDE_VENTILATION_MOTEUR_INACTIFS)); 							
								// Mise � jour du voyant d'autorisation de d�part Essai
								SetCtrlVal (GiPanel, PANEL_MODE_START_ENABLE, 1);

								// Autorisation de l'appui sur les boutons de d�part essai
								SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VITESSE, ATTR_DIMMED, 	0);
								SetCtrlAttribute (GiPanel, PANEL_MODE_BUT_START_PRESSION, ATTR_DIMMED, 	0);
								SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_START_VIT_PRESS, ATTR_DIMMED, 0);
						
								// Demande d'appui sur le bouton de la boucle de s�curit�
								ModesAddMessageZM(sMSG_OK_SECUR_LOOP_CLOSED);
								ModesAddMessageZM(sMSG_WAIT_START_TEST);

							bAffichMsgAttDepEssai = 0;
						}
						
						if((GetGiStartCycleVitesse()== 1)||(GetGiStartCyclePression() == 1)||(GetGiStartVitPress() == 1)){
							// Interdiction de l'ouverture g�che
							SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_OUV_GACHE, ATTR_DIMMED, 1);
							bAffichMsgEssEnCours = 1;
							SetGiEtat(iETAT_ESSAI_EN_COURS); 
							iNbPannesSucc = 0;
						}
					} 
			}
			
			if(GetGiEtat() ==  iETAT_ESSAI_EN_COURS){
				RetourEtatAttente(&iPorte1Ouverte, &iPorte2Ouverte, &iCapotOuvert, 
									 &iBoucleSecOuv, &iMoteurArret, &iArretUrgence, &iEtatCaptVib);

				if(	(iPorte1Ouverte == iUSB6008_ETAT_PORTE_1_OUVERTE) 			||
					(iPorte2Ouverte == iUSB6008_ETAT_PORTE_2_OUVERTE) 			||
					(iCapotOuvert 	== iUSB6008_ETAT_CAPOT_SECURITE_OUVERT) 	||
					(iBoucleSecOuv  == iUSB6008_ETAT_BOUCLE_SECURITE_OUVERTE)	||
					(GetGiErrVaria() 	!= 0)										||
					(GetGiErrUsb6008() 	!= 0)										||
					(iArretUrgence 	== iUSB6008_ETAT_ARRET_URGENCE_ACTIF)		||
					(iEtatCaptVib 	==iUSB6008_ETAT_VIBRATIONS_DETECT_ACTIF)){
					
					if((GetGiErrVaria() != 0) || (GetGiErrUsb6008() != 0))
						iNbPannesSucc++;
					else
						iNbPannesSucc += 2;
				}
				else
					iNbPannesSucc = 0;
					
				if(iNbPannesSucc >= 4) {
					bAffichMsgAttente = 1;
					SetGiEtat(iETAT_ATTENTE);

						if (iPorte1Ouverte == iUSB6008_ETAT_PORTE_1_OUVERTE) 
							sprintf(sMsg, "%s: Door 1 Opened", sMSG_ERR_SECU_DFLT_DETEC);
						else
						if (iPorte2Ouverte == iUSB6008_ETAT_PORTE_2_OUVERTE)
							sprintf(sMsg, "%s: Door 2 Opened", sMSG_ERR_SECU_DFLT_DETEC);
						else
						if (iCapotOuvert 	== iUSB6008_ETAT_CAPOT_SECURITE_OUVERT)
							sprintf(sMsg, "%s: Security Hood Opened", sMSG_ERR_SECU_DFLT_DETEC);
						else
						if (iEtatCaptVib 	== iUSB6008_ETAT_VIBRATIONS_DETECT_ACTIF)
							sprintf(sMsg, "%s: ********** WARNING: VIBRATIONS DETECTED !!! **********", sMSG_ERR_SECU_DFLT_DETEC);
						else
						if (iBoucleSecOuv  == iUSB6008_ETAT_BOUCLE_SECURITE_OUVERTE)
							sprintf(sMsg, "%s: Security Loop Opened", sMSG_ERR_SECU_DFLT_DETEC);
						else
						if (GetGiErrVaria() 	!= 0)
							sprintf(sMsg, "%s: Variator communication error", sMSG_ERR_SECU_DFLT_DETEC);
						else
						if (GetGiErrUsb6008() 	!= 0)
							sprintf(sMsg, "%s: USB6008 communication error", sMSG_ERR_SECU_DFLT_DETEC);
						else
						if (iArretUrgence 	== iUSB6008_ETAT_ARRET_URGENCE_ACTIF)
							sprintf(sMsg, "%s: Emergency stop pushed", sMSG_ERR_SECU_DFLT_DETEC);
						else
							strcpy(sMsg, sMSG_ERR_SECU_DFLT_DETEC);
						
						AffStatusPanel(GiPanel, GiStatusPanel, iLEVEL_WARNING,"Cycle Error", sMsg, GetPointerToGiPanelStatusDisplayed(), &iAffMsg);
						ReleasePointerToGiPanelStatusDisplayed();

					SetGiAffMsg(iAffMsg);
				}else{
						if(bAffichMsgEssEnCours){
								SetGiErrUsb6008(Usb6008CommandeOuvertureGache (iUSB6008_CMDE_OUVERTURE_GACHE_INACTIVE));
								if(GetGiErrUsb6008() == 0){
									SetGbGacheActive(iGACHE_FERMEE);
									SetCtrlAttribute (GiPanel, PANEL_MODE_BUTT_OUV_GACHE, ATTR_LABEL_TEXT, "Open Electric Lock");
								}							

								// Mise � jour du voyant d'autorisation de d�part Essai
								SetCtrlVal (GiPanel, PANEL_MODE_START_ENABLE, 1);

								// Demande d'appui sur le bouton de la boucle de s�curit�
								ModesAddMessageZM(sMSG_TEST_RUNNING);

							bAffichMsgEssEnCours = 0;
						}
						
						// Si tous les cycles sont termin�s, alors on revient � l'accueil
						if((GetGiStartCycleVitesse()== 0) && (GetGiStartCyclePression() == 0) && (GetGiStartVitPress() == 0)){
							if ((GetGbEndCycleVitesse () == 1) && (GetGbEndCyclePression() == 1)){
								bAffichMsgAttente = 1;
								SetGiEtat(iETAT_ATTENTE);
							}
						}						
					}			
			}
		
		ProcessSystemEvents();
		dTime = Timer();
		SyncWait(dTime, dDELAY_SECURITY_PROCESS);
    }

	return(0);
}

// DEBUT ALGO
//***************************************************************************
//int CVICALLBACK OuvertureGache (int panel, int control, int event,
//		void *callbackData, int eventData1, int eventData2)
//***************************************************************************
//  - Param�tres CVI
//
//  - Commande l'ouverture de la gache
//
//  - 1 si probl�me d�tect�, 0 sinon
//***************************************************************************
// FIN ALGO
int CVICALLBACK OuvertureGache (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event){
		case EVENT_COMMIT:
			// On ne peut commander la g�che que si un essai est en cours
			if (GetGiEtat() != iETAT_ESSAI_EN_COURS){
				if(GetGbGacheActive() == iGACHE_FERMEE){
					// Commande de la g�che
					SetGiErrUsb6008(Usb6008CommandeOuvertureGache (iUSB6008_CMDE_OUVERTURE_GACHE_ACTIVE));
					// S'il n'y a pas d'erreur
					if(GetGiErrUsb6008() == 0){
						SetGbGacheActive(iGACHE_OUVERTE);
						SetCtrlAttribute (panel, control, ATTR_LABEL_TEXT, "Close Electric Lock");
					}
				}
				else{
							// Commande de la g�che
							SetGiErrUsb6008(Usb6008CommandeOuvertureGache (iUSB6008_CMDE_OUVERTURE_GACHE_INACTIVE));

						// S'il n'y ap pas d'erreur
						if(GetGiErrUsb6008() == 0){
							SetGbGacheActive(iGACHE_FERMEE);
							SetCtrlAttribute (panel, control, ATTR_LABEL_TEXT, "Open Electric Lock");
						}
					}				
			}
			break;
	}
	return 0;
}

// DEBUT ALGO
//***************************************************************************
// int CVICALLBACK DetailStatus (int panel, int control, int event,
//		void *callbackData, int eventData1, int eventData2)
//***************************************************************************
//  - Param�tres CVI
//
//  - Affiche le d�tail des status
//
//  - 1 si probl�me d�tect�, 0 sinon
//***************************************************************************
// FIN ALGO
int CVICALLBACK DetailStatus (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			if(GetGiPanelStatusDisplayed() == 0){
				// On cache l'�cran principal
				SetPanelAttribute (GiPanel, ATTR_VISIBLE, 0); 
				DisplayPanel(GiStatusPanel);
				
				// Modification du 07/07/2011 par CB ------ DEBUT --------------
				SetCtrlAttribute (GiStatusPanel, PANEL_STAT_MESSAGES, ATTR_TEXT_BOLD, 0);
				SetCtrlAttribute (GiStatusPanel, PANEL_STAT_MESSAGES, ATTR_TEXT_BGCOLOR, VAL_WHITE);
				SetCtrlAttribute (GiStatusPanel, PANEL_STAT_MESSAGES, ATTR_TEXT_COLOR,  VAL_BLACK);
				// Modification du 07/07/2011 par CB ------ FIN --------------
				
				//Effacement de la zone de message de l'�cran de status
				ResetTextBox (GiStatusPanel, PANEL_STAT_MESSAGES, "");
				SetGiPanelStatusDisplayed(1);
				SetGiAffMsg(0);
			}
		break;
	}
	
	return 0;
}

// DEBUT ALGO
//***************************************************************************
//int CVICALLBACK CloseStatusPanel (int panel, int control, int event,
//		void *callbackData, int eventData1, int eventData2)
//***************************************************************************
//  - Param�tres CVI
//
//  - Ferme l'�cran de d�tail des status
//
//  - 1 si probl�me d�tect�, 0 sinon
//***************************************************************************
// FIN ALGO
int CVICALLBACK CloseStatusPanel (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event){
		case EVENT_COMMIT:
			//Effacement de la zone de message de l'�cran de status
			ResetTextBox (GiStatusPanel, PANEL_STAT_MESSAGES, "");
			// On cache l'�cran d'affichage du status
			HidePanel (GiStatusPanel);
			//On refait passer � z�ro l'indicateur de message affich�
			SetGiAffMsg(0);
			// On affiche l'�cran principal
			SetPanelAttribute (GiPanel, ATTR_VISIBLE, 1); 
			SetGiPanelStatusDisplayed(0);
		break;
	}
	
	return 0;
}

int CVICALLBACK AffResult (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_COMMIT:

			break;
		}
	return 0;
}

